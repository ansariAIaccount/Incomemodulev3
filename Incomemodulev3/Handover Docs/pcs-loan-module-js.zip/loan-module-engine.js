/* =========================================================
   Loan Module Integration Layer — Engine
   Extracted from income-calculator.html (single source of truth)
   Last sync: 2026-05-08
   ========================================================= */
const ONE_DAY = 86400000;
function toISO(d){ const z=new Date(d); z.setHours(12,0,0,0); return z.toISOString().slice(0,10); }
function parseISO(s){ if(!s) return null; const [y,m,d]=s.split('-').map(Number); return new Date(y, m-1, d, 12); }
function addDays(d,n){ return new Date(d.getTime()+n*ONE_DAY); }
function addMonths(d,n){ const x=new Date(d); x.setMonth(x.getMonth()+n); return x; }
function eachDay(from,to){ const out=[]; for(let d=new Date(from); d<=to; d=addDays(d,1)) out.push(new Date(d)); return out; }
function isLeap(y){ return (y%4===0 && y%100!==0) || y%400===0; }
function daysInYear(d){ return isLeap(d.getFullYear())?366:365; }
function sameDate(a,b){ return a && b && a.getTime()===b.getTime(); }

/* ---------- Day-count per-day accrual factor ---------- */
function dayCountFactor(basis, date){
  // Returns the fraction of year attributed to ONE calendar day.
  switch(basis){
    case 'ACT/360': return 1/360;
    case 'ACT/365': return 1/365;
    case 'ACT/ACT': return 1/daysInYear(date);
    case '30/360':  return 1/360; // simplified — for daily granularity 30/360 treats each day = 1/360
    default: return 1/360;
  }
}

/* ---------- Event lookup ---------- */
function eventsOn(date, events){
  const iso = toISO(date);
  return (events||[]).filter(e => e.date === iso);
}

/* ---------- Holiday calendars (Req 18) ----------
   Small curated set covering 2019-2031 for demo purposes. In production these
   would come from a calendar service (e.g. SIFMA, TARGET, Bank of England).
-------------------------------------------------- */
const HOLIDAY_CALENDARS = {
  none: new Set(),
  usFederal: new Set([
    '2019-01-01','2019-01-21','2019-02-18','2019-05-27','2019-07-04','2019-09-02','2019-10-14','2019-11-11','2019-11-28','2019-12-25',
    '2020-01-01','2020-01-20','2020-02-17','2020-05-25','2020-07-03','2020-09-07','2020-10-12','2020-11-11','2020-11-26','2020-12-25',
    '2024-01-01','2024-01-15','2024-02-19','2024-05-27','2024-06-19','2024-07-04','2024-09-02','2024-10-14','2024-11-11','2024-11-28','2024-12-25',
    '2025-01-01','2025-01-20','2025-02-17','2025-05-26','2025-06-19','2025-07-04','2025-09-01','2025-10-13','2025-11-11','2025-11-27','2025-12-25',
    '2026-01-01','2026-01-19','2026-02-16','2026-05-25','2026-06-19','2026-07-03','2026-09-07','2026-10-12','2026-11-11','2026-11-26','2026-12-25',
    '2027-01-01','2028-01-01','2029-01-01','2030-01-01','2031-01-01'
  ]),
  ukBank: new Set([
    '2024-01-01','2024-03-29','2024-04-01','2024-05-06','2024-05-27','2024-08-26','2024-12-25','2024-12-26',
    '2025-01-01','2025-04-18','2025-04-21','2025-05-05','2025-05-26','2025-08-25','2025-12-25','2025-12-26',
    '2026-01-01','2026-04-03','2026-04-06','2026-05-04','2026-05-25','2026-08-31','2026-12-25','2026-12-28'
  ]),
  target: new Set([
    '2024-01-01','2024-03-29','2024-04-01','2024-05-01','2024-12-25','2024-12-26',
    '2025-01-01','2025-04-18','2025-04-21','2025-05-01','2025-12-25','2025-12-26',
    '2026-01-01','2026-04-03','2026-04-06','2026-05-01','2026-12-25','2026-12-28'
  ])
};
function isHoliday(date, calendarId){
  const cal = HOLIDAY_CALENDARS[calendarId] || HOLIDAY_CALENDARS.none;
  return cal.has(toISO(date));
}

/* ---------- Business day + payment date helpers (v3) ----------
   Standard loan-market conventions:
     - Following            : if date is non-bizday, roll FORWARD to next bizday
     - ModifiedFollowing    : Following, but if it crosses month-end, roll
                              BACKWARD to the prior bizday instead (default
                              for syndicated loans + most interest payments)
     - Preceding            : if date is non-bizday, roll BACKWARD
     - NoAdjustment         : keep the scheduled date even if non-bizday
   Weekend = Saturday (6) or Sunday (0). Holiday = in HOLIDAY_CALENDARS[cal].
-------------------------------------------------------------- */
function isWeekend(d){ const w = d.getDay(); return w === 0 || w === 6; }
function isBusinessDay(d, calendarId){
  return !isWeekend(d) && !isHoliday(d, calendarId);
}
function rollDate(date, calendarId, convention){
  // Returns { paymentDate (Date), originalScheduledDate (Date), rolled (bool),
  //          rollReason ('weekend'|'holiday'|null), conventionUsed }.
  const conv = convention || 'ModifiedFollowing';
  const orig = new Date(date);
  if(conv === 'NoAdjustment' || isBusinessDay(orig, calendarId)){
    return { paymentDate: orig, originalScheduledDate: orig, rolled: false, rollReason: null, conventionUsed: conv };
  }
  const reason = isWeekend(orig) ? 'weekend' : 'holiday';
  if(conv === 'Preceding'){
    let d = new Date(orig);
    while(!isBusinessDay(d, calendarId)) d = addDays(d, -1);
    return { paymentDate: d, originalScheduledDate: orig, rolled: true, rollReason: reason, conventionUsed: conv };
  }
  // Following / ModifiedFollowing share forward-roll first
  let d = new Date(orig);
  while(!isBusinessDay(d, calendarId)) d = addDays(d, 1);
  if(conv === 'ModifiedFollowing' && d.getMonth() !== orig.getMonth()){
    // Forward-roll crossed month-end → roll backward instead
    d = new Date(orig);
    while(!isBusinessDay(d, calendarId)) d = addDays(d, -1);
  }
  return { paymentDate: d, originalScheduledDate: orig, rolled: true, rollReason: reason, conventionUsed: conv };
}
/* generatePaymentSchedule — list of payment events from anchor to endDate
   at the given frequency, each rolled per convention.
   anchor / endDate are ISO strings or Dates. frequency is one of
   'monthly' | 'quarterly' | 'semi' | 'semiAnnual' | 'annual'.
   Returns: [{ paymentDate ISO, originalScheduledDate ISO, rolled, rollReason, conventionUsed, seq }]
-------------------------------------------------------------- */
function generatePaymentSchedule(anchor, frequency, endDate, calendarId, convention){
  const out = [];
  const anchorD = (anchor instanceof Date) ? anchor : parseISO(anchor);
  const endD    = (endDate instanceof Date) ? endDate : parseISO(endDate);
  if(!anchorD || !endD) return out;
  const stepMonths = ({ monthly:1, quarterly:3, semi:6, semiAnnual:6, annual:12 })[frequency] || 0;
  if(!stepMonths) return out;
  const conv = convention || 'ModifiedFollowing';
  let seq = 0;
  for(let i = 0; ; i++){
    // Schedule date = anchor day-of-month, i months later. Preserve the
    // anchor's day-of-month: addMonths uses JS Date semantics which roll
    // overflow forward (e.g. 1/31 + 1mo → 3/3). For finance we want EOM-clamped:
    // 1/31 + 1mo → 2/28 (or 2/29 in a leap year).
    const target = addMonths(anchorD, i * stepMonths);
    const wantedDay = anchorD.getDate();
    if(target.getDate() !== wantedDay){
      // JS overflowed — clamp to last day of intended month
      const intendedMonth = (anchorD.getMonth() + i * stepMonths) % 12;
      const intendedYear  = anchorD.getFullYear() + Math.floor((anchorD.getMonth() + i * stepMonths) / 12);
      target.setFullYear(intendedYear, intendedMonth + 1, 0);  // 0th day = last of prev month
      target.setHours(12,0,0,0);
    }
    if(target > endD) break;
    const rolled = rollDate(target, calendarId, conv);
    seq++;
    out.push({
      seq,
      paymentDate:           toISO(rolled.paymentDate),
      originalScheduledDate: toISO(rolled.originalScheduledDate),
      rolled:                rolled.rolled,
      rollReason:            rolled.rollReason,
      conventionUsed:        rolled.conventionUsed,
      dayOfWeek:             ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][rolled.paymentDate.getDay()]
    });
    if(seq > 600) break;  // safety — 50 years of monthly
  }
  return out;
}
// Expose for the V3 UI (fee card preview etc.).
if(typeof window !== 'undefined'){
  window.rollDate = rollDate;
  window.generatePaymentSchedule = generatePaymentSchedule;
  window.isBusinessDay = isBusinessDay;
  window.isHoliday_engine = isHoliday;
}

/* ---------- Capitalization gate ---------- */
/* A floating-rate reset date: the anchor's day-of-month, every N months after
   settlement. Shares the day-of-month convention with isCapitalizationDay so a
   loan that settles on the 15th resets on the 15th, not on month-ends. */
function isResetDay(date, anchor, months){
  if(!anchor || !(months > 0)) return false;
  if(date.getDate() !== anchor.getDate()) return false;
  const elapsed = (date.getFullYear()-anchor.getFullYear())*12 + (date.getMonth()-anchor.getMonth());
  return elapsed > 0 && elapsed % months === 0;
}

function isCapitalizationDay(date, anchor, freq){
  // Capitalization happens on the day-of-month of the anchor at the given frequency.
  if(!anchor) return false;
  if(date.getDate() !== anchor.getDate()) return false;
  const months = (date.getFullYear()-anchor.getFullYear())*12 + (date.getMonth()-anchor.getMonth());
  if(months <= 0) return false;
  if(freq==='Monthly')   return months % 1 === 0;
  if(freq==='Quarterly') return months % 3 === 0;
  if(freq==='Yearly')    return months % 12 === 0;
  return false;
}

/* ---------- IRR / yield solve (bisection, robust) ---------- */
function npv(rate, cashflows){
  // cashflows: [{t: yearsFromT0, amount}]
  let v=0; for(const cf of cashflows) v += cf.amount/Math.pow(1+rate, cf.t); return v;
}
function solveYield(targetNPV, cashflows){
  let lo=-0.99, hi=5.0;
  const f = r => npv(r, cashflows) - targetNPV;
  let fl=f(lo), fh=f(hi);
  if(fl*fh > 0) return null; // no sign change
  for(let i=0;i<200;i++){
    const mid=(lo+hi)/2, fm=f(mid);
    if(Math.abs(fm)<1e-9) return mid;
    if(fl*fm<0){ hi=mid; fh=fm; } else { lo=mid; fl=fm; }
  }
  return (lo+hi)/2;
}

/* ---------- Effective Interest Rate (EIR) solver ----------
   Returns a self-contained yield report for the instrument, computed
   independently of the amortization method selected. Fields:
     method          - the amort method actually driving book accretion
     effectiveYield  - the y used by the effective-interest family (or null)
     impliedYTM      - yield solved from (purchasePrice, projected coupon CFs,
                       face at maturity) — always computed for Fixed coupons
                       when PP≠Face; for Floating, uses current (index+spread).
     cashYield       - annual coupon / purchasePrice (current yield).
     totalReturn     - annualized (faceValue + totalCoupon - purchasePrice) / PP
     source          - 'price' | 'formula' | 'override' | 'implied' | 'par'
     note            - human-readable explanation.
   All yields are decimals (0.12 = 12%).
-------------------------------------------------------------- */
// Face-weighted aggregate EIR across tranches[] / underlyingLoans[].
// Returns null if no children resolved a non-zero coupon — caller handles fallback.
function aggregateChildEIRs(childResults, childRecords, kind){
  if(!childResults.length) return null;
  let totalFace = 0, weightedCoupon = 0, weightedYield = 0, withYield = 0;
  for(let i = 0; i < childResults.length; i++){
    const r = childResults[i];
    // Accept either `faceValue` (engine shape) or `face` (Builder shape) —
    // v4 projects B.tranches directly onto inst.tranches so covenant KPI
    // computes can see PIK toggles, and those tranches use `face`.
    // Without this fallback, aggregateChildEIRs saw totalFace=0 and
    // returned null → computeEIR returned null → Run Accounting crashed
    // for any multi-tranche DB-loaded deal (Barrenjoey RE Mezz).
    const rec = childRecords[i];
    const f = (rec && (rec.faceValue != null ? +rec.faceValue : +rec.face)) || 0;
    if(f <= 0) continue;
    totalFace += f;
    weightedCoupon += (r.couponRate || 0) * f;
    if(r.effectiveYield != null){
      weightedYield += r.effectiveYield * f;
      withYield += f;
    }
  }
  if(totalFace <= 0) return null;
  const couponRate = weightedCoupon / totalFace;
  const effectiveYield = withYield > 0 ? weightedYield / withYield : null;
  return {
    method: 'aggregated',
    couponRate,
    annualCoupon: totalFace * couponRate,
    effectiveYield,
    impliedYTM: null,
    cashYield: null,
    totalReturn: null,
    yearsToMat: childResults[0].yearsToMat,
    dayBasis: childResults[0].dayBasis,
    source: 'children',
    note: `Face-weighted across ${childResults.length} ${kind}${childResults.length === 1 ? '' : 's'} — coupon ${(couponRate*100).toFixed(4)}%`
  };
}

/* ============================================================================
   US GAAP — 4-method EIR calculator (Interest AT / Investran convention)
   Applied ONLY when instr.accountingFramework === 'USGAAP'. IFRS / ASPE deals
   continue to use the original IRR-style bisection (see below).

   Methods per the Income Security Panel spec (Folder 1):
     • Method 1 (custom formula — Main Street Capital):
         EIR = (P/CV)^(1/m) - 1 + (I1 + I2)
     • Method 2 (PRICE, iterative — default):  retained as highest-priority
         EIR = bisection over (CV, [coupon CFs..., face + last coupon])
     • Method 3 (generic formula):
         EIR = (PMT + (P-CV)/m) / ((CV+P)/2)
     • Method 4 (client override):
         EIR = instr.eirOverride  (skip calculation)

   Priority order when instr.eirMethod is null/missing:
     override → method2 (PRICE) → method3 → method1.
   ============================================================================ */
/* ============================================================================
   OID / Premium treatment (Transtype #1 spec — Option β)

   Translates the user-facing `oidTreatment` and `oidMethod` fields into the
   existing engine machinery (`amortization.method`). The engine already
   produces separate JE pairs for fee accretion vs OID/premium accretion — this
   helper just lets PortF set it via a clean, single field.

     oidTreatment:
       'auto'    → infer from PP vs FV  (PP<FV → oid, PP>FV → premium, else none)
       'oid'     → force discount accretion treatment
       'premium' → force premium amortisation treatment
       'none'    → no OID/premium treatment

     oidMethod:
       'effective-interest'  → use existing effectiveInterestFormula path
       'straight-line'       → use existing straightLine path
   ============================================================================ */
function resolveOIDTreatment(instr){
  if(!instr) return { treatment: 'none', method: 'effective-interest' };
  const pp = instr.purchasePrice || instr.faceValue || 0;
  const fv = instr.faceValue || 0;
  let t = (instr.oidTreatment || 'auto').toLowerCase();
  if(t === 'auto'){
    if(pp < fv - 0.01) t = 'oid';
    else if(pp > fv + 0.01) t = 'premium';
    else t = 'none';
  }
  const m = (instr.oidMethod || 'effective-interest').toLowerCase();
  return { treatment: t, method: m, oidAmount: fv - pp };
}

// Ensure `amortization.method` is set to drive the existing accretion logic
// whenever oidTreatment resolves to oid/premium. This runs lazily on read; we
// don't mutate the instrument here — the engine's dailyAmort path already
// keys off amortization.method, so we provide it via a getter when computeEIR
// or buildSchedule are called.
function applyOIDOverrideToAmortMethod(instr){
  const r = resolveOIDTreatment(instr);
  if(r.treatment === 'none') return instr;
  // Don't overwrite an explicitly-set non-'none' amortization.method
  const existing = instr.amortization && instr.amortization.method;
  if(existing && existing !== 'none') return instr;
  // effective-interest → solve yield from price (purchasePrice vs face);
  // straight-line     → totalOID / totalDays
  const newMethod = r.method === 'straight-line' ? 'straightLine' : 'effectiveInterestPrice';
  return Object.assign({}, instr, {
    amortization: Object.assign({}, instr.amortization || {}, { method: newMethod }),
    _oidResolved: r
  });
}

function computeEIRUSGAAP(instr){
  if(!instr) return null;
  const method = instr.eirMethod || 'method2';     // default: PRICE

  const settle   = parseISO(instr.settlementDate);
  const maturity = parseISO(instr.maturityDate);
  if(!settle || !maturity || maturity <= settle) return null;

  const basis = instr.dayBasis || 'ACT/365';
  const daysPerYear = (basis === 'ACT/365' || basis === 'ACT/ACT') ? 365 : 360;
  const totalDays = Math.round((maturity - settle) / ONE_DAY);
  const m = totalDays / daysPerYear;

  const P    = instr.faceValue    || 0;
  const CV   = instr.purchasePrice || P;
  const c    = instr.coupon || { type: 'Fixed', fixedRate: 0 };
  const I1   = (c.type === 'Fixed') ? (c.fixedRate || 0) : 0;
  const I2   = (instr.pik && instr.pik.enabled && instr.pik.rate) || 0;
  // PMT per Folder 1 spec — annual interest payment INCLUDING PIK accrual.
  // Test data verifies: P=10m, I1=10%, I2=5% → PMT = 1.5m (not just cash 1m).
  const PMT  = P * (I1 + I2);

  function packReport(eir, methodCode, methodLabel, source, note, trace){
    return {
      method:         instr.amortization?.method || methodCode,
      eirMethod:      methodCode,
      eirMethodLabel: methodLabel,
      couponRate:     I1,
      annualCoupon:   PMT,
      effectiveYield: eir,
      impliedYTM:     null,
      cashYield:      CV > 0 ? (PMT / CV) : null,
      totalReturn:    null,
      yearsToMat:     m,
      dayBasis:       basis,
      source:         source,
      note:           note,
      rateBreakdown:  '',
      eirTrace:       trace,
      eirInputs:      { P, CV, m, I1, I2, PMT, settle: instr.settlementDate, mat: instr.maturityDate }
    };
  }

  // ── Method 4 — Client Override ─────────────────────────────────────────
  if(method === 'override'){
    if(typeof instr.eirOverride === 'number'){
      const eir = instr.eirOverride;
      return packReport(eir, 'override', 'Method 4 — Client Override',
        'override', 'Client-provided override · ' + (eir*100).toFixed(4) + '% · skips calculation',
        { steps: [{ label: 'Client override', value: eir, isFinal: true }] });
    }
    // override flagged but no value → fall through to default
  }

  // ── Method 1 — Custom formula (Main Street Capital) ────────────────────
  if(method === 'method1'){
    if(CV <= 0 || m <= 0) return packReport(I1, 'method1', 'Method 1 — Custom Formula',
      'method1-degenerate', 'Cannot compute: CV or m is zero',
      { steps: [] });
    const A   = P / CV;
    const B   = 1 / m;
    const C   = Math.pow(A, B);
    const D   = I1 + I2;
    const eir = C - 1 + D;
    return packReport(eir, 'method1', 'Method 1 — Custom Formula',
      'method1-custom', 'EIR = (P/CV)^(1/m) - 1 + (I1+I2)',
      { steps: [
          { label: 'A = P / CV',         value: A,   formula: P + ' / ' + CV },
          { label: 'B = 1 / m',          value: B,   formula: '1 / ' + m.toFixed(6) },
          { label: 'C = A^B',            value: C,   formula: A.toFixed(6) + '^' + B.toFixed(6) },
          { label: 'D = I1 + I2',        value: D,   formula: I1 + ' + ' + I2 },
          { label: 'EIR = C - 1 + D',    value: eir, isFinal: true,
            formula: C.toFixed(6) + ' - 1 + ' + D.toFixed(6) }
      ]});
  }

  // ── Method 3 — Generic formula ─────────────────────────────────────────
  if(method === 'method3'){
    if(CV + P <= 0 || m <= 0) return packReport(I1, 'method3', 'Method 3 — Generic Formula',
      'method3-degenerate', 'Cannot compute: CV+P or m is zero',
      { steps: [] });
    const a   = (P - CV) / m;
    const b   = PMT + a;
    const cAvg= (CV + P) / 2;
    const eir = b / cAvg;
    return packReport(eir, 'method3', 'Method 3 — Generic Formula',
      'method3-generic', 'EIR = (PMT + (P-CV)/m) / ((CV+P)/2)',
      { steps: [
          { label: 'A = (P-CV) / m',     value: a,    formula: '(' + P + ' - ' + CV + ') / ' + m.toFixed(6) },
          { label: 'B = PMT + A',        value: b,    formula: PMT + ' + ' + a.toFixed(6) },
          { label: 'C = (CV+P) / 2',     value: cAvg, formula: '(' + CV + ' + ' + P + ') / 2' },
          { label: 'EIR = B / C',        value: eir,  isFinal: true,
            formula: b.toFixed(6) + ' / ' + cAvg.toFixed(6) }
      ]});
  }

  // ── Method 2 — PRICE (default; bisection over bond cashflows) ──────────
  const cfs = [];
  const fullYears = Math.floor(m);
  for(let y = 1; y <= fullYears; y++) cfs.push({ t: y, amount: PMT });
  const stub = m - fullYears;
  cfs.push({ t: m, amount: P + (stub > 0 ? PMT * stub : 0) });
  const eir = solveYield(CV, cfs);
  return packReport(eir, 'method2', 'Method 2 — PRICE (Iterative)',
    'method2-price', 'PRICE method · bisection solve over coupon + balloon cashflows',
    { steps: [
        { label: 'Cashflow set',       value: cfs.length + ' periods' },
        { label: 'Day-1 outflow',      value: -CV },
        { label: 'Coupon stream',      value: PMT + ' × ' + fullYears + ' years' },
        { label: 'Balloon',            value: P + (stub > 0 ? ' + stub coupon' : '') },
        { label: 'Bisection result',   value: eir, isFinal: true }
    ], cashflows: cfs });
}

function computeEIR(instr){
  if(!instr) return null;

  // ── US GAAP — branch to Interest AT 4-method calculator (Folder 1 spec)
  if(instr.accountingFramework === 'USGAAP'){
    return computeEIRUSGAAP(instr);
  }

  // ---- Multi-tranche / guarantee wrapper handling ----------------------
  // For loans split into tranches[] (e.g. Suffolk Solar) compute a face-weighted
  // EIR across the children. For guarantees with underlyingLoans[] (Volt
  // Multi-Loan), do the same. The top-level coupon on these wrappers is
  // typically all zeros — the real rate lives on each child.
  if(Array.isArray(instr.tranches) && instr.tranches.length){
    const child = instr.tranches.map(t => {
      const merged = Object.assign({}, instr, t);
      delete merged.tranches; delete merged.underlyingLoans;   // prevent infinite recursion
      return computeEIR(merged);
    }).filter(x => x);
    return aggregateChildEIRs(child, instr.tranches, 'tranche');
  }
  if(Array.isArray(instr.underlyingLoans) && instr.underlyingLoans.length){
    const child = instr.underlyingLoans.map(u => {
      const merged = Object.assign({}, instr, u);
      delete merged.tranches; delete merged.underlyingLoans;
      return computeEIR(merged);
    }).filter(x => x);
    return aggregateChildEIRs(child, instr.underlyingLoans, 'underlying');
  }

  const settle   = parseISO(instr.settlementDate);
  const maturity = parseISO(instr.maturityDate);
  if(!settle || !maturity || maturity <= settle) return null;

  const basis = instr.dayBasis || 'ACT/360';
  const daysPerYear = (basis==='ACT/365' || basis==='ACT/ACT') ? 365 : 360;
  const totalDays = Math.round((maturity-settle)/ONE_DAY);
  const yearsToMat = totalDays / daysPerYear;

  const face = instr.faceValue || 0;
  const price = instr.purchasePrice || face;
  const amort = instr.amortization || { method:'none' };

  // ---- Current coupon rate -----------------------------------------------
  // Three coupon families:
  //   • Fixed                — uses coupon.fixedRate
  //   • Floating             — uses coupon.floatingRate + coupon.spread (legacy SOFR-style)
  //   • SONIA / SOFR / EURIBOR / FED / etc — RFR-driven, uses:
  //         rfr.baseRate                                     (the observed index level)
  //       + coupon.spread  OR  current marginSchedule entry  (the contractual margin)
  //       + ESG adjustment if enabled
  const c = instr.coupon || { type:'Fixed', fixedRate:0 };
  const RFR_TYPES = new Set(['SONIA','SOFR','ESTR','EURIBOR','TONA','FED']);
  let couponRate = 0;
  let rateBreakdown = '';
  if(c.type === 'Fixed'){
    couponRate = c.fixedRate || 0;
    rateBreakdown = `Fixed coupon ${(couponRate*100).toFixed(4)}%`;
  } else if(RFR_TYPES.has(c.type) || instr.rfr){
    const baseRate = instr.rfr?.baseRate ?? c.floatingRate ?? 0;
    let margin = c.spread ?? 0;
    // marginSchedule[] takes precedence if present (Libra 3, Volt, Suffolk)
    if(Array.isArray(instr.marginSchedule) && instr.marginSchedule.length){
      const todayISO = toISO(new Date());
      const inWindow = instr.marginSchedule.find(s =>
        (!s.from || s.from <= todayISO) && (!s.to || s.to >= todayISO)
      ) || instr.marginSchedule[0];
      if(inWindow){
        margin = (inWindow.marginBps != null) ? inWindow.marginBps / 10000 : (inWindow.spread || margin);
      }
    }
    let raw = baseRate + margin;
    if(c.floor != null) raw = Math.max(raw, c.floor);
    if(c.cap   != null) raw = Math.min(raw, c.cap);
    couponRate = raw;
    rateBreakdown = `${c.type || 'RFR'} ${(baseRate*100).toFixed(4)}% + margin ${(margin*100).toFixed(4)}% = ${(couponRate*100).toFixed(4)}%`;
  } else {
    // Legacy 'Floating' (SOFR-style) — explicit floatingRate + spread on coupon
    let raw = (c.floatingRate || 0) + (c.spread || 0);
    if(c.floor != null) raw = Math.max(raw, c.floor);
    if(c.cap   != null) raw = Math.min(raw, c.cap);
    couponRate = raw;
    rateBreakdown = `Floating ${((c.floatingRate||0)*100).toFixed(4)}% + spread ${((c.spread||0)*100).toFixed(4)}% = ${(couponRate*100).toFixed(4)}%`;
  }
  const annualCoupon = face * couponRate;

  // --- Implied YTM: annual coupons + balloon at maturity ---
  let impliedYTM = null;
  if(price > 0 && face > 0 && yearsToMat > 0){
    const cfs = [];
    const fullYears = Math.floor(yearsToMat);
    for(let y=1; y<=fullYears; y++) cfs.push({ t:y, amount: annualCoupon });
    const stub = yearsToMat - fullYears;
    cfs.push({ t: yearsToMat, amount: face + (stub>0 ? annualCoupon*stub : 0) });
    impliedYTM = solveYield(price, cfs);
  }

  // --- Effective yield actually driving amortization ---
  let effectiveYield = null, source = 'par', note = '';
  if(amort.method === 'effectiveInterestPrice'){
    effectiveYield = impliedYTM;
    source = 'price';
    note = 'Yield solved from purchase price vs. projected coupon cashflows.';
  } else if(amort.method === 'effectiveInterestFormula'){
    effectiveYield = couponRate + (amort.spread ?? 0);
    source = 'formula';
    note = `Yield = coupon (${(couponRate*100).toFixed(4)}%) + user spread (${((amort.spread||0)*100).toFixed(4)}%).`;
  } else if(amort.method === 'effectiveInterestIRR'){
    effectiveYield = amort.yieldOverride ?? couponRate;
    source = 'override';
    note = 'Yield override supplied by user.';
  } else if(amort.method === 'straightLine'){
    source = 'straightLine';
    note = 'Straight-line amortization — no effective yield; showing implied YTM for reference.';
  } else {
    source = price === face ? 'par' : 'implied';
    note = price === face
      ? 'Bond purchased at par — no amortization; cash yield equals coupon.'
      : 'No amortization method set — showing implied YTM for reference only.';
  }

  // --- Other useful yield metrics ---
  const cashYield   = price > 0 ? (annualCoupon / price) : null;
  const totalCoupon = annualCoupon * yearsToMat;
  const totalReturn = (price > 0 && yearsToMat > 0)
    ? ((face + totalCoupon - price) / price) / yearsToMat : null;

  // Prepend the rate breakdown to the note so the FV / EIR display shows base + margin.
  const fullNote = rateBreakdown ? `${rateBreakdown}${note ? ' · ' + note : ''}` : note;
  return {
    method: amort.method || 'none',
    couponRate, annualCoupon,
    effectiveYield, impliedYTM, cashYield, totalReturn,
    yearsToMat, dayBasis: basis, source, note: fullNote, rateBreakdown
  };
}

/* ═══════════════════════════════════════════════════════════════════════════
   deriveModificationGainLoss — IFRS 9 §5.4.3 / §B5.4.6
   ───────────────────────────────────────────────────────────────────────────
   On a non-substantial modification the lender does not derecognise. It
   recalculates the gross carrying amount as the present value of the REVISED
   contractual cash flows, discounted at the ORIGINAL effective interest rate,
   and takes the difference to profit or loss.

   Until now PCS took `gainLoss` as a figure typed in by the user. That makes
   the headline number of a restructuring an assertion rather than a
   calculation: nothing checked it, nothing could reproduce it, and an auditor
   asking "how did you arrive at that?" would have had no answer. Worse, a
   blank field silently produced a modification with no gain or loss at all.

   This derives it. The supplied value still wins when one is given — a user
   may be booking a figure agreed elsewhere — but the derivation is always
   computed alongside so the two can be compared and a disagreement surfaced.

   Returns null when it cannot be computed (no original EIR, no horizon), so
   the caller can fall back rather than publish a zero that looks deliberate.
   ═══════════════════════════════════════════════════════════════════════════ */

/* ═══ Date-banded margins ═══════════════════════════════════════════════════
   An interest component carries a base rate plus a list of dated spread bands
   — [{from, to, marginBps}] — and the all-in rate on any day is the base plus
   whichever band covers that day. This is how a step-up, a ratchet, a pricing
   holiday and a PIK leg that only runs for one amendment year are all
   expressed.

   The engine previously read the base rate alone on every coupon type except
   compounded-RFR, and the builder only ever handed over `spreads[0].bps` as a
   single lifetime constant. So every band after the first was discarded, and
   on a FIXED coupon all of them were: a deal priced at "6% base, +400bps for
   2025, +0bps thereafter" ran at a flat 6%, and a PIK leg written as "0% base,
   +1100bps during the amendment year" never capitalised a cent. Both are
   silent — the schedule looks orderly, the journals balance, and the rate is
   simply wrong.

   Returns null, not 0, when no band covers the date. The two are different
   answers: 0 bps is a band that deliberately adds nothing, while null means
   nobody said — and only the caller knows whether its fallback is the
   contractual spread or no spread at all. */
function bandBpsOn(schedule, dateISO){
  if(!Array.isArray(schedule) || !schedule.length || !dateISO) return null;
  /* Where two bands both cover the date, the one that STARTS later wins.
     Band ends are inclusive, so a schedule written "…to 2025-07-01" followed
     by "from 2025-07-01…" has both live on the changeover day. Returning the
     first match let the expiring band own that day — and since these schedules
     arrive from a database with no ORDER BY, "first" is not even reliably the
     earliest, so a margin could be read from the wrong period entirely. */
  let best = null, bestFrom = null;
  for(const b of schedule){
    if(!b) continue;
    const f = b.from || b.effectiveFrom || '0000-01-01';
    const t = b.to   || b.effectiveTo   || '9999-12-31';
    if(dateISO < f || dateISO > t) continue;
    if(best === null || f >= bestFrom){ best = b; bestFrom = f; }
  }
  if(best === null) return null;
  const bps = (best.marginBps != null) ? +best.marginBps : +best.bps;
  return isFinite(bps) ? bps : 0;
}
if(typeof window !== 'undefined') window.bandBpsOn = bandBpsOn;

/* The PIK rate in force on a given day.

   `instr.pik.rate` is the rate at inception and stays the fallback, so a deal
   with a flat PIK coupon behaves exactly as before. When a band schedule is
   present it wins, because a PIK leg that switches on mid-life — the ordinary
   shape of a payment-deferral amendment — cannot be expressed as one number.

   Note the `enabled` check is deliberately NOT applied here: whether PIK runs
   at all is the caller's question (see pikEverEnabled), and a zero rate today
   with a non-zero band next year is still an enabled PIK leg. */
function pikRateOn(instr, dateISO){
  const p = instr && instr.pik;
  if(!p) return 0;
  const sched = p.schedule;
  if(Array.isArray(sched) && sched.length){
    const bps = bandBpsOn(sched, dateISO);
    return (+p.baseRate || 0) + (bps == null ? 0 : bps / 10000);
  }
  return +p.rate || 0;
}
if(typeof window !== 'undefined') window.pikRateOn = pikRateOn;

/* ── RFR provenance ──────────────────────────────────────────────────────────
   Where the rate for a given day came from: 'actual' | 'forecast' |
   'held-flat' | 'base' | 'none'.

   Placed HERE, beside the other module-scope helpers, and not next to
   computeCompoundedRFR where it logically belongs — because that function is
   not module scope. It sits inside buildSchedule, at column zero, which reads
   exactly like a top-level declaration and is not one. Defining these two
   there left them invisible to every caller outside the schedule builder and
   silently un-exported, and the indentation gave no hint.

   Taking the instrument and a date rather than remembering what the last rate
   calculation did: a "what happened on the previous call" channel works until
   something calls it twice, or out of order, or not at all, and then it
   reports the wrong day's provenance with complete confidence.

   'held-flat' is the honest name for the long-standing behaviour — no
   forecast supplied, so the last published fixing is carried into the future.
   It is not an observation and must never be shown as one. */
function rfrRateSourceOn(instr, dateISO){
  const rfr = instr && instr.rfr;
  if(!rfr || !Array.isArray(rfr.fixings) || !rfr.fixings.length){
    return (rfr && rfr.baseRate != null) ? 'base' : 'none';
  }
  const fxs = rfr.fixings.slice().sort((a,b) => (a.date||'').localeCompare(b.date||''));
  const lastActual  = fxs[fxs.length - 1].date;
  const firstActual = fxs[0].date;
  if(dateISO <= lastActual){
    return (dateISO >= firstActual) ? 'actual' : 'base';
  }
  const fcs = Array.isArray(rfr.forecast) ? rfr.forecast : [];
  if(fcs.length){
    /* Inside the curve's own span it is a forecast. PAST its last point the
       rate is the final forecast value carried forward, which is an
       extrapolation and not a view anybody published — so it is reported as
       held-flat, the same as having no curve at all.

       This matters at the long end: the SONIA curve runs to June 2035 and
       Suffolk matures in 2062, so twenty-seven years would otherwise be
       labelled "forecast" on the strength of a curve that stops decades
       earlier. */
    let first = null, last = null;
    for(const f of fcs){
      if(!f || !f.date) continue;
      if(first === null || f.date < first) first = f.date;
      if(last  === null || f.date > last)  last  = f.date;
    }
    if(first !== null && dateISO >= first && dateISO <= last) return 'forecast';
  }
  return 'held-flat';
}
if(typeof window !== 'undefined') window.rfrRateSourceOn = rfrRateSourceOn;

/* The published rate in force on a day — actuals first, forecast beyond them,
   last actual held flat if there is no forecast. No compounding.

   This is the correct reading for a TERM rate (Term SOFR, EURIBOR, BBSW,
   BBSY): the rate is published for the period and taken as it stands. A
   compounded-in-arrears RFR (SONIA, SOFR, ESTR) is a different calculation and
   goes through computeCompoundedRFR instead — compounding a term fixing would
   overstate it, and reading a daily RFR as a term rate would understate the
   convention it was contracted on.

   Returns null when nothing is known, so the caller can fall back to the
   static rate rather than being handed a zero that looks deliberate. */
function rfrRateOn(instr, dateISO){
  const rfr = instr && instr.rfr;
  if(!rfr) return null;
  const pick = (series) => {
    if(!Array.isArray(series) || !series.length) return null;
    let last = null;
    for(const f of series.slice().sort((a,b) => (a.date||'').localeCompare(b.date||''))){
      if(f.date <= dateISO) last = +f.rate; else break;
    }
    return (last != null && isFinite(last)) ? last : null;
  };
  const fxs = Array.isArray(rfr.fixings) ? rfr.fixings : [];
  if(!fxs.length) return null;
  const sorted = fxs.slice().sort((a,b) => (a.date||'').localeCompare(b.date||''));
  const lastActual = sorted[sorted.length - 1].date;
  if(dateISO <= lastActual) return pick(sorted);          // inside the actuals
  const fc = pick(rfr.forecast);
  if(fc != null) return fc;                               // forecast beyond
  return pick(sorted);                                    // held flat
}
if(typeof window !== 'undefined') window.rfrRateOn = rfrRateOn;

/* The last day with an ACTUAL fixing — the cutover. Exposed so the UI can say
   "observed to 17 Sep 2026, forecast thereafter" instead of leaving the reader
   to work out which part of a 35-year schedule was ever observed. */
/* True when the forecast in force on this day is an ALL-IN rate — the coupon
   itself, margin already included — rather than a bare benchmark.

   Only meaningful on days the forecast actually covers. Inside the actual
   fixings, and beyond the curve's last point, the rate is a benchmark and the
   margin applies as normal; treating those days as all-in would strip a margin
   that was never in the number.

   The distinction is worth this much care because it is invisible in the data:
   a 6% all-in rate and a 6% benchmark are the same number, and the only thing
   that says which is which is the curve it came from. Read one as the other
   and every deal on the index is wrong by its margin, every day, with nothing
   on screen to show it. */
function rfrForecastIsAllIn(instr, dateISO){
  const rfr = instr && instr.rfr;
  if(!rfr) return false;
  if((rfr.forecastBasis || 'benchmark') !== 'all_in') return false;
  return rfrRateSourceOn(instr, dateISO) === 'forecast';
}
if(typeof window !== 'undefined') window.rfrForecastIsAllIn = rfrForecastIsAllIn;

function rfrLastActualDate(instr){
  const fxs = instr && instr.rfr && instr.rfr.fixings;
  if(!Array.isArray(fxs) || !fxs.length) return null;
  return fxs.slice().sort((a,b) => (a.date||'').localeCompare(b.date||''))[fxs.length-1].date;
}
if(typeof window !== 'undefined') window.rfrLastActualDate = rfrLastActualDate;

/* True when PIK runs at any point in the deal's life. A schedule whose bands
   are all zero is not a PIK deal; one with a single non-zero band is, even if
   the rate today is nil. Getting this wrong in either direction is costly: too
   eager and every deal grows a PIK apparatus it never uses, too strict and the
   amendment year never capitalises. */
function pikEverEnabled(instr){
  const p = instr && instr.pik;
  if(!p || p.enabled === false) return false;
  if((+p.rate || 0) > 0) return true;
  if((+p.baseRate || 0) > 0) return true;
  const sched = p.schedule;
  if(Array.isArray(sched) && sched.some(b => b && Math.abs(+(b.marginBps != null ? b.marginBps : b.bps) || 0) > 0)) return true;
  return !!p.enabled && (+p.rate || 0) > 0;
}
if(typeof window !== 'undefined') window.pikEverEnabled = pikEverEnabled;

function deriveModificationGainLoss(instr, o){
  const modDate = o && o.modDate;
  const originalEIR = o && o.originalEIR;
  const daysPerYear = (o && o.daysPerYear) || 360;
  if(!modDate || originalEIR == null || !isFinite(originalEIR) || originalEIR <= -0.99) return null;
  const start = parseISO(modDate);
  const end   = parseISO(instr.maturityDate);
  if(!start || !end || end <= start) return null;

  /* Post-modification nominal coupon. Read AFTER the caller has applied the
     event's newCoupon, so this is the revised rate, not the original one. */
  const c = instr.coupon || {};
  let rate = 0;
  if(c.type === 'Fixed') rate = +c.fixedRate || 0;
  else rate = ((+c.floatingRate || 0) || ((instr.rfr && +instr.rfr.baseRate) || 0)) + (+c.spread || 0);
  /* A banded margin is the revised rate when one covers the modification date.
     Without this the derivation discounted the revised cash flows at the rate
     in force BEFORE the amendment — so the one change the calculation exists
     to measure was the one input it could not see. The band replaces the
     constant spread rather than adding to it: on a non-Fixed coupon `spread`
     is the fallback for "no band was given", so counting both would apply the
     margin twice. */
  const _modBandBps = bandBpsOn(instr.marginSchedule, modDate);
  if(_modBandBps != null){
    rate = (c.type === 'Fixed')
      ? (+c.fixedRate || 0) + _modBandBps / 10000
      : ((+c.floatingRate || 0) || ((instr.rfr && +instr.rfr.baseRate) || 0)) + _modBandBps / 10000;
  }
  if(c.floor != null) rate = Math.max(rate, +c.floor);
  if(c.cap   != null) rate = Math.min(rate, +c.cap);

  /* Principal movements. Three kinds, and the distinction matters:
       draw        — lender pays out, balance up    → NEGATIVE cash flow
       repayment   — lender receives, balance down  → POSITIVE cash flow
       write-off   — forgiveness, balance down      → NO cash flow at all
     Treating forgiveness as a receipt would turn a loss into a wash, which is
     precisely the error this function exists to prevent. */
  const cashIn = {}, balanceOnly = {};
  let openingWriteOff = 0;
  const bump = (m, iso, amt) => { if(amt) m[iso] = (m[iso] || 0) + amt; };
  for(const e of (instr.principalSchedule || [])){
    if(!e || !e.date || e.date < modDate) continue;
    const amt = Math.abs(+e.amount || 0);
    if(!amt) continue;
    const ty = String(e.type || '');
    if(ty === 'writeOff' || ty === 'forgiveness'){
      // A write-off dated ON the modification date is part of the restructuring
      // itself: it reduces the balance the revised cash flows are projected on.
      if(e.date === modDate) openingWriteOff += amt;
      else bump(balanceOnly, e.date, -amt);
      continue;
    }
    if(e.date === modDate) continue;      // other same-day events already in `balance`
    if(ty === 'draw' || ty === 'initialPurchase')                         bump(cashIn, e.date, -amt);
    else if(/^(paydown|repayment|prepayment|mandatoryPrepayment)$/.test(ty)) bump(cashIn, e.date,  amt);
  }

  /* Fees paid between the parties are part of the revised cash flows
     (IFRS 9 §B5.4.6) — an amendment fee received on the modification date
     belongs in the discounting, not in income on receipt. */
  const base = (+instr.commitment || +instr.faceValue || 0);
  for(const f of (instr.fees || [])){
    if(!f || !f.paymentDate || f.paymentDate < modDate) continue;
    const mode = String(f.mode || '');
    const amt = (mode === 'fixed' || mode === 'fixAmount')
      ? (+f.amount || +f.flatAmount || 0)
      : ((+f.rate || +f.pct || 0) * base);
    if(amt) bump(cashIn, f.paymentDate, amt);
  }

  // Interest payment dates across the revised horizon.
  const freq = String(instr.couponFrequency || 'quarterly').toLowerCase();
  const sched = generatePaymentSchedule(start, freq, end, instr.holidayCalendar, instr.rollConvention) || [];
  const endISO = toISO(end);
  const payable = new Set(sched.map(s => s.paymentDate).filter(dt => dt > modDate));
  payable.add(endISO);                    // the final coupon always settles at maturity

  /* Walk the revised horizon, accruing interest and collecting dated flows.

     The walk starts the day AFTER the modification, so anything falling ON the
     modification date has to be taken first or it is silently lost. An
     amendment fee received on the day of the restructuring is the ordinary
     case, not an edge case — dropping it understated the gain by the whole
     fee. It discounts at t=0, so it enters at face. */
  /* When the caller has already applied the concession to the balance it hands
     in, subtracting it again here would halve the projected recovery and double
     the reported loss. */
  let bal = o.forgivenessApplied
    ? Math.max(0, (+o.balance || 0))
    : Math.max(0, (+o.balance || 0) - openingWriteOff);
  let accrued = 0;
  const flows = [];
  if(Math.abs(cashIn[modDate] || 0) > 0.005){
    flows.push({ date: modDate, amount: cashIn[modDate] });
  }

  /* Interest settled in kind is NOT a cash receipt. It capitalises into the
     balance and comes back as a larger repayment later — which is the whole
     economic point of a PIK amendment, and the reason exposure at default
     rises. Discounting it as though it were received quarterly in cash would
     erase the deferral the modification was granted to achieve, and report no
     loss on the very change that caused one. */
  /* The PIK rate as at the modification date, not at inception. On a deferral
     amendment these are the two numbers least likely to agree: PIK is commonly
     nil before the concession and the whole point of it afterwards. Reading the
     inception scalar projected a cash-only loan and reported no loss on the
     very change that caused one. */
  const pikRate = pikEverEnabled(instr) ? Math.max(0, pikRateOn(instr, modDate)) : 0;
  let pikAccrued = 0;
  const pikDates = pikRate > 0
    ? new Set((generatePaymentSchedule(
        start,
        String((instr.pik && (instr.pik.capitalizationFrequency || instr.pik.freq)) || 'quarterly').toLowerCase(),
        end, instr.holidayCalendar, instr.rollConvention) || []
      ).map(s => s.paymentDate))
    : new Set();

  for(let dd = addDays(start, 1); dd <= end; dd = addDays(dd, 1)){
    const iso = toISO(dd);
    accrued += bal * rate / daysPerYear;
    if(pikRate > 0){
      pikAccrued += bal * pikRate / daysPerYear;
      if(pikDates.has(iso) || iso === endISO){ bal += pikAccrued; pikAccrued = 0; }
    }
    let cash = cashIn[iso] || 0;
    if(payable.has(iso)){ cash += accrued; accrued = 0; }
    bal += (balanceOnly[iso] || 0) - (cashIn[iso] > 0 ? cashIn[iso] : 0)
         + (cashIn[iso] < 0 ? -cashIn[iso] : 0);
    if(bal < 0) bal = 0;
    if(Math.abs(cash) > 0.005) flows.push({ date: iso, amount: cash });
    if(flows.length > 5000) break;        // safety on a very long-dated loan
  }
  // Anything still outstanding at maturity is contractually repayable.
  if(bal > 0.005) flows.push({ date: endISO, amount: bal });

  // Discount at the ORIGINAL EIR. Not the revised one — that is the whole
  // point of §5.4.3: the rate is held, the cash flows move.
  let pv = 0;
  for(const f of flows){
    const t = Math.round((parseISO(f.date) - start) / ONE_DAY) / daysPerYear;
    pv += f.amount / Math.pow(1 + originalEIR, t);
  }
  const carrying = +o.carrying || 0;
  const gainLoss = pv - carrying;
  return {
    gainLoss,
    pv,
    preModCarrying: carrying,
    originalEIR,
    couponAfterMod: rate,
    forgivenAtMod: openingWriteOff,
    flowCount: flows.length,
    firstFlow: flows.length ? flows[0].date : null,
    lastFlow:  flows.length ? flows[flows.length-1].date : null,
    // §5.4.3's 10% test: the PV change against the pre-modification carrying
    // amount is what decides substantial vs non-substantial.
    pvChangePct: carrying ? (gainLoss / carrying) * 100 : null
  };
}
if(typeof window !== 'undefined') window.deriveModificationGainLoss = deriveModificationGainLoss;

/* ---------- Core schedule builder ----------
   Walks the day grid from settlement → maturity and maintains:
     balance              (principal outstanding, includes PIK capitalizations)
     drawnBalance         (for revolvers: actually drawn portion)
     carryingValue        (used by effective-interest / straight-line methods)
     cumInterest, cumPIK  (tracker for capitalization)
-------------------------------------------------- */
// ─── Transtype #17 — Multiple Amortisation Profiles ────────────────────
// Expand a high-level amortProfile spec into explicit principalSchedule
// paydown events. Supported profile kinds:
//
//   • 'bullet'         — single repayment at maturity (no-op; default)
//   • 'levelPrincipal' — equal principal payments across N periods
//                        E.g. $10m / 20 quarters = $500k each quarter
//   • 'annuity'        — equal total payments (P+I); engine computes the
//                        principal carve-out per period using the contract
//                        rate at start (approximation — real annuity would
//                        rely on the actual rate at each period date)
//   • 'ioBalloon'      — interest-only for ioMonths, then full balloon
//                        at maturity. Common for bridge / project finance.
//
// The expander only runs when amortProfile is set AND principalSchedule
// doesn't already contain explicit paydowns (so user-supplied schedules
// take precedence — backward compatible with all existing seeds).
function expandAmortProfile(instr){
  const prof = instr.amortProfile;
  if(!prof || !prof.kind || prof.kind === 'bullet') return;
  const sched = Array.isArray(instr.principalSchedule) ? instr.principalSchedule : [];
  const hasExplicitPaydown = sched.some(e => e.type === 'paydown' || e.type === 'repayment');
  if(hasExplicitPaydown) return;   // user already specified — don't double up

  const face = +instr.faceValue || +instr.commitment || 0;
  if(face <= 0) return;
  const settle   = new Date(instr.settlementDate);
  const maturity = new Date(instr.maturityDate);
  if(isNaN(settle) || isNaN(maturity) || maturity <= settle) return;

  const balloon = Math.max(0, +prof.balloon || 0);
  const amortAmount = face - balloon;        // amount to amortise across periods

  // Step interval in months between paydowns: 'M'=1, 'Q'=3, 'S'=6, 'A'=12
  const stepMonths = { M:1, Q:3, S:6, A:12 }[prof.frequency || 'Q'] || 3;
  const ioMonths   = Math.max(0, +prof.ioMonths || 0);
  // First amort date: ioMonths after settle (or explicit profile.startDate)
  const firstAmort = prof.startDate
    ? new Date(prof.startDate)
    : new Date(settle.getFullYear(), settle.getMonth() + ioMonths + stepMonths, settle.getDate());

  // Enumerate period-end dates from firstAmort to maturity inclusive
  const periodDates = [];
  let d = new Date(firstAmort);
  while(d < maturity){
    periodDates.push(new Date(d));
    d = new Date(d.getFullYear(), d.getMonth() + stepMonths, d.getDate());
  }
  const nPeriods = periodDates.length;
  if(nPeriods === 0){
    // No room for periodic paydowns — fall through to bullet at maturity
    sched.push({ date: instr.maturityDate, type:'paydown', amount: face, _generated:true, _profile: prof.kind });
    instr.principalSchedule = sched;
    return;
  }

  // Generate paydowns by kind
  const paydowns = [];
  if(prof.kind === 'levelPrincipal'){
    const perPeriod = amortAmount / nPeriods;
    periodDates.forEach((pd, i) => {
      paydowns.push({ date: pd.toISOString().slice(0,10), type:'paydown', amount: round2(perPeriod),
                      _generated:true, _profile:'levelPrincipal', _idx: i+1 });
    });
  } else if(prof.kind === 'annuity'){
    // Annuity formula: PMT = P × r/(1−(1+r)^-N)  where r = periodic rate
    const annualRate = (instr.coupon && (instr.coupon.fixedRate || (instr.coupon.floatingRate||0) + (instr.coupon.spread||0))) || 0;
    const r = annualRate * stepMonths / 12;
    const PMT = (r === 0) ? (amortAmount / nPeriods) : (amortAmount * r / (1 - Math.pow(1+r, -nPeriods)));
    let outstanding = amortAmount;
    periodDates.forEach((pd, i) => {
      const interestThisPd = outstanding * r;
      const principalThisPd = Math.max(0, PMT - interestThisPd);
      const cappedPrincipal = (i === nPeriods - 1) ? outstanding : Math.min(principalThisPd, outstanding);
      outstanding -= cappedPrincipal;
      paydowns.push({ date: pd.toISOString().slice(0,10), type:'paydown', amount: round2(cappedPrincipal),
                      _generated:true, _profile:'annuity', _idx: i+1 });
    });
  } else if(prof.kind === 'ioBalloon'){
    // Single balloon at maturity (no intermediate paydowns).
    paydowns.push({ date: instr.maturityDate, type:'paydown', amount: round2(face),
                    _generated:true, _profile:'ioBalloon', _idx: 1 });
  }

  // Add the balloon repayment at maturity (after the last period paydown) for
  // levelPrincipal / annuity if balloon > 0
  if(balloon > 0 && (prof.kind === 'levelPrincipal' || prof.kind === 'annuity')){
    paydowns.push({ date: instr.maturityDate, type:'paydown', amount: round2(balloon),
                    _generated:true, _profile: prof.kind + '_balloon' });
  }

  instr.principalSchedule = sched.concat(paydowns);
}
function round2(x){ return Math.round(x * 100) / 100; }

// ---------------------------------------------------------------------------
// applyCovenantSideEffects — Phase A medium-scope covenants
//
// Reads instr.covenants[] and returns an enriched array tagging each covenant
// with status (compliant / headroomWarning / breached), breachDate,
// curePeriodEndDate, and a stable identity (covIdentity) used for idempotent
// event synthesis. Pure function — does not mutate instr.
//
// Inputs per covenant (DB / Builder shape, both supported):
//   kpiMetric / name           — what's being measured
//   threshold                  — numeric limit
//   direction                  — 'max' | 'min' | 'maximum' | 'minimum' | '≤' | '≥' | '=='
//   lastReportedValue          — most recent observation (number or string-numeric)
//   reportDate / lastTestDate  — date the observation was taken (fallback = settle)
//   curePeriodDays             — days from breach to consequence trigger (default 0)
//   breachStepUpBps            — margin uplift in bps if marginStepUp is in consequenceOnBreach
//   consequenceOnBreach        — string OR comma-list of: 'sicrTrigger', 'marginStepUp',
//                                'mandatoryPrepayment', 'acceleration', 'eventOfDefault'
//   headroomWarnPct            — % below threshold at which to tag headroomWarning (default 0.10)
//
// Returns: covenants array with added { status, headroomPct, breachDate,
//   curePeriodEndDate, covIdentity, consequenceList[] }.
// ---------------------------------------------------------------------------
function applyCovenantSideEffects(instr){
  const list = Array.isArray(instr && instr.covenants) ? instr.covenants : [];
  if(!list.length) return [];
  const settleISO = instr.settlementDate || '1970-01-01';
  return list.map((c, idx) => {
    const enriched = Object.assign({}, c);
    const val = (c.lastReportedValue != null) ? +c.lastReportedValue : null;
    const thr = (c.threshold != null) ? +c.threshold : null;
    const dir = String(c.direction || c.testDirection || 'max').toLowerCase();
    const warnPct = (c.headroomWarnPct != null) ? +c.headroomWarnPct : 0.10;
    let breached = false, headroomWarning = false, headroomPct = null;
    if(val != null && thr != null && !isNaN(val) && !isNaN(thr)){
      if(dir === 'max' || dir === 'maximum' || dir === '≤' || dir === '<=' || dir === 'lte'){
        breached = val > thr;
        if(!breached && thr !== 0){
          headroomPct = (thr - val) / Math.abs(thr);
          headroomWarning = headroomPct < warnPct;
        }
      } else if(dir === 'min' || dir === 'minimum' || dir === '≥' || dir === '>=' || dir === 'gte'){
        breached = val < thr;
        if(!breached && thr !== 0){
          headroomPct = (val - thr) / Math.abs(thr);
          headroomWarning = headroomPct < warnPct;
        }
      } else if(dir === '==' || dir === 'equal' || dir === 'eq'){
        breached = val !== thr;
      }
    }
    enriched.status = breached ? 'breached' : (headroomWarning ? 'headroomWarning' : 'compliant');
    enriched.headroomPct = headroomPct;
    // Breach date: prefer explicit breach_date, then last reported/test date, then settle
    const breachDate = c.breachDate || c.breach_date
                     || c.lastReportedDate || c.last_reported_date
                     || c.lastTestDate || c.last_test_date
                     || c.reportDate || c.report_date
                     || c.nextTestDate || c.next_test_date
                     || c.firstTestDate || c.first_test_date
                     || settleISO;
    enriched.breachDate = breached ? breachDate : null;
    // Cure period end = breachDate + curePeriodDays (default 0 = take effect immediately)
    const cureDays = +(c.curePeriodDays ?? c.cure_period_days ?? 0) || 0;
    if(breached){
      if(cureDays > 0){
        const d = new Date(breachDate + 'T00:00:00Z');
        d.setUTCDate(d.getUTCDate() + cureDays);
        enriched.curePeriodEndDate = d.toISOString().slice(0,10);
      } else {
        enriched.curePeriodEndDate = breachDate;
      }
    } else {
      enriched.curePeriodEndDate = null;
    }
    // Normalise consequence into a list for easier matching
    const consRaw = c.consequenceOnBreach || c.consequence_on_breach || c.consequence || '';
    const consList = Array.isArray(consRaw)
      ? consRaw.map(String)
      : String(consRaw).split(/[,;|]/).map(s => s.trim()).filter(Boolean);
    enriched.consequenceList = consList;
    // Stable identity for idempotent event synthesis across re-invocations
    enriched.covIdentity = c.id || c.covenant_id || c.name
      || ((c.kpiMetric || c.kpi_metric || 'covenant') + ':' + (c.threshold ?? idx) + ':' + idx);
    return enriched;
  });
}

function buildSchedule(instr){
  if(!instr) return [];

  // Resolve OID/Premium treatment first — if oidTreatment is set (or auto
  // resolves to oid/premium given PP vs FV), apply amortization.method so the
  // existing dailyAmort path engages. This produces the separate "Discount
  // Accretion" / "Premium Amortization" JE pair already wired in generateDIU.
  instr = applyOIDOverrideToAmortMethod(instr);

  // Transtype #17 — Expand any amortProfile into explicit principalSchedule
  // paydowns. Operates in-place; safe for repeat invocations because the
  // expander short-circuits when explicit paydowns already exist.
  if(instr.amortProfile && instr.amortProfile.kind && instr.amortProfile.kind !== 'bullet'){
    // Clone so we don't mutate the user's INSTRUMENTS entry on repeated calls
    instr = Object.assign({}, instr, { principalSchedule: (instr.principalSchedule || []).slice() });
    expandAmortProfile(instr);
  }

  // ---- Multi-tranche / multi-underlying support -------------------------
  // If instr.tranches is non-empty (a loan with fixed + floating tranches in
  // one transaction) OR instr.underlyingLoans is non-empty (a guarantee
  // covering multiple loans), recursively build a schedule per sub-instrument
  // and aggregate row-by-row. Each sub-instrument inherits the parent's
  // settlement/maturity and identifying fields unless overridden.
  // Closes scenarios #10 (fixed+floating mix) and G1 (multiple underlyings).
  const subs = (Array.isArray(instr.tranches) && instr.tranches.length)
    ? instr.tranches
    : (Array.isArray(instr.underlyingLoans) && instr.underlyingLoans.length)
      ? instr.underlyingLoans
      : null;
  if(subs){
    // Build schedule for each sub-instrument with parent context inherited
    const subSchedules = subs.map(s => {
      const merged = Object.assign({}, instr, s);
      // Don't recurse infinitely
      delete merged.tranches;
      delete merged.underlyingLoans;
      // Each sub keeps its own coupon, marginSchedule, principalSchedule, etc.
      return buildSchedule(merged);
    });
    // Aggregate row-by-row by date. Use the longest sub's date list as the
    // canonical day grid (all subs share parent settle/maturity so all grids
    // are equal length).
    const longest = subSchedules.reduce((a,b) => b.length > a.length ? b : a, subSchedules[0]);
    const aggregated = [];
    const SUM_KEYS = ['balance','drawnBalance','carryingValue','initialPurchase','draw','paydown',
                      'dailyCash','cumInterestAccrued','cumInterestEarned',
                      'capitalized','cashInterestPayment','dailyPik','cumPikAccrued','cumPikEarned',
                      'pikPaydown','amortDaily','cumAmort','nonUseFee','cumNonUseFee',
                      'dailyFees','dailyEIRAccretion','cumEIRAccretion',
                      'dailyDefaultInterest','dailyDefaultFee','cumDefaultInterest','cumDefaultFee'];
    for(let k = 0; k < longest.length; k++){
      const date = longest[k].date;
      const r = { date, jsDate: longest[k].jsDate, dayOfWeek: longest[k].dayOfWeek,
                  feeBreakdown: {}, hasEvent: false,
                  // weighted-average rate placeholders
                  couponRate: 0, floatingRate: 0, currentRate: 0, pikRate: 0 };
      for(const key of SUM_KEYS) r[key] = 0;
      let totalBal = 0;
      for(const sched of subSchedules){
        const sr = sched[k]; if(!sr) continue;
        for(const key of SUM_KEYS){ r[key] += (sr[key] || 0); }
        totalBal += (sr.balance || 0);
        r.hasEvent = r.hasEvent || sr.hasEvent;
        // merge per-fee breakdown
        if(sr.feeBreakdown){
          for(const [fk,fv] of Object.entries(sr.feeBreakdown)){
            r.feeBreakdown[fk] = (r.feeBreakdown[fk] || 0) + (fv || 0);
          }
        }
      }
      // Weighted-average rates by balance
      if(totalBal > 0){
        for(const sched of subSchedules){
          const sr = sched[k]; if(!sr || !sr.balance) continue;
          const w = sr.balance / totalBal;
          r.couponRate   += (sr.couponRate   || 0) * w;
          r.floatingRate += (sr.floatingRate || 0) * w;
          r.currentRate  += (sr.currentRate  || 0) * w;
          r.pikRate      += (sr.pikRate      || 0) * w;
        }
      }
      aggregated.push(r);
    }
    // Aggregate per-fee accumulation across sub-schedules
    const aggFeeBreakdown = [];
    const seen = new Map();
    for(const sched of subSchedules){
      for(const f of (sched.feeBreakdown || [])){
        const key = f.label;
        if(!seen.has(key)){
          seen.set(key, { label:f.label, ifrs:f.ifrs, cumAccrued: 0, cumRecognised: 0, cumPaid: 0 });
          aggFeeBreakdown.push(seen.get(key));
        }
        seen.get(key).cumAccrued += f.cumAccrued || 0;
      }
    }
    aggregated.feeBreakdown = aggFeeBreakdown;
    aggregated.deferredEIRPool = subSchedules.reduce((a,s) => a + (s.deferredEIRPool || 0), 0);
    aggregated.tranchesUsed = subs.map(s => s.id || s.label);
    return aggregated;
  }

  const settle   = parseISO(instr.settlementDate);
  const maturity = parseISO(instr.maturityDate);
  if(!settle || !maturity || maturity < settle) return [];

  const basis = instr.dayBasis || 'ACT/360';

  // ----- Phase A medium covenants — derive side-effects + synth events ----
  const enrichedCovenants = applyCovenantSideEffects(instr);
  // Set of consequence-bearing breached covenants for fast lookup in helpers
  const breachedCovs = enrichedCovenants.filter(c => c.status === 'breached');
  // Phase A #4 — Mandatory prepayment synthesis on covenant acceleration.
  // For any breached covenant with consequence ∈ {mandatoryPrepayment,
  // acceleration, eventOfDefault}, push a synthetic event into
  // instr.principalSchedule. The actual amount is materialised inside the
  // event loop (set to current balance at trigger date), so partial paydowns
  // earlier in the schedule don't get over- or under-counted. Idempotent —
  // skipped when a matching event already exists. Stale synth events
  // (covenant cured / removed) are stripped on each call.
  const accelCovs = breachedCovs.filter(c =>
    c.consequenceList.includes('mandatoryPrepayment')
    || c.consequenceList.includes('acceleration')
    || c.consequenceList.includes('eventOfDefault'));
  const accelCovIds = new Set(accelCovs.map(c => c.covIdentity));
  instr.principalSchedule = instr.principalSchedule || [];
  // Strip stale synth events whose covenant is no longer breached / present
  instr.principalSchedule = instr.principalSchedule.filter(e =>
    !(e && e._covenantSynthesised && e.type === 'mandatoryPrepayment'
      && !accelCovIds.has(e._covenantIdentity)));
  // Add fresh synth events for any newly-breached accelerating covenants
  for(const c of accelCovs){
    const accelDate = c.curePeriodEndDate || c.breachDate;
    const already = instr.principalSchedule.some(e =>
      e && e._covenantSynthesised && e._covenantIdentity === c.covIdentity
      && e.type === 'mandatoryPrepayment');
    if(!already && accelDate){
      instr.principalSchedule.push({
        type: 'mandatoryPrepayment',
        date: accelDate,
        amount: 0,                            // materialised in loop = balance at trigger
        kind: 'covenantBreach',
        trigger: 'covenantBreach',
        reason: 'Covenant breach acceleration: ' + (c.name || c.kpiMetric || c.kpi_metric || 'unnamed'),
        _covenantSynthesised: true,
        _covenantIdentity: c.covIdentity,
      });
    }
  }

  // Helper: total margin step-up bps active on a given date across all
  // breached covenants with a non-zero breachStepUpBps. Active window:
  // [breachDate, curePeriodEndDate]. Multiple breached covenants stack.
  //
  // Phase C bugfix — apply step-up whenever breachStepUpBps > 0, regardless of
  // whether 'marginStepUp' is the named consequence. Real-world contracts
  // commonly pair sicrTrigger with a rate uplift (e.g. "breach forces SICR
  // for accounting AND adds 150bps to the spread"). Treating the bps field
  // as the sole authoritative signal removes the ambiguity.
  const covenantMarginStepBpsOn = (dateISO) => {
    let total = 0;
    for(const c of breachedCovs){
      const bps = +(c.breachStepUpBps ?? c.breach_step_up_bps ?? 0) || 0;
      if(bps <= 0) continue;
      if(dateISO < c.breachDate) continue;
      // After cure period ends, the step-up persists until next test cycle.
      // For Phase A we keep step-up live from breach onward (no auto-cure
      // without a fresh observation). Phase B adds the breach-log + cure date
      // wiring that lets us turn this off.
      total += bps;
    }
    return total;
  };

  // Helper: SICR active when any breached covenant has consequence sicrTrigger
  // (or any of: marginStepUp + an explicit sicrTrigger tag). Per IFRS 9 §B5.5.17
  // and ASC 326-20-30-2, a covenant breach is a presumptive SICR indicator —
  // the user opts in by configuring sicrTrigger on the covenant.
  const covenantSICRActiveOn = (dateISO) => {
    for(const c of breachedCovs){
      if(!c.consequenceList.includes('sicrTrigger')) continue;
      if(dateISO >= c.breachDate) return true;
    }
    return false;
  };

  const events = (instr.principalSchedule||[]).slice().sort((a,b)=> a.date.localeCompare(b.date));

  // For revolvers / loans the "balance" starts at initial draw (first event w/ type=draw at settle) or faceValue.
  // Facility / deferred-drawdown case: if the principalSchedule has draws AFTER
  // settlement and NO initial/draw event at settlement, the loan starts at
  // zero balance (e.g. SP023 / Libra 2 — signed Oct 2024, first draw Feb 2026).
  const initialDraw = events.find(e => e.date===toISO(settle) && (e.type==='draw' || e.type==='initial'));
  const hasFutureDraws = events.some(e => e.type === 'draw' && e.date > toISO(settle));
  let balance;
  if(initialDraw)            balance = initialDraw.amount;
  else if(hasFutureDraws)    balance = 0;       // facility with deferred drawdown
  else                       balance = instr.faceValue || 0;
  // BUGFIX: when initialDraw is a `type='draw'` event (not 'initial'), the
  // loop below would add its amount AGAIN, double-counting the draw. Mark it
  // so the loop skips it on the matched settle-date row.
  if(initialDraw && initialDraw.type === 'draw') initialDraw._consumedAsInitial = true;
  let drawnBalance  = balance;
  const commitment  = instr.commitment ?? instr.faceValue;

  // Carrying value start — mirror the balance-init logic so partially-drawn
  // facilities don't seed carrying at face while balance starts at drawn.
  // Historically this was `purchasePrice ?? faceValue` on the assumption that
  // the loan was fully funded at close (buyer paid purchasePrice for the
  // whole face). For deals with drawn_initially < face + post-close drawdowns,
  // that seeded carrying at face and then the daily loop added each drawdown
  // again → carrying peaked at face + Σdrawdowns instead of tracking balance.
  // Precedence:
  //   1. explicit purchasePrice (secondary purchase / debt-for-equity acquisition)
  //   2. actual initialDraw amount (funded-at-close portion)
  //   3. 0 (deferred-draw facility, no initial funding)
  //   4. faceValue (legacy default when the caller doesn't hand us any draw events)
  let carryingValue;
  if(instr.purchasePrice != null)  carryingValue = +instr.purchasePrice;
  else if(initialDraw)             carryingValue = initialDraw.amount;
  else if(hasFutureDraws)          carryingValue = 0;
  else                             carryingValue = instr.faceValue || 0;

  /* ─── Fees, costs and the opening carrying amount ────────────────────────
     Hoisted ABOVE the effective-yield solve on purpose. The rate has to be
     solved against the amount actually invested — consideration net of
     yield-integral fees received and gross of transaction costs — so that
     figure must exist before the solver runs. Computing it afterwards (as this
     did originally) leaves the solve anchored to the headline price while the
     daily roll-forward starts somewhere else, and the two never reconcile.

     Fee shapes accepted:
       mode 'flat'/'fixed' + oneOff  — a stated amount (v0.4/v0.5 flat amounts)
       mode 'percent'     + oneOff  — a rate applied to a stated base           */
  const fees = Array.isArray(instr.fees) ? instr.fees : [];
  const feeAccum = fees.map(f => ({
    id: f.id, kind: f.kind, label: f.label || f.kind, ifrs: f.ifrs || 'IFRS15-overTime',
    cumAccrued: 0, cumRecognised: 0, cumPaid: 0
  }));
  const totalLifeDays = Math.max(1, Math.round((maturity - settle)/ONE_DAY));
  // For IFRS9-EIR fees: deferred income at t0 = sum(flat one-off) + 0 (% accrue daily over life)
  let deferredEIRPool = 0;
  /* On a facility that is undrawn at settlement the fee cannot reduce a
     carrying amount that is still nil — doing so opens the asset at MINUS the
     fee, which is not a conservative presentation but an impossible one, and
     it sends the EIR solve looking for a yield on a negative investment. The
     reduction is held here and applied on the first drawdown instead, which is
     also when the deferred fee liability is released. */
  const _drawnAtSettle = balance > 0.005;
  let pendingEIRFeeOffset = 0;
  for(const f of fees){
    // Accept both 'flat' (engine-native) and 'fixed' (v3 builder mapping of 'fixAmount').
    if(/EIR$/.test(f.ifrs || '') && (f.mode === 'flat' || f.mode === 'fixed') && f.frequency === 'oneOff'){
      deferredEIRPool += (f.amount || 0);
      // Reduce initial carrying value by the deferred fee (cash received at signing
      // is offset against carrying amount; it accretes back into interest income).
      if(_drawnAtSettle) carryingValue -= (f.amount || 0);
      else               pendingEIRFeeOffset += (f.amount || 0);
    } else if(/EIR$/.test(f.ifrs || '') && f.mode === 'percent' && f.frequency === 'oneOff'){
      const baseAmt = ((b)=>{
        if(b==='commitment') return commitment;
        if(b==='face')       return instr.faceValue || 0;
        if(b==='drawn')      return drawnBalance;
        if(b==='covered')    return instr.coveredAmount || 0;
        return commitment;
      })(f.base);
      const oneOff = baseAmt * (f.rate || 0);
      deferredEIRPool += oneOff;
      if(_drawnAtSettle) carryingValue -= oneOff;
      else               pendingEIRFeeOffset += oneOff;
    }
  }
  /* IFRS 9 measures a financial asset initially at fair value PLUS directly
     attributable transaction costs, so costs raise the opening carrying amount
     and therefore the effective yield — the mirror image of a fee received,
     which lowers it. Both belong in the same number. */
  const txnCosts = +instr.transactionCosts || 0;
  if(txnCosts) carryingValue += txnCosts;

  /* The amount actually invested. On the Harbour Point example:
        59,100,000 paid  −  600,000 arrangement fee  +  185,000 costs
      = 58,685,000
     Captured once, so the solver and the daily roll-forward can never be
     anchored to two different opening balances. */
  const eirOpeningCarrying = carryingValue;
  /* The balance that opening carrying amount corresponds to. Both already
     reflect the day-zero funding, so the yield walk must start from this pair
     and apply only the movements that come AFTER settlement — re-applying the
     initial draw would count it twice and send the solve to a negative rate. */
  const eirOpeningBalance = balance;

  // Precompute total life (years) and a rough cashflow set for IRR methods.
  // For SONIA / CompoundedRFR coupons the fixedRate is 0 — derive an
  // indicative coupon from the rfr base + first margin step + ESG adj so the
  // EIR solver can still project cashflows.
  const totalDays = Math.round((maturity-settle)/ONE_DAY);
  let couponRateNominal = instr.coupon?.fixedRate ?? 0;
  /* Any coupon that is not Fixed carries its rate in floatingRate + spread (or,
     when no observed level was supplied, rfr.baseRate + spread) — fixedRate is
     zero on all of them.

     This used to name only SONIA and CompoundedRFR. builderToInstrument maps
     SOFR, TermSOFR, EURIBOR, ESTR, BBSW and anything else that is not FIXED to
     type 'Floating', so every one of those deals ran with a NOMINAL COUPON OF
     ZERO: no EIR was solved, the schedule reported "coupon" with a contractual
     rate of 0.00%, and anything downstream that discounts at the original EIR
     — the §5.4.3 modification derivation above all — discounted at nil and
     returned a present value several times the carrying amount. On the Stage 3
     demo deal that produced a modification gain of 154,859,350 against a true
     figure of 12,022,928. Silent, and plausible enough to ship. */
  /* The rate AT SETTLEMENT, because this is the rate the ORIGINAL effective
     interest rate is solved on, and the original EIR is fixed at initial
     recognition (IFRS 9 §B5.4.1). A later band is either a contractual step —
     which belongs in a multi-step projection, not in this scalar — or a
     concession, which must NOT contaminate the original EIR, or §5.4.3 would
     discount the revised cash flows at a rate that already contains the
     revision and report no gain or loss by construction. */
  const _settleISO = toISO(settle);
  if(instr.coupon && (instr.coupon.type === 'Fixed' || !instr.coupon.type)){
    const bps = bandBpsOn(instr.marginSchedule, _settleISO);
    if(bps != null) couponRateNominal = (instr.coupon.fixedRate ?? 0) + bps / 10000;
  }
  if(!couponRateNominal && instr.coupon && instr.coupon.type !== 'Fixed'){
    const base = (instr.coupon.floatingRate != null && instr.coupon.floatingRate !== 0)
      ? instr.coupon.floatingRate
      : (instr.rfr?.baseRate ?? 0);
    /* Was `marginSchedule[0]` — the first band in array order, which is only
       the band in force at settlement if the list happens to be sorted. It
       often is not: these arrive from a UI list and from a database with no
       ORDER BY on the band table, so a deal whose amendment-year concession
       was stored first priced its entire life off the concession. */
    const bandBps   = bandBpsOn(instr.marginSchedule, _settleISO);
    const marginBps = (bandBps != null) ? bandBps : ((instr.coupon.spread ?? 0) * 10000);
    const esgBps    = instr.esgAdjustment?.deltaBps ?? 0;
    let r = base + (marginBps + esgBps)/10000;
    if(instr.coupon.floor != null) r = Math.max(r, instr.coupon.floor);
    if(instr.coupon.cap   != null) r = Math.min(r, instr.coupon.cap);
    couponRateNominal = r;
  }

  // Effective interest yield (y):
  //   method effectiveInterestPrice  -> solve from PP
  //   method effectiveInterestFormula-> yield = coupon + spread (user-supplied)
  //   method effectiveInterestIRR    -> explicit yield input
  //   method straightLine            -> no y — amortize linearly
  let effectiveYield = null;
  // Set when a yield COULD have been solved but deliberately was not. Carried
  // on the schedule so the UI can say why rather than showing a blank.
  let eirRefusal = null;
  const amort = instr.amortization || { method:'none' };
  // Days-per-year aligned with the day-count basis (keeps IRR-solve consistent with daily accrual).
  const daysPerYear = (basis==='ACT/365' || basis==='ACT/ACT') ? 365 : 360;
  /* ─── Purchased or originated credit-impaired ────────────────────────────
     A loan already credit-impaired when acquired takes a CREDIT-ADJUSTED
     effective rate: lifetime expected credit losses are built into the yield
     from initial recognition, and no separate day-one allowance is raised.
     That is a different calculation, not a parameter of this one.

     Running the ordinary method on such an asset overstates interest income
     for the whole of its life — the discount that compensates for expected
     losses gets accreted into income as though it were pure yield — and the
     error never self-corrects. So the solve is refused rather than performed,
     and the reason is carried out to the caller. Deliberately loud: silence
     here produces a plausible number that is wrong by design. */
  const pociFlag = instr.creditImpairedAtAcquisition === true;
  /* ─── POCI — credit-adjusted effective interest rate (IFRS 9 §B5.4.7) ─────
     The ordinary EIR discounts the CONTRACTUAL cash flows. A credit-adjusted
     EIR discounts the cash flows the holder actually EXPECTS to collect —
     contractual less lifetime expected credit losses — back to the amount
     paid. On a distressed purchase the two are far apart: 100m of contractual
     principal bought for 60m because 40m is not expected to arrive. Discount
     the contractual flows and the 40m accretes into interest income as though
     it were yield; discount the expected flows and the rate reflects what the
     buyer is really earning on the money at risk.

     The lifetime ECL at acquisition is supplied — it is the fund's own
     underwriting view, not something the engine can infer from a price. When
     it has not been stated the solve is still refused, because inferring it
     from the discount would assume the entire discount is credit (it may be
     liquidity, or a bargain) and would silently manufacture the input the
     whole method rests on. */
  let caEIR = null;
  let caEIRBuild = null;
  if(pociFlag){
    const lifetimeECLAtAcq = (instr.ifrs && instr.ifrs.lifetimeECLAtAcquisition != null)
      ? +instr.ifrs.lifetimeECLAtAcquisition : null;
    const considerationPOCI = (instr.purchasePrice != null ? +instr.purchasePrice : null);
    if(lifetimeECLAtAcq == null || !(lifetimeECLAtAcq >= 0)){
      eirRefusal = 'Credit-impaired at acquisition, but no lifetime expected '
                 + 'credit loss was stated at the acquisition date. The credit-'
                 + 'adjusted effective rate discounts the cash flows expected to '
                 + 'be collected, so that figure is an input, not something that '
                 + 'can be read off the purchase price — a discount to par may be '
                 + 'credit, liquidity or a bargain, and assuming it is all credit '
                 + 'would invent the number the whole calculation depends on. '
                 + 'Enter the lifetime ECL at acquisition in Accounting Treatment.';
    } else if(!(considerationPOCI > 0)){
      eirRefusal = 'Credit-impaired at acquisition, but no consideration was '
                 + 'stated. A credit-adjusted rate is solved against what was '
                 + 'actually paid; without it there is nothing to solve to.';
    } else {
      /* Expected cash flows = contractual, less the lifetime loss. The loss is
         applied against the final principal recovery, which is where a
         distressed recovery shortfall actually falls — interest on a
         non-performing loan is collected or it is not, but the principal
         haircut crystallises at the end. */
      const horizonD = parseISO(instr.expectedRedemptionDate || instr.maturityDate) || maturity;
      const yrs = Math.max(0.0001, Math.round((horizonD - settle)/ONE_DAY) / daysPerYear);
      const face = +instr.faceValue || 0;
      const expectedPrincipal = Math.max(0, face - lifetimeECLAtAcq);
      const cfs = [];
      const whole = Math.floor(yrs);
      const annualCoupon = face * (couponRateNominal || 0);
      /* Interest is projected at the full contractual rate and the whole of the
         expected shortfall is taken against principal. That is not an optimism
         about the borrower — it is what the stated input means. The lifetime
         ECL supplied IS the expected shortfall; haircutting interest as well
         would make total expected losses exceed the figure the user entered and
         contradict the number the rate is being solved against. A fund that
         expects to lose interest too should say so by raising that figure. */
      const recoveryRatio = face > 0 ? (expectedPrincipal / face) : 0;
      for(let y = 1; y <= whole; y++) cfs.push({ t: y, amount: annualCoupon });
      const stub = yrs - whole;
      cfs.push({ t: yrs, amount: expectedPrincipal + (stub > 0 ? annualCoupon * stub : 0) });
      const solved = solveYield(considerationPOCI, cfs);
      if(solved == null || !isFinite(solved)){
        eirRefusal = 'Credit-impaired at acquisition. The credit-adjusted rate '
                   + 'did not converge on the expected cash flows supplied — check '
                   + 'that the lifetime ECL at acquisition is below face value and '
                   + 'that a redemption horizon is set.';
      } else {
        caEIR = solved;
        effectiveYield = solved;
        caEIRBuild = {
          consideration:        considerationPOCI,
          faceValue:            face,
          lifetimeECLAtAcq:     lifetimeECLAtAcq,
          expectedPrincipal:    expectedPrincipal,
          recoveryRatio:        recoveryRatio,
          contractualCoupon:    couponRateNominal || 0,
          horizon:              toISO(horizonD),
          yearsToHorizon:       yrs,
          creditAdjustedEIR:    solved,
          // What the ordinary method would have produced, for contrast. The
          // gap between the two is the overstatement POCI treatment avoids.
          ordinaryEIRWouldBe:   solveYield(considerationPOCI, (function(){
                                  const c = [];
                                  for(let y = 1; y <= whole; y++) c.push({ t:y, amount: annualCoupon });
                                  c.push({ t: yrs, amount: face + (stub > 0 ? annualCoupon*stub : 0) });
                                  return c;
                                })())
        };
      }
    }
  }
  if(!pociFlag && amort.method === 'effectiveInterestPrice' && instr.faceValue && couponRateNominal){
    /* The rate is solved against the OPENING CARRYING AMOUNT — consideration
       net of yield-integral fees received and gross of transaction costs — not
       against the headline price. Solving on the price alone and then releasing
       the fee separately produces two half-answers: a yield that ignores the
       fee, and a fee release that ignores the yield. */
    /* An undrawn facility has an opening carrying amount of nil, so this used
       to fall through to face value and solve a yield that ignored the fee
       entirely. The amount at risk is what will be advanced, net of the fee
       already held — 100m drawn against a 2m fee is 98m invested. */
    const _firstDrawAmt = (!_drawnAtSettle)
      ? events.filter(e => e && e.type === 'draw' && e.date > toISO(settle))
              .reduce((a, e) => a + (+e.amount || 0), 0)
      : 0;
    const eirT0 = eirOpeningCarrying > 0
      ? eirOpeningCarrying
      : (_firstDrawAmt > 0
           ? Math.max(1, _firstDrawAmt - pendingEIRFeeOffset)
           : (instr.purchasePrice || instr.faceValue || 0));

    /* Horizon: the EXPECTED life, not the contractual one. IFRS 9 spreads the
       yield over the period the instrument is expected to be held, and on a
       long-dated loan the two are not close — Suffolk runs to 2063 on paper.
       Falls back to contractual maturity when nothing was stated. */
    const expISO = instr.expectedRedemptionDate || null;
    const expDate = expISO ? parseISO(expISO) : null;
    /* On a facility undrawn at signing the effective rate is not earned from
       the signing date — there is nothing invested yet. It runs from the first
       drawdown, on the amount advanced net of any fee held since signing.
       Anchoring on settlement instead produced an EIR equal to the coupon with
       the fee ignored entirely, and a carrying amount that drifted DOWN from 98
       toward 97 over the life instead of accreting back to par. */
    const _firstDrawDate = (!_drawnAtSettle)
      ? (events.filter(e => e && e.date && e.type === 'draw' && e.date > toISO(settle))
                .map(e => e.date).sort()[0] || null)
      : null;
    const eirStart = _firstDrawDate ? parseISO(_firstDrawDate) : settle;
    const horizonEnd = (expDate && expDate > eirStart && expDate <= maturity) ? expDate : maturity;
    const horizonDays = Math.max(1, Math.round((horizonEnd - eirStart)/ONE_DAY));

    // Build cashflows aligned to the scheduler's day-count: coupon annually + face at maturity.
    const yearsToMat = horizonDays / daysPerYear;
    const cfs = [];
    const coupon = instr.faceValue * couponRateNominal;
    const fullYears = Math.floor(yearsToMat);
    for(let y=1; y<=fullYears; y++) cfs.push({t:y, amount: coupon});
    const stub = yearsToMat - fullYears;
    cfs.push({t: yearsToMat, amount: instr.faceValue + (stub>0 ? coupon*stub : 0)});
    const seed = solveYield(eirT0, cfs) ?? couponRateNominal;

    /* Refinement pass: find the yield that makes the daily roll-forward land on
       the closing balance.

       This used to hold the balance at faceValue for the whole life and accrue
       a constant coupon on it. That is only true of a bullet. On an amortising
       loan the balance falls as principal is repaid, so both the coupon and the
       yield accrue on less and less — and the discount and fee are earned over
       a smaller average balance, which RAISES the effective rate. Holding face
       constant produced the same EIR for a bullet and for a loan repaying 20% a
       year, and left carrying value £716,697 short of the balance at maturity
       on a £60m five-year facility.

       So the walk now follows the actual principal schedule. Each day:
         balance += draws − repayments
         carrying += carrying×y×dcf − balance×coupon×dcf + draws − repayments
       and the target is carrying == balance at the horizon, not carrying ==
       face. A repayment reduces the carrying amount by the cash received. */
    const _settleISO = toISO(settle);
    const _pSched = Array.isArray(instr.principalSchedule) ? instr.principalSchedule : [];
    const _deltaByDay = {};                       // ISO date → net principal movement
    for(const e of _pSched){
      if(!e || !e.date) continue;
      // Day-zero funding is already inside eirOpeningCarrying / eirOpeningBalance.
      // On a deferred-draw facility the walk starts at the first drawdown and
      // opens with that balance, so movements on or before it are already in.
      if(e.date <= (_firstDrawDate || _settleISO)) continue;
      const amt = +e.amount || 0;
      if(!amt) continue;
      const isDraw = (e.type === 'draw' || e.type === 'initialPurchase');
      const isDown = (e.type === 'paydown' || e.type === 'repayment' ||
                      e.type === 'prepayment' || e.type === 'mandatoryPrepayment');
      if(!isDraw && !isDown) continue;
      _deltaByDay[e.date] = (_deltaByDay[e.date] || 0) + (isDraw ? amt : -amt);
    }

    const runCarrying = (y) => {
      let cv  = eirT0;
      /* Walk from the date the money actually went out. On a facility undrawn
         at signing that is the first drawdown, with the balance already at the
         drawn amount and the carrying amount at that figure net of the fee —
         so the draw itself must NOT be applied again inside the loop. */
      let bal = (!_drawnAtSettle && _firstDrawAmt > 0)
        ? _firstDrawAmt
        : (eirOpeningBalance || instr.faceValue || 0);
      const d = new Date(eirStart);
      for(let k = 0; k <= horizonDays; k++){
        const iso = toISO(d);
        const delta = _deltaByDay[iso] || 0;
        if(delta){ bal += delta; cv += delta; }
        cv += (cv * y - bal * couponRateNominal) * (1/daysPerYear);
        d.setDate(d.getDate() + 1);
      }
      // Solve for carrying == balance, so the asset is carried at exactly what
      // is still owed on the day the horizon is reached.
      return cv - bal;
    };
    // runCarrying now returns the GAP (carrying − balance), so the root is 0.
    // It previously returned the carrying amount and was compared against face;
    // leaving that comparison in place would have solved for carrying == 2×face.
    let y0 = seed, y1 = seed * 1.001;
    let f0 = runCarrying(y0);
    let f1 = runCarrying(y1);
    for(let i=0; i<12 && Math.abs(f1) > 1e-3; i++){
      if(f1 === f0) break;                       // flat secant — no further progress
      const y2 = y1 - f1 * (y1-y0) / (f1-f0);
      if(!isFinite(y2)) break;
      y0 = y1; f0 = f1; y1 = y2; f1 = runCarrying(y1);
    }
    effectiveYield = y1;
  } else if(amort.method === 'effectiveInterestFormula'){
    effectiveYield = (couponRateNominal) + (amort.spread ?? 0);
  } else if(amort.method === 'effectiveInterestIRR'){
    effectiveYield = amort.yieldOverride ?? couponRateNominal;
  }

  // Discount/premium for straight-line
  const straightLineDaily = (amort.method==='straightLine' && instr.purchasePrice && instr.faceValue && totalDays>0)
    ? (instr.faceValue - instr.purchasePrice) / totalDays
    : 0;

  // PIK tracking (capitalize at anchor dates)
  /* `pikEnabled` asks whether this deal has a PIK leg AT ALL, over its whole
     life — so a leg that switches on at an amendment counts, even though the
     rate today is nil. It gates the apparatus; the rate per day is looked up
     separately below. Reading `instr.pik.enabled` alone was the reason a
     deferral amendment never capitalised: builderToInstrument reports
     `enabled:false` whenever the PIK rate AT INCEPTION is zero, which on a
     deferral deal it always is. */
  const pikEnabled = pikEverEnabled(instr);
  /* The rate at inception. Still used for the ORIGINAL EIR (which must be
     struck on inception terms) — the daily accrual uses pikRateOn(d) instead,
     so a banded leg steps when it is contracted to. */
  const pikRateNominal = pikRateOn(instr, toISO(settle));
  const capAnchor = settle;
  const capFreq = instr.pik?.capitalizationFrequency || 'Monthly';

  let cumCashAccrued = 0, cumPikAccrued = 0;
  let cumInterestEarned = 0, cumPikEarned = 0;
  let cumAmort = 0;
  let cumNonUseFee = 0;
  // ---- IFRS 9 ECL state -------------------------------------------------
  // ECL allowance is a contra-asset that grows toward the target ECL each day.
  // Target = (Stage 1 ? 12-month PD : lifetime PD) × LGD × EAD.
  // Daily ECL change = target - allowance, posted DR P&L / CR Loan Loss Allow.
  let eclAllowance = 0;
  let cumECLChange = 0;
  // ---- FX revaluation state ---------------------------------------------
  // Reval P&L is computed daily as opening-balance × (todayFX - yesterdayFX),
  // where FX = instrument currency → functional currency. fxRateSchedule
  // [{date, rate}] supplies date-effective fixings; default to 1.0.
  const fxScheduleSorted = (instr.fxRateSchedule || []).slice().sort((a,b)=>a.date.localeCompare(b.date));
  function fxRateOn(dateISO){
    if(!fxScheduleSorted.length) return 1.0;
    let r = fxScheduleSorted[0].rate;
    for(const step of fxScheduleSorted){
      if(step.date <= dateISO) r = step.rate;
      else break;
    }
    return r;
  }
  let prevFX = fxScheduleSorted[0]?.rate ?? 1.0;
  let cumFXGain = 0;
  // ---- IFRS 9 hedge accounting state ------------------------------------
  // hedge: { type:'CFH'|'FVH', notional, fixedRate, floatingRate,
  //          fairValueSchedule:[{date, mtm}], effectivenessRatio:0.95,
  //          settlementDates:[...] }
  // CFH: effective portion → cashFlowHedgeReserve (OCI 35000); ineffective → P&L (45100)
  // FVH: hedge MTM change → P&L (45200); offsetting hedged-item FV change → P&L
  // Reclassification on settlement: DR Hedge Reserve / CR P&L Hedge Income
  const hedgeFVSorted = ((instr.hedge?.fairValueSchedule) || []).slice().sort((a,b)=>a.date.localeCompare(b.date));
  const hedgeSettlements = new Set((instr.hedge?.settlementDates) || []);
  let prevHedgeMTM = hedgeFVSorted[0]?.mtm ?? 0;
  let cashFlowHedgeReserve = 0;     // OCI accumulator (CFH only)
  let cumHedgeOCI = 0;              // total OCI movement to date
  let cumHedgePL  = 0;              // total P&L impact (effective for FVH, ineffective for CFH)
  let cumHedgeReclass = 0;          // reserve reclassified to P&L on settlements (CFH)
  function hedgeMTMOn(dateISO){
    if(!hedgeFVSorted.length) return 0;
    let m = hedgeFVSorted[0].mtm;
    for(const step of hedgeFVSorted){
      if(step.date <= dateISO) m = step.mtm;
      else break;
    }
    return m;
  }

  // ---- Fee accrual setup (multi-fee) ----------------------------------
  // instr.fees: [{ id, kind, label, mode, rate, base, amount, frequency,
  //                paymentDate, ifrs, accrueFrom, accrueTo }]
  //   kind        : arrangement | commitment | guarantee | other
  //   mode        : 'percent' (rate × base × dcf) | 'flat' (amount on paymentDate)
  //   base        : commitment | undrawn | drawn | covered | face
  //   ifrs        : IFRS9-EIR | IFRS15-overTime | IFRS15-pointInTime
  //   frequency   : oneOff | daily | monthly | quarterly | semiAnnual | annual
  // EIR-classified fees (IFRS 9) accrete into carrying value as deferred
  // income; recognised pro-rata over the life. IFRS 15 fees are recognised
  // over the service period (commitment/guarantee) or at the point-in-time.
  /* ─── Floating-rate EIR policy ───────────────────────────────────────────
     IFRS 9 permits two treatments for a floating-rate instrument, and both are
     used in the market:

       'original' — the rate is set at initial recognition and held. Movements
                    in the benchmark flow through interest income via the
                    coupon, but the yield used to accrete the carrying amount
                    does not change.
       'revise'   — the rate is re-estimated at each reset (B5.4.5), anchored
                    to the carrying amount at that date over the remaining
                    expected life.

     This is an accounting policy, not a fact about the loan, so it is a
     setting rather than something inferred. Default 'original' — the treatment
     the engine has always applied — so no existing deal changes its numbers
     until someone deliberately chooses otherwise.

     IFRS 9 expects a policy to be applied consistently to like items, so a
     per-deal override is recorded and surfaced rather than applied quietly;
     eirBasis below reports which was used and how many times the rate moved. */
  const eirFloatingPolicy = (instr.eirFloatingPolicy === 'revise') ? 'revise' : 'original';
  // Anything that is not a fixed coupon resets against a benchmark.
  const isFloatingCoupon = !!(instr.coupon && instr.coupon.type && instr.coupon.type !== 'Fixed');
  let activeYield = effectiveYield;      // the rate actually driving accretion today
  let eirRevisions = 0;
  /* One entry per modification event: what was supplied, what the §5.4.3
     derivation produced, and whether they agree. Carried out on the schedule
     so the UI can show the build-up rather than a bare figure. */
  const modDerivations = [];

  /* Re-estimation at a reset. Uses the periodic solve rather than the daily
     walk: the daily walk is O(days) and a 39-year facility resetting twice a
     year would run it ~78 times inside a secant loop. Anchoring each estimate
     to the current carrying amount means any approximation is corrected at the
     next reset rather than compounding — and the final segment still solves to
     land on the balance outstanding. */
  function _reestimateEIR(cv, bal, cpnRate, daysLeft){
    if(!(cv > 0) || !(bal > 0) || !(daysLeft > 0)) return null;
    const yrs = daysLeft / daysPerYear;
    const cpn = bal * (cpnRate || 0);
    const cfs = [];
    const full = Math.floor(yrs);
    for(let y = 1; y <= full; y++) cfs.push({ t: y, amount: cpn });
    const stub = yrs - full;
    cfs.push({ t: yrs, amount: bal + (stub > 0 ? cpn * stub : 0) });
    const y = solveYield(cv, cfs);
    // Reject nonsense rather than let a failed solve poison the schedule.
    return (y != null && isFinite(y) && y > -0.5 && y < 2) ? y : null;
  }

  /* Reset cadence, in months. Prefer the component's own tenor (a 6M SONIA
     component resets every six months); fall back to the accrual frequency. */
  const _resetMonths = (function(){
    const t = instr.rfr && instr.rfr.tenor;
    if(t){
      const m = String(t).trim().toUpperCase().match(/^(\d+)([DWMY])$/);
      if(m){
        const n = +m[1];
        if(m[2] === 'M') return n;
        if(m[2] === 'Y') return n * 12;
        if(m[2] === 'W') return Math.max(1, Math.round(n / 4.345));
        if(m[2] === 'D') return Math.max(1, Math.round(n / 30.44));
      }
    }
    const f = String(instr.interestAccrualFreq || '').toLowerCase();
    if(/month/.test(f))  return 1;
    if(/quarter/.test(f)) return 3;
    if(/semi/.test(f))    return 6;
    if(/annual|year/.test(f)) return 12;
    return 3;
  })();

  /* ─── Why the straight-line pool is gone ─────────────────────────────────
     Deferred fee income used to accrete as deferredEIRPool / totalLifeDays —
     an even daily slice. IFRS 9 5.4.1 requires the effective interest method,
     under which the release is the gap between the yield on the carrying
     amount and the contractual coupon. That gap grows as the carrying amount
     grows, so the true profile is never a straight line.

     The engine already computes exactly that, further down, as
         dailyAmort = carryingValue × effectiveYield × dcf − dailyCash
     but it only runs when effectiveYield is non-null — which, until the v0.5
     inputs arrived, it never was. So the flat pool was doing the work instead.

     Now that a yield is actually solved, running BOTH would add the fee to
     carrying value twice and overshoot par at maturity. The flat accretion is
     therefore kept only as the legacy fallback for deals with no solved yield,
     where it remains better than nothing. */
  const eirFlatFallback = (effectiveYield == null && deferredEIRPool > 0)
    ? (deferredEIRPool / totalLifeDays)
    : 0;
  // V3 — Running total so the daily accretion step can cap itself at the pool
  // (prevents float-rounding overshoot) and crystallise the residual when the
  // loan is derecognised (balance → 0 via paydown / sale / write-off).
  let cumulativeEIRAccreted = 0;
  /* Set once the asset leaves the balance sheet through a sale or a
     debt-for-equity swap (IFRS 9 §3.2.3 — substantially all risks and rewards
     transferred). Never un-set: derecognition is not reversible. */
  let assetDerecognised = false;

  // ---- SONIA / margin ratchet helpers ---------------------------------
  // instr.marginSchedule: [{ from: ISO, to: ISO|null, marginBps: number }]
  // instr.esgAdjustment : { from: ISO, deltaBps: number }   (e.g., -2.5)
  // instr.rfr            : { index, baseRate, lookbackDays, rounding }
  // ─── V3 — Compounded RFR (SONIA / SOFR / ESTR / BBSW) ────────────────────
// Implements the daily-compounded-in-arrears methodology used by ISDA /
// ARRC / LMA for modern RFR loans, honouring the four convention fields the
// v3 Builder persists on `interest_terms`:
//
//   • lookbackDays     — observation period ends N business days before
//                        the period-end (typical: 5 days for SONIA loans).
//   • observationShift — also shifts the period START by N business days.
//                        When true (combined with lookback), the period
//                        window for weighting equals the actual interest
//                        period (vs the standard "look-back only" where
//                        the window is shifted but weights track the
//                        observation period, not the interest period).
//   • lockoutDays      — the rate observed (period_end − lockoutDays) is
//                        repeated for the final L days (common in U.S.
//                        SOFR loans following the ARRC fallback).
//   • dailyCompounding — true → daily-compounded;
//                        false → simple-arithmetic average of fixings.
//   • dayCount         — day-count basis for the compound factor and
//                        annualisation. 'ACT/360' (default), 'ACT/365',
//                        'ACT/365F' or 'ACT/365L' all pick the corresponding
//                        year-days denominator. '30/360' isn't meaningful at
//                        the daily-factor level (30/360 is a period-based
//                        convention) — it falls back to ACT/360.
//
// Input requires an actual fixings series on instr.rfr.fixings = [{date,rate}].
// When the series is empty or missing, returns null and the caller falls back
// to `instr.rfr.baseRate` (preserves legacy behaviour).
//
// Tenor parsing accepts any of: "1D".."999D" · "1W".."52W" · "1M".."60M"
// · "1Y".."30Y" (case-insensitive, whitespace-tolerant). Falls back to 90d
// when the tenor string can't be parsed.

// Exported for reuse by other engine helpers and tests.
function tenorToDays(tenor){
  if(tenor == null) return 90;
  // Numeric input (e.g. 45) → treat as days
  if(typeof tenor === 'number' && isFinite(tenor)) return Math.max(1, Math.round(tenor));
  const s = String(tenor).trim().toUpperCase().replace(/\s+/g,'');
  // Common shortcuts
  if(s === 'ON' || s === 'O/N') return 1;   // overnight
  if(s === 'TN' || s === 'T/N') return 1;   // tom-next
  if(s === 'SN' || s === 'S/N') return 2;   // spot-next
  // "<n><unit>" — n can be int, unit one of D/W/M/Y
  const m = s.match(/^(\d+(?:\.\d+)?)\s*([DWMY])$/);
  if(!m) return 90;
  const n = parseFloat(m[1]);
  const u = m[2];
  if(u === 'D') return Math.max(1, Math.round(n));
  if(u === 'W') return Math.max(1, Math.round(n * 7));
  // Months use 30.4375 (avg calendar-month length) so 6M → 183, 18M → 548, 2M → 61
  if(u === 'M') return Math.max(1, Math.round(n * 30.4375));
  if(u === 'Y') return Math.max(1, Math.round(n * 365));
  return 90;
}

// Day-count denominator for compound factor + annualisation.
function dayCountDenom(dayCount){
  const s = (dayCount || 'ACT/360').toString().trim().toUpperCase().replace(/\s+/g,'');
  if(s === 'ACT/365' || s === 'ACT/365F' || s === 'ACT/365L' || s === '365/365' || s === 'A/365') return 365;
  // ACT/360, 30/360, A/360 and unknown → 360
  return 360;
}

// ─── Are we entitled to believe the compounded rate we just produced? ───────
//
// computeCompoundedRFR will always hand back a number. That is the problem it
// creates: a rate compounded with lookback 0 / lockout 0 / shift 0 because
// nobody told us the conventions is arithmetically identical to one where the
// counterparty genuinely uses none, and there is no way to tell them apart
// downstream. A lookback of 5 vs 0 on the same fixings moves the rate by a
// basis point or two — immaterial on one period, not immaterial across 210 of
// them on a £1.4bn book, and fatal to a reconciliation, because a difference
// against the counterparty can no longer be read as an error.
//
// So the number is separated from the claim. This reports what we actually
// know, and callers record it next to the rate.
//
//   'stated'    — the conventions came from the loan agreement or the
//                 counterparty. A difference against their number is a real
//                 difference and worth investigating.
//   'assumed'   — someone (a seeder, a default, a person filling a form)
//                 supplied them. The rate is usable for our own accrual; it
//                 cannot verify anyone else's figure.
//   'unstated'  — no conventions recorded at all. The rate below is computed
//                 as though there were none, which is itself a convention and
//                 usually the wrong one.
//   'n/a'       — not a compounded RFR, or no fixings series, so the question
//                 does not arise.
function rfrConventionStatus(instr){
  const rfr = instr && instr.rfr;
  if(!rfr || !Array.isArray(rfr.fixings) || rfr.fixings.length === 0){
    return { status:'n/a', verifiable:false, describe:'',
             reason:'No fixings series — the compounded path is not in use.' };
  }
  // A plain-English rendering of what we are using, so the UI does not need to
  // reach back into the instrument to say it.
  const bits = [];
  if(rfr.index)                    bits.push(String(rfr.index));
  if(rfr.dailyCompounding === true)  bits.push('compounded daily');
  if(rfr.dailyCompounding === false) bits.push('simple average');
  if(rfr.lookbackDays     != null) bits.push(rfr.lookbackDays + '-day lookback');
  if(rfr.lockoutDays      != null) bits.push(rfr.lockoutDays + '-day lockout');
  if(rfr.observationShift != null) bits.push(rfr.observationShift + '-day observation shift');
  const describe = bits.join(' · ');

  const missing = ['lookbackDays','observationShift','lockoutDays','dailyCompounding']
                    .filter(k => rfr[k] == null);
  if(missing.length === 4){
    return {
      status:'unstated', verifiable:false, missing, describe,
      reason:'No compounding conventions recorded. The rate below is computed with '
           + 'no lookback, no lockout and no observation shift — which is itself a '
           + 'convention, not an absence — so it cannot be reconciled against the '
           + 'counterparty.'
    };
  }
  if(rfr.conventionsSource === 'stated'){
    return { status:'stated', verifiable:true, missing, describe,
             reason: missing.length
               ? 'Supplied by the counterparty or the loan agreement. Not stated: ' + missing.join(', ') + '.'
               : 'Supplied by the counterparty or the loan agreement — a difference against their figure is a real difference.' };
  }
  return {
    status:'assumed', verifiable:false, missing, describe,
    reason:'These conventions were assumed, not stated. Fine for our own accrual; '
         + 'not evidence that anyone else\'s figure is wrong.'
  };
}

function computeCompoundedRFR(asOfDate, instr){
  const rfr = instr && instr.rfr;
  if(!rfr || !Array.isArray(rfr.fixings) || rfr.fixings.length === 0) return null;
  // `|| 0` is deliberate and safe HERE: this function's job is to produce a
  // number, and with nothing stated, zero is the only defensible arithmetic.
  // What must not happen is that choice being invisible — rfrConventionStatus
  // above reports it, and the caller records it alongside the rate.
  const lookback   = +rfr.lookbackDays     || 0;
  const obsShift   = +rfr.observationShift || 0;
  const lockout    = +rfr.lockoutDays      || 0;
  const compounded = !!rfr.dailyCompounding;
  const tenorDays  = tenorToDays(rfr.tenor);
  const denom      = dayCountDenom(rfr.dayCount);
  // Observation window: [periodStart − obsShift, asOf − lookback], with the
  // last `lockout` days inside that window held flat at the rate observed on
  // (periodEnd − lockout).
  const periodEnd       = addDays(asOfDate, -lookback);
  const periodStart     = addDays(periodEnd, -tenorDays + (obsShift ? obsShift : 0));
  const lockoutCutoff   = addDays(periodEnd, -lockout);
  /* Date → rate, from ACTUAL fixings first and the FORECAST curve beyond them.

     Two different things were being conflated by one rule.

     Within the published series, carrying the last fixing forward is correct:
     SONIA is not published at weekends or on bank holidays, and the rate that
     applies on a Saturday is Friday's. That behaviour is kept.

     PAST the last published fixing it is not a convention, it is an
     assumption — and it was invisible. A loan maturing in 2030 was priced at
     whatever SONIA last printed, held flat for four years, and reported in the
     same column, same formatting, as an observed rate. Nobody chose that and
     nothing said it was happening.

     So the series now ends where the actuals end, and the forecast curve takes
     over from the day after. `rateSourceAt` reports which of the two produced
     a given day so the caller can show provenance rather than implying
     observation. */
  const fxs = rfr.fixings.slice().sort((a,b) => (a.date||'').localeCompare(b.date||''));
  const fcs = (Array.isArray(rfr.forecast) ? rfr.forecast.slice() : [])
                .sort((a,b) => (a.date||'').localeCompare(b.date||''));
  const lastActualISO = fxs.length ? fxs[fxs.length - 1].date : null;

  function _lookupIn(series, iso){
    let last = null;
    for(const f of series){
      if(f.date <= iso) last = +f.rate || 0;
      else break;
    }
    return last;
  }

  function fixingAt(d){
    const iso = toISO(d);
    // Inside the actual series — including non-publication days, where the
    // previous fixing legitimately applies.
    if(lastActualISO && iso <= lastActualISO){
      const a = _lookupIn(fxs, iso);
      if(a != null) return a;
      return (rfr.baseRate || 0);        // before the first fixing
    }
    // Beyond the actuals: the forecast curve, carried forward between its own
    // points the same way.
    if(fcs.length){
      const f = _lookupIn(fcs, iso);
      if(f != null) return f;
      // The forecast starts later than this date — fall back to the last
      // actual rather than to nothing.
      if(lastActualISO) return _lookupIn(fxs, lastActualISO) ?? (rfr.baseRate || 0);
    }
    /* No forecast supplied. The last actual held flat is the old behaviour and
       stays the fallback, because refusing to produce a rate would stop the
       schedule entirely. It is reported as 'held-flat', not as an observation,
       so the assumption travels with the number. */
    if(lastActualISO) return _lookupIn(fxs, lastActualISO) ?? (rfr.baseRate || 0);
    return (rfr.baseRate || 0);
  }

  // Walk daily across the observation window.
  let product = 1;     // for compounded
  let sum     = 0;     // for simple
  let count   = 0;
  const lockoutRate = fixingAt(lockoutCutoff);
  for(let d = new Date(periodStart); d <= periodEnd; d = addDays(d, 1)){
    const rate = (d > lockoutCutoff && lockout > 0) ? lockoutRate : fixingAt(d);
    if(compounded){
      // Daily compounding: (1 + r × 1/denom) factor — denom matches the
      // dayCount basis (360 for ACT/360, 365 for ACT/365).
      product *= (1 + rate / denom);
    } else {
      sum += rate;
    }
    count++;
  }
  if(count === 0) return null;
  if(compounded){
    // Annualise: (product − 1) × denom / count — same basis as the factor.
    return (product - 1) * denom / count;
  }
  return sum / count;
}

function lookupMarginBps(dateISO){
    const ms = instr.marginSchedule || [];
    for(const m of ms){
      const f = m.from || '0000-01-01';
      const t = m.to   || '9999-12-31';
      if(dateISO >= f && dateISO <= t) return m.marginBps;
    }
    return null;
  }
  function esgDeltaBps(dateISO){
    const e = instr.esgAdjustment;
    if(!e || !e.from) return 0;
    return dateISO >= e.from ? (e.deltaBps || 0) : 0;
  }

  const rows = [];
  const days = eachDay(settle, maturity);
  for(let i=0; i<days.length; i++){
    const d = days[i];

    // ----- Apply events first (draws, paydowns, prepayments, write-offs, recoveries, cures, forbearance, cap. costs, loan sales) -----
    const evs = eventsOn(d, events);
    let draw=0, paydown=0, prepayment=0, prepayPenalty=0, initial=0;
    let mandatoryPrepayment=0;                       // Transtype #16 — covenant-triggered portion
    const mandatoryTriggers = [];                    // Transtype #16 — array of trigger reason codes
    let writeOff=0, writeOffAllowanceUsed=0, writeOffResidualExpense=0;
    let recovery=0;
    let recoveryAllocation=null;        // Transtype #24 — optional bucket split
    let cureRelease=0;                  // Transtype #10
    let allowanceReversal=0;            // Transtype #23 — model-driven, no stage change
    let forbearanceStartDeferred=0;     // Transtype #11 (one-time deferral booking on start date)
    let capitalisedCost=0;              // Transtype #12 (one-off origination cost paid out)
    let loanSale=0, loanSaleCV=0, loanSaleGain=0;  // Transtype #13 (cash, carrying derecognised, gain/loss)
    let participation=0, participationCV=0, participationGain=0;  // Transtype #14 (partial sale)
    let debtEquitySwap=0, debtEquitySwapCV=0, debtEquitySwapLoss=0;  // Transtype #15 (D4E swap)
    const dateISO = toISO(d);
    /* A forgiveness dated on a modification date is part of that restructuring,
       not a separate write-off. Decided once, before the event loop, so the
       write-off handler and the modification block below agree. */
    const _forgivenessIsModification =
      (instr.modificationEvents || []).some(m => m && m.date === dateISO);
    let forgivenInModificationToday = 0;
    for(const e of evs){
      if(e.type==='initial'){ initial += e.amount; /* already counted into starting balance */ }
      else if(e.type==='draw'){
        // Skip the draw event that was already consumed by the initialDraw
        // detection (otherwise balance/carryingValue would double-count).
        if(e._consumedAsInitial){ draw += e.amount; /* counted into starting balance */ }
        else { draw += e.amount; balance += e.amount; drawnBalance += e.amount; carryingValue += e.amount; }
        /* First drawdown on a facility that was undrawn at settlement: this is
           the moment the deferred fee stops being a liability and becomes a
           reduction in the carrying amount of the asset. 100m drawn against a
           2m fee held since signing carries at 98m from today, and the fee
           accretes back through the EIR from here. Applied once. */
        if(pendingEIRFeeOffset > 0 && balance > 0.005){
          carryingValue -= pendingEIRFeeOffset;
          pendingEIRFeeOffset = 0;
        }
      }
      // 'repayment' is an alias for 'paydown' used by guarantee / equity-fund
      // examples — semantically clearer when reading the schedule.
      // Phase C bugfix — clamp the deduction to current balance so a previously-
      // executed acceleration (covenant-breach mandatoryPrepayment that already
      // zeroed the balance) doesn't get further reduced by the remaining
      // scheduled paydowns. The loan is extinguished; subsequent scheduled
      // payments are no-ops.
      else if(e.type==='paydown' || e.type==='repayment'){
        /* `repayOutstanding` means "settle whatever is left", which is what a
           bullet maturity actually does. The amount cannot be known when the
           schedule is built: on a PIK loan the balance compounds, so a payoff
           fixed at face leaves the capitalised interest outstanding forever.
           Measured on a 6% cash + 10.5% PIK facility, £10m face compounded to
           £16.37m and the auto payoff repaid only £10m, leaving £6.8m owing
           after maturity. The stated amount is kept as a floor so a partial
           schedule is never silently enlarged. */
        const target = e.repayOutstanding
          ? Math.max(+e.amount || 0, Math.max(0, balance))
          : e.amount;
        const actual = Math.min(Math.max(0, balance), target);
        paydown += actual;
        /* PIK accrued since the last capitalisation is settled in cash at the
           payoff, not capitalised onto a loan that is being extinguished. The
           day loop capitalises AFTER events, so without this the final stub
           landed on a zero balance and left a phantom £428,570 outstanding on a
           loan that had just been repaid in full. */
        if(e.repayOutstanding && cumPikAccrued > 0.005){
          paydown += cumPikAccrued;
          cumPikAccrued = 0;
        }
        balance -= actual;
        drawnBalance = Math.max(0, drawnBalance - actual);
        carryingValue = Math.max(0, carryingValue - actual);
      }
      // Transtype #4 — Prepayment. Same balance / carrying effect as paydown,
      // tagged separately so generateDIU emits a distinct "Loan Prepayment" JE.
      else if(e.type==='prepayment'){
        prepayment += e.amount; balance -= e.amount; drawnBalance -= e.amount; carryingValue -= e.amount;
        // Transtype #5 — Prepayment penalty.
        // Look up the applicable rate from instr.prepaymentPenaltySchedule[] and
        // compute penalty = prepayAmount × rate. If the prepayment event itself
        // carries a `penaltyRate` field, that overrides the schedule (per-deal
        // negotiated case).
        const sched = Array.isArray(instr.prepaymentPenaltySchedule) ? instr.prepaymentPenaltySchedule : [];
        let rate = 0;
        if(typeof e.penaltyRate === 'number') rate = e.penaltyRate;
        else {
          const band = sched.find(s => (!s.from || s.from <= dateISO) && (!s.to || s.to >= dateISO));
          if(band) rate = band.ratePct || band.rate || 0;
        }
        if(rate > 0) prepayPenalty += e.amount * rate;
      }
      // Transtype #16 — Mandatory Prepayment Events. Covenant-triggered
      // partial or full early repayment (excess cash flow sweep, change-of-
      // control, asset disposal proceeds, insurance/condemnation, IPO
      // proceeds). Same balance/carrying effect as a voluntary prepayment,
      // but tagged separately so DIU emits a distinct transtype carrying
      // the trigger reason — critical for covenant tracking and lender
      // reporting. Default: NO penalty income (mandatory prepayments
      // typically waive penalty by design).
      //   • trigger: 'excessCashFlow'|'changeOfControl'|'assetSale'|'ipo'|'insurance'
      //   • penaltyRate: 0 by default — set explicitly if the credit agreement
      //                  applies a make-whole even on mandatory prepay
      else if(e.type==='mandatoryPrepayment'){
        // Phase A #4 — Covenant-synthesised events carry amount=0 until the
        // trigger date; materialise the amount as the FULL outstanding balance
        // (acceleration), recomputed at the actual trigger date so prior
        // paydowns inside the schedule are netted correctly.
        if(e._covenantSynthesised && (!e.amount || e.amount === 0)){
          e.amount = Math.max(0, balance);
        }
        mandatoryPrepayment += e.amount;
        // Also feed into the overall prepayment bucket so dashboard / cashflow
        // charts continue to display the principal flow correctly (the voluntary
        // vs. mandatory split is recovered in DIU via the dedicated row field).
        prepayment   += e.amount;
        balance      -= e.amount;
        drawnBalance -= e.amount;
        carryingValue-= e.amount;
        if(e.trigger) mandatoryTriggers.push(e.trigger);
        // Apply penalty only if the event explicitly carries a rate (rare).
        if(typeof e.penaltyRate === 'number' && e.penaltyRate > 0){
          prepayPenalty += e.amount * e.penaltyRate;
        }
      }
      // Transtype #9 — Recovery post-write-off. Cash received from the
      // borrower (or bankruptcy estate, guarantor, collateral realisation)
      // AFTER the loan has been written off. Balance / carrying remain zero;
      // the recovery is recognised as income that reverses prior impairment.
      // Per IFRS 9 §B5.5.43 / ASC 326-20-30, recoveries are credited to the
      // same line that absorbed the original write-off (470000 Impairment).
      else if(e.type==='recovery'){
        recovery += e.amount;
        // ── Transtype #24 — Loan-Loss Recovery Allocation ──
        // Optional `allocation` object splits the recovery across buckets
        // (principal / default interest / default fees / legal). When present,
        // generateDIU emits one JE pair per bucket so reports can trace where
        // the recovered cash actually paid down. If absent, falls through to
        // the single principal-only JE pair (legacy behaviour).
        if(e.allocation){
          // Tag the day's row so generateDIU sees the split (carries through
          // via the row push at end of loop iteration).
          recoveryAllocation = recoveryAllocation || { principal:0, defaultInt:0, defaultFee:0, legal:0 };
          recoveryAllocation.principal  += (+e.allocation.principal  || 0);
          recoveryAllocation.defaultInt += (+e.allocation.defaultInt || 0);
          recoveryAllocation.defaultFee += (+e.allocation.defaultFee || 0);
          recoveryAllocation.legal      += (+e.allocation.legal      || 0);
        }
      }
      // Transtype #10 — Cure / Stage Reversal. Borrower returns to performing
      // status; the ECL allowance is released back to P&L. `releaseAmount`
      // specifies how much of the existing allowance to reverse. The engine
      // releases up to the existing allowance balance, no more.
      else if(e.type==='cure'){
        const release = Math.min(eclAllowance, e.releaseAmount || 0);
        cureRelease  += release;
        eclAllowance -= release;
        cumECLChange -= release;
      }
      // Transtype #23 — Allowance Reversal (Without Stage Change).
      // Same mechanic as cure (release ECL allowance to P&L) but driven by a
      // model recalibration (PD/LGD update, macro overlay change, qFactor
      // adjustment) rather than a stage migration. Distinct event type so
      // reports / IFRS 7 §35F disclosures can split "model-driven movements"
      // from "stage-cure movements" in the ECL roll-forward.
      else if(e.type==='allowanceReversal'){
        const release = Math.min(eclAllowance, e.releaseAmount || 0);
        allowanceReversal += release;
        eclAllowance      -= release;
        cumECLChange      -= release;
      }
      // Transtype #11 — Forbearance / Payment Holiday. A start-of-period
      // booking that documents the deferred interest expected during the
      // holiday window. Subsequent JE flows continue as normal (engine doesn't
      // suspend accruals — for clean demos the operator/PortF schedules
      // payments accordingly). The `deferredAmount` is the operator-estimated
      // interest deferred over the holiday period.
      else if(e.type==='forbearance'){
        forbearanceStartDeferred += (e.deferredAmount || 0);
      }
      // Transtype #12 — Capitalised origination costs. Costs PAID by NWF at
      // origination (legal, transaction, valuation) that capitalise into the
      // loan's carrying value per IFRS 9 §B5.4 / ASC 310-20-25-2. Increases
      // carrying by the cost amount and reduces day-1 cash by the same.
      else if(e.type==='capitalisedCost'){
        capitalisedCost += e.amount;
        carryingValue   += e.amount;
      }
      // Transtype #13 — Loan Sale (full derecognition). Sell the entire loan
      // to another lender / investor. Compute gain/loss = salePrice − carrying
      // at the sale date; zero out balance + drawnBalance + carryingValue so
      // subsequent days produce no further accruals (balance × rate × dcf = 0).
      // Per IFRS 9 §3.2.3 / ASC 860 derecognition: full transfer of control,
      // risks and rewards. Any residual ECL allowance is released to P&L below.
      else if(e.type==='loanSale'){
        const cvBefore = carryingValue;
        const sale     = (typeof e.salePrice === 'number') ? e.salePrice
                        : (typeof e.amount    === 'number') ? e.amount
                        : carryingValue;
        loanSale       += sale;
        loanSaleCV     += cvBefore;
        loanSaleGain   += (sale - cvBefore);
        // Release any remaining ECL allowance back to P&L (since the asset
        // and its credit exposure no longer belong to NWF).
        if(eclAllowance > 0){
          cureRelease  += eclAllowance;
          cumECLChange -= eclAllowance;
          eclAllowance  = 0;
        }
        // Derecognise the asset
        balance        = 0;
        drawnBalance   = 0;
        carryingValue  = 0;
        /* Latched for the rest of the schedule. A sold position must stay off
           the balance sheet — nothing downstream may put value back on it. */
        assetDerecognised = true;
      }
      // Transtype #14 — Loan Participation / Partial Sell-Down. NWF sells a
      // fraction (`fraction` 0–1, or `notionalSold` in currency) of the loan
      // to a participant. Per IFRS 9 §3.2.6 "transfer of part of asset where
      // the part is a fully proportionate share" — derecognise the
      // participated proportion, keep the rest on balance sheet accruing.
      //
      //   • fraction   : 0–1 (default if both given); engine multiplies by carrying
      //   • salePrice  : cash received from participant
      //   • Pro-rata ECL allowance also released for the sold portion
      else if(e.type==='participation'){
        let frac = (typeof e.fraction === 'number') ? e.fraction : null;
        if(frac == null && typeof e.notionalSold === 'number' && balance > 0){
          frac = e.notionalSold / balance;
        }
        if(frac == null || frac <= 0) frac = 0;
        if(frac > 1) frac = 1;
        const cvSold   = carryingValue * frac;
        const balSold  = balance       * frac;
        const drawSold = drawnBalance  * frac;
        const sale     = (typeof e.salePrice === 'number') ? e.salePrice : cvSold;
        participation     += sale;
        participationCV   += cvSold;
        participationGain += (sale - cvSold);
        // Pro-rata ECL allowance release (participant takes the credit risk).
        if(eclAllowance > 0 && frac > 0){
          const eclRelease = eclAllowance * frac;
          cureRelease  += eclRelease;
          cumECLChange -= eclRelease;
          eclAllowance -= eclRelease;
        }
        // Derecognise the sold proportion only
        balance       -= balSold;
        drawnBalance  -= drawSold;
        carryingValue -= cvSold;
      }
      // Transtype #15 — Debt-for-Equity Swap. Borrower issues equity to
      // settle the loan obligation. Per IFRIC 19 ("Extinguishing Financial
      // Liabilities with Equity Instruments") / ASC 470-50-40: derecognise
      // the entire loan at carrying; recognise an equity investment at fair
      // value (almost always lower than carrying in a distressed swap); the
      // difference flows to P&L as Restructuring Loss.
      //
      //   • equityFairValue : fair value of equity received
      //   • equityShares    : optional — # shares received (informational only)
      else if(e.type==='debtEquitySwap'){
        const cvBefore = carryingValue;
        const fv       = (typeof e.equityFairValue === 'number') ? e.equityFairValue : 0;
        debtEquitySwap     += fv;
        debtEquitySwapCV   += cvBefore;
        debtEquitySwapLoss += (cvBefore - fv);   // typically positive (loss)
        // Release any ECL allowance (loan no longer NWF's credit exposure).
        if(eclAllowance > 0){
          cureRelease  += eclAllowance;
          cumECLChange -= eclAllowance;
          eclAllowance  = 0;
        }
        // Derecognise the loan
        balance        = 0;
        drawnBalance   = 0;
        carryingValue  = 0;
        assetDerecognised = true;      // same latch as a sale — see loanSale
      }
      // Transtype #8 — Write-off. Stage 3 credit-impaired loan whose recovery
      // efforts have failed. Zero out balance + carryingValue; subsequent days
      // produce no further accruals (because balance × rate × dcf = 0).
      // The JE pair generated in generateDIU splits the write-off between the
      // existing ECL allowance (uses it up first) and a residual P&L charge.
      else if(e.type==='writeOff'){
        const wAmt = (typeof e.amount === 'number' && e.amount > 0) ? e.amount : balance;
        /* Forgiveness granted as part of a restructuring is NOT a write-off.
           IFRS 9 §5.4.4 writes off a gross amount the entity has no reasonable
           expectation of recovering, against the allowance. A negotiated
           concession is a change to the contractual cash flows — §5.4.3 — and
           its whole effect belongs in the modification gain or loss.

           Doing both double-counts: the carrying amount falls by the forgiven
           principal, and then the modification measures only the residual. On
           the forgiveness demo deal that reported a 3.3m loss on a 15m
           concession. So when a write-off shares its date with a modification
           event, the balance falls here and the CARRYING AMOUNT is left for the
           modification to move. No allowance is consumed and no write-off
           journal is raised — the loss is the modification's to report. */
        if(_forgivenessIsModification){
          balance      -= wAmt;
          drawnBalance -= wAmt;
          forgivenInModificationToday += wAmt;
        } else {
          writeOff += wAmt;
          // Snapshot the allowance balance available to absorb the write-off
          const availableAllowance = Math.max(0, eclAllowance);
          const used = Math.min(wAmt, availableAllowance);
          writeOffAllowanceUsed   += used;
          writeOffResidualExpense += (wAmt - used);
          // Apply the write-off to balances + allowance
          balance        -= wAmt;
          drawnBalance   -= wAmt;
          carryingValue  -= wAmt;
          eclAllowance   -= used;            // allowance consumed
          cumECLChange   -= used;            // allowance release recorded
        }
      }
    }

    // ----- IFRS 9 modification accounting (§5.4.3) -----------------------
    // modificationEvents: [{date, modType, gainLoss, newCoupon, newMaturity,
    //                       newSchedule, reason, pvDelta}]
    // Substantial mod (≥10% PV change) → derecognise + new instrument (the
    // engine logs the event and applies new terms forward; full derecog/re-
    // recog requires splitting into two instruments which we surface in DIU).
    // Non-substantial → adjust carrying value + post P&L gain/loss.
    let dailyModGain = 0;
    let modEventDescription = null;
    const dISO = toISO(d);
    for(const mev of (instr.modificationEvents || [])){
      if(mev.date !== dISO) continue;
      /* Apply the revised terms BEFORE deriving the gain or loss. The
         derivation discounts the REVISED cash flows, so it has to see the new
         coupon and the new maturity; deriving first would re-price the old
         deal and report no change. */
      if(mev.newCoupon){
        instr.coupon = Object.assign({}, instr.coupon || {}, mev.newCoupon);
      }
      if(mev.newMaturity){
        /* Record what it was before overwriting it. An extension is a
           concession in its own right — often the most valuable one in the
           package — and without the before picture the ledger shows a 2030
           loan with no trace that it was contracted to 2028. Only set once, so
           a second modification does not erase the original. */
        if(!instr.originalMaturityDate) instr.originalMaturityDate = instr.maturityDate;
        mev._maturityBefore = instr.maturityDate;
        mev._maturityAfter  = mev.newMaturity;
        // Note: maturity change mid-life only takes effect for accrual purposes
        // beyond this date. The day grid was fixed at loop start so we won't
        // extend rows — set a flag for the user.
        instr.maturityDate = mev.newMaturity;
      }
      /* IFRS 9 §5.4.3 — derive, don't assume. The original EIR is the rate
         solved at initial recognition, NOT activeYield: under the 'revise'
         floating policy activeYield has already moved with the resets, and
         discounting at it would hold the carrying amount flat by construction
         and report a gain or loss of nil on every modification. */
      let derived = null;
      try {
        derived = deriveModificationGainLoss(instr, {
          modDate:     dISO,
          /* `balance` is already net of any forgiveness granted today — the
             event loop above reduced it. Say so, or the derivation would
             subtract the concession a second time and double the loss. The
             carrying amount, by contrast, was deliberately left whole, so the
             measurement is against the pre-concession gross figure. */
          balance:     balance,
          carrying:    carryingValue,
          forgivenessApplied: forgivenInModificationToday > 0,
          /* The discount rate has to be on the same basis as the cash flows
             being discounted, and the derivation projects PIK: interest settled
             in kind capitalises and comes back as a larger repayment.

             Neither rate to hand is on that basis. `couponRateNominal` is the
             cash coupon only. The solved `effectiveYield` is cash-basis too —
             the schedule's own solve walks a balance that moves with the
             principal schedule, and capitalisation is not in it. Discounting a
             stream that compounds at cash + PIK by either of them prices a 20%
             instrument at 9%, and the gap surfaces as a modification gain that
             is pure artefact: 66.3m on the Stage 3 demo deal against a true
             figure near 12m.

             So when interest settles in kind, the PIK element is added to
             whichever rate we have. Approximate — the two do not compound
             together — but it is on the right basis, and on the same basis as
             the projection, which is what makes the difference meaningful. */
          originalEIR: (function(){
            const solved = (effectiveYield != null) ? effectiveYield : couponRateNominal;
            /* pikRateNominal is the rate AT INCEPTION, which is the right one
               here and the wrong one three lines into the daily loop. The
               original EIR is struck once, on the terms that existed at initial
               recognition; a PIK leg introduced by this very amendment must not
               appear in the rate the amendment is measured against, or the
               concession would be discounted at a rate that already assumes it. */
            return pikEnabled ? (solved + pikRateNominal) : solved;
          })(),
          daysPerYear: daysPerYear
        });
      } catch(err){
        console.warn('[engine] modification gain/loss derivation failed on ' + dISO + ':', err && err.message);
        derived = null;
      }
      const supplied = (mev.gainLoss != null && mev.gainLoss !== '') ? +mev.gainLoss : null;
      const gainLoss = (supplied != null) ? supplied : (derived ? derived.gainLoss : 0);
      /* Both are carried out. A supplied figure that disagrees with the
         derivation is not silently preferred — it is reported next to it, so
         the difference is a question somebody can answer rather than a number
         nobody can reproduce. */
      modDerivations.push({
        date: dISO,
        modType: mev.modType || 'non_substantial',
        reason: mev.reason || null,
        // The extension, when there was one — surfaced beside the gain or loss
        // so the panel can show what changed, not only what it cost.
        maturityBefore: mev._maturityBefore || null,
        maturityAfter:  mev._maturityAfter  || null,
        supplied,
        derived: derived ? derived.gainLoss : null,
        source: (supplied != null) ? 'supplied' : (derived ? 'derived' : 'none'),
        disagreement: (supplied != null && derived && Math.abs(supplied - derived.gainLoss) > 0.5)
                        ? (supplied - derived.gainLoss) : null,
        detail: derived
      });
      dailyModGain += gainLoss;
      modEventDescription = (mev.modType === 'substantial' ? 'Substantial' : 'Non-substantial')
                          + ' modification' + (mev.reason ? ' — ' + mev.reason : '');
      // For non-substantial mods, adjust carrying value by gain/loss (P&L pair posted via DIU)
      if(mev.modType !== 'substantial' && gainLoss){
        carryingValue += gainLoss;
      }
    }

    // ----- Determine effective coupon rate for today -----
    let couponRate = instr.coupon?.fixedRate ?? 0;
    let floatingRate = instr.coupon?.floatingRate ?? 0;
    const todayISO = toISO(d);
    /* Date-banded margin for today. The compounded-RFR branch below already
       does its own band lookup (and layers ESG on top), so it is left alone;
       this covers Fixed and Floating, where the band was previously ignored
       altogether and the whole life ran on the base rate plus — on Floating —
       a single constant spread taken from whichever band happened to be first
       in the array. */
    const todayBandBps = bandBpsOn(instr.marginSchedule, todayISO);
    if(instr.coupon?.type === 'Fixed' || !instr.coupon?.type){
      /* A fixed coupon is base + band, the same arithmetic Stage 1 shows in the
         interest-component card. Omitting this was the whole defect for deal
         2: the band was computed one line up and then dropped, so a loan
         contracted at "6% plus 400bps for year one" accrued 6% in year one.
         Floor and cap are deliberately not applied — the Fixed branch has
         never clamped, and a 10% coupon is not a breach of a cap that was
         written for a floating rate. */
      if(todayBandBps != null) couponRate = (instr.coupon?.fixedRate ?? 0) + todayBandBps / 10000;
    } else if(instr.coupon?.type === 'Floating'){
      /* The benchmark for today, from the fixings series when there is one.

         This branch used `floatingRate` — a single number captured at build
         time — for the entire life of the deal, and every index except SONIA
         is routed here. So a seven-year SOFR loan sitting on 272 observed SOFR
         fixings ran at the 4.00% base rate for all seven years and never read
         one of them. The fixings were loaded, stored, round-tripped and
         ignored, which is the same shape of defect as the discarded spread
         bands.

         Term rates belong here and are taken as published — no compounding.
         Daily compounded-in-arrears RFRs are routed to the branch below by
         builderToInstrument instead, because reading them as term rates would
         apply the wrong convention.

         `floatingRate` remains the fallback when no fixings exist, so a deal
         with nothing observed behaves exactly as before. */
      const observed = rfrRateOn(instr, todayISO);
      const base = (observed != null) ? observed : floatingRate;
      /* An all-in forecast IS the coupon. Adding the margin band on top would
         charge it twice — the curve already contains one. */
      const _allIn = rfrForecastIsAllIn(instr, todayISO);
      let r = _allIn
        ? base
        : base + (todayBandBps != null ? todayBandBps / 10000 : (instr.coupon.spread ?? 0));
      if(instr.coupon.floor != null) r = Math.max(r, instr.coupon.floor);
      if(instr.coupon.cap   != null) r = Math.min(r, instr.coupon.cap);
      couponRate = r;
    } else if(instr.coupon?.type === 'SONIA' || instr.coupon?.type === 'CompoundedRFR'){
      // RFR (SONIA / SOFR / ESTR / BBSW) + ratcheted margin + optional ESG.
      // V3 — Use computeCompoundedRFR which respects lookback / observation_shift
      // / lockout / daily_compounding / weighted from instr.rfr (projected by
      // builderToInstrument from interest_terms). Falls back to baseRate when
      // no actual fixings series is supplied — same as the legacy behaviour.
      const rfrBase = computeCompoundedRFR(d, instr) || (instr.rfr?.baseRate ?? floatingRate) || 0;
      const baseMarginBps = lookupMarginBps(todayISO);
      const marginBps = (baseMarginBps != null ? baseMarginBps : (instr.coupon.spread ?? 0)*10000)
                       + esgDeltaBps(todayISO);
      /* Same rule as the term branch: on a day covered by an ALL-IN forecast
         the rate already includes a margin, so none is added. ESG is dropped
         with it — an all-in quote is a finished number, and layering a
         sustainability adjustment onto it would be inventing a second
         adjustment nobody quoted. */
      const _allInRfr = rfrForecastIsAllIn(instr, todayISO);
      /* KNOWN EDGE, not handled: computeCompoundedRFR averages over an
         observation window, and the window that straddles the cutover contains
         benchmark days on one side and all-in days on the other. Compounding
         those together gives a rate that is neither — too high to be the
         benchmark, too low to be the all-in coupon.

         It affects one window (one tenor's worth of days, so about three
         months on a 3M deal) and self-corrects once the whole window sits in
         the forecast. Left alone deliberately rather than papered over,
         because the alternatives — extending the actuals, or back-filling the
         margin into them — would both invent data. Worth knowing when reading
         rates either side of the changeover date. */
      let r = _allInRfr ? rfrBase : rfrBase + marginBps/10000;
      if(instr.coupon.floor != null) r = Math.max(r, instr.coupon.floor);
      if(instr.coupon.cap   != null) r = Math.min(r, instr.coupon.cap);
      couponRate = r;
    }

    // ----- Phase A #3 — Covenant breach margin step-up -----
    // Applied uniformly across Fixed / Floating / RFR coupons so any breached
    // covenant with consequence=marginStepUp lifts the rate from breachDate
    // onward. Multiple breaches stack additively. Floor/cap are NOT
    // re-applied: the step-up represents a credit-spread penalty per the loan
    // agreement and is intentionally permitted to push above the contractual
    // cap.
    const covenantBreachStepUpBps = covenantMarginStepBpsOn(todayISO);
    if(covenantBreachStepUpBps > 0){
      couponRate += covenantBreachStepUpBps / 10000;
    }
    // Compute SICR flag once per day so both ECL block and row push can read it
    const covenantSICRActive = covenantSICRActiveOn(todayISO);

    // ----- Holiday skip (Req 18): when enabled, zero the day-count factor on holidays -----
    const onHoliday = instr.holidayCalendar && instr.holidayCalendar!=='none' && isHoliday(d, instr.holidayCalendar);
    const skipToday = !!(instr.skipHolidays && onHoliday);

    // ----- Amortization window (Req 10): only amortize inside [amortStart, amortEnd] if set -----
    const amortStart = instr.amortStart ? parseISO(instr.amortStart) : settle;
    const amortEnd   = instr.amortEnd   ? parseISO(instr.amortEnd)   : maturity;
    const inAmortWindow = d >= amortStart && d <= amortEnd;

    // ----- Day count factor -----
    const dcf = skipToday ? 0 : dayCountFactor(basis, d);

    // ----- Daily cash accrual -----
    // For guarantee / equity instruments NWF does not earn the underlying
    // loan's coupon (only fees / dividends), so suppress interest accrual.
    // The coupon rate stays on the row for reference (drives the underlying
    // loan's behaviour and any rate-linked guarantee fee calcs).
    const noInterest = instr.instrumentKind === 'guarantee'
                    || instr.instrumentKind === 'equity-fund'
                    || instr.instrumentKind === 'equity-direct';
    const dailyCash = noInterest ? 0 : (balance * couponRate * dcf);
    cumCashAccrued += dailyCash;
    cumInterestEarned += dailyCash;

    // ----- Default interest / default fee accrual -----
    // instr.defaultEvents: [{date, kind:'missedPayment'|'covenantBreach',
    //                        defaultRateBps, defaultFeeAmount, endDate?, reason}]
    // From the event date (until endDate or maturity) the engine adds
    // defaultRateBps × balance × dcf as additional default interest, and
    // recognises defaultFeeAmount as a one-off default fee on the event date.
    let dailyDefaultInterest = 0;
    let dailyDefaultFee = 0;
    if(Array.isArray(instr.defaultEvents)){
      for(const ev of instr.defaultEvents){
        if(!ev.date) continue;
        const evEnd = ev.endDate || toISO(maturity);
        if(todayISO >= ev.date && todayISO <= evEnd && ev.defaultRateBps){
          dailyDefaultInterest += balance * (ev.defaultRateBps/10000) * dcf;
        }
        if(todayISO === ev.date && ev.defaultFeeAmount){
          dailyDefaultFee += ev.defaultFeeAmount;
        }
      }
    }

    // ----- Daily PIK accrual -----
    /* Today's rate, not inception's. A PIK leg written as "0% base, +1100bps
       for the amendment year" accrues nothing outside that year and 11% inside
       it — which is the point of writing it that way. Held in a per-day
       variable so the row below can report the rate actually applied rather
       than a lifetime constant that was true on day one and nowhere else. */
    const pikRateToday = pikEnabled ? Math.max(0, pikRateOn(instr, todayISO)) : 0;
    let dailyPik = 0;
    if(pikEnabled && pikRateToday > 0){
      dailyPik = balance * pikRateToday * dcf;
      cumPikAccrued += dailyPik;
      cumPikEarned  += dailyPik;
    }

    // ----- IFRS 9 ECL provisioning ---------------------------------------
    // Target ECL based on stage:
    //   Stage 1: 12-month ECL  =  pdAnnual × lgd × balance
    //   Stage 2: lifetime ECL  =  min(1, pdAnnual × yearsRemaining) × lgd × balance
    //   Stage 3: lifetime ECL on net carrying (= gross - existing allowance)
    // Daily change = target - allowance (positive grows allowance, negative reverses).
    let dailyECLChange = 0;
    /* ─── POCI — IFRS 9 §5.5.13 / §5.5.14 ──────────────────────────────────
       A purchased or originated credit-impaired asset is measured differently
       from everything else, and the differences are absolute rather than
       matters of degree:

         • NO day-one loss allowance. The expected losses are already in the
           price and already in the credit-adjusted rate. Raising an allowance
           as well would charge for them twice.
         • NO stage transfers. There is no Stage 1, 2 or 3 for a POCI asset
           and no SICR assessment — it starts impaired and stays POCI for life.
         • Only the CUMULATIVE CHANGE in lifetime expected losses since
           acquisition goes to profit or loss. A favourable change is an
           impairment GAIN, recognised even where it takes the allowance below
           nil against the acquisition-date expectation.

       So the allowance carried here is the movement, not the level: expected
       losses of 40m at acquisition falling to 25m is a 15m gain, and rising to
       50m is a 10m further charge. */
    if(pociFlag && instr.ifrs && instr.ifrs.computeECL !== false){
      const baseECL = (instr.ifrs.lifetimeECLAtAcquisition != null)
        ? +instr.ifrs.lifetimeECLAtAcquisition : null;
      if(baseECL != null){
        /* Revised lifetime expectations, each dated. Supplied by the fund's
           own credit process — nothing about a POCI asset can be inferred from
           a PD/LGD grid, which is why these are facts the user states. */
        const revisions = Array.isArray(instr.ifrs.lifetimeECLRevisions)
          ? instr.ifrs.lifetimeECLRevisions : [];
        let currentExpected = baseECL;
        for(const rv of revisions){
          if(rv && rv.date && rv.date <= todayISO && rv.amount != null){
            currentExpected = +rv.amount;
          }
        }
        // Allowance = cumulative change since acquisition. Negative is a gain.
        const targetAllowance = currentExpected - baseECL;
        dailyECLChange = targetAllowance - eclAllowance;
        eclAllowance += dailyECLChange;
        cumECLChange += dailyECLChange;
      }
    } else if(instr.ifrs && instr.ifrs.computeECL !== false){
      // Phase A #2 — SICR auto-migration on covenant breach.
      // Per IFRS 9 §B5.5.17(k) and ASC 326-20-30-2, a covenant breach is a
      // qualitative indicator of significant increase in credit risk. When
      // any covenant with consequence=sicrTrigger is breached, escalate
      // Stage 1 → Stage 2 from breachDate onward (manual Stage 3 overrides
      // still win; we only escalate, never de-escalate).
      let stage = instr.ifrs.ecLStage || 1;
      if(covenantSICRActive && stage < 2) stage = 2;
      const pdAnn = instr.ifrs.pdAnnual || 0;
      const lgd   = instr.ifrs.lgd || 0;
      /* The target is nil when there is no exposure, and the allowance is moved
         toward the target either way.

         This condition used to gate the WHOLE calculation on `balance > 0`,
         which meant the allowance could be established but never released: on
         the day the loan was repaid the block was skipped, so the allowance
         simply kept its last value to the end of the schedule. It was invisible
         while the grid showed only a gross carrying amount, and became a
         negative net carrying amount the moment Gross and Net were shown side
         by side — a repaid loan reporting an allowance against nothing.

         Releasing to nil is also the right answer for a revolver that is fully
         repaid mid-life and redrawn later: no exposure, no allowance, and the
         allowance re-establishes when it is drawn again. */
      let targetECL = 0;
      if(pdAnn > 0 && lgd > 0 && balance > 0){
        const yrsRemaining = Math.max(0, (maturity - d) / (365 * ONE_DAY));
        let lifetimePD = Math.min(1, pdAnn * yrsRemaining);
        if(stage === 1){
          targetECL = balance * pdAnn * lgd;
        } else if(stage === 2){
          targetECL = balance * lifetimePD * lgd;
        } else {
          /* Stage 3 — credit-impaired. The MEASUREMENT is the same as Stage 2:
             lifetime expected credit losses on the exposure. What changes at
             Stage 3 is interest recognition — revenue is calculated on the net
             carrying amount rather than the gross (§5.4.1(b)) — and that is
             handled separately by stage3InterestBase, not here.

             This used to compute lifetime ECL on the balance NET of the
             existing allowance and then add that allowance back. Re-applied
             every day, it ratchets: day one charges LGD on the full exposure,
             day two charges LGD again on what is left, and so on until the
             allowance reaches the whole balance. A loan with LGD 45% was fully
             provided for inside a month, and the LGD input had no effect on the
             answer at all — the clamp decided it. */
          targetECL = balance * lifetimePD * lgd;
          // Never provide for more than is outstanding.
          targetECL = Math.min(balance, targetECL);
        }
      }
      /* Move toward the target, including when the target is nil. Guarded on
         "is there anything to do" rather than on "is there exposure", so the
         release at repayment actually posts. */
      if(Math.abs(targetECL - eclAllowance) > 0.005){
        dailyECLChange = targetECL - eclAllowance;
        eclAllowance += dailyECLChange;
        cumECLChange += dailyECLChange;
      }
    }

    // ----- FX revaluation ------------------------------------------------
    // Revalue OPENING balance at today's rate vs prior day's rate. Flow
    // changes on the day (draws/repayments) get booked at today's FX so they
    // don't generate FX P&L themselves.
    const todayFX = fxRateOn(todayISO);
    const dailyFXGain = (i === 0) ? 0 : (balance - draw + paydown) * (todayFX - prevFX);
    // (balance - draw + paydown) reconstructs the opening balance: today's
    // closing balance was already adjusted for the day's flows above.
    cumFXGain += dailyFXGain;
    prevFX = todayFX;

    // ----- IFRS 9 hedge accounting (§6) --------------------------------
    // Daily hedge MTM change is split into effective (OCI for CFH) and
    // ineffective (P&L for both CFH and FVH). For FVH the entire change is
    // P&L because it directly offsets the hedged item's FV movements.
    let dailyHedgeOCI = 0;          // CFH effective portion
    let dailyHedgePL  = 0;          // ineffective (CFH) or full hedge MTM (FVH)
    let dailyHedgeReclass = 0;      // CFH reclassification to P&L on settlement
    let hedgeEffectiveness = null;  // 80-125% test indicator
    if(instr.hedge && instr.hedge.type){
      const effRatio = instr.hedge.effectivenessRatio ?? 0.95;
      const todayMTM = hedgeMTMOn(dISO);
      const dMTM = (i === 0) ? 0 : todayMTM - prevHedgeMTM;
      prevHedgeMTM = todayMTM;
      // ── Transtype #20 — Hedge De-Designation ──
      // Per IFRS 9 §6.5.6 / ASC 815-25-40 / 815-30-40: once hedge accounting
      // is voluntarily discontinued, future MTM movements stop flowing through
      // the CFH OCI / FVH P&L mechanism. For CFH, the EXISTING reserve is
      // amortised to P&L over the remaining life of the originally-hedged
      // exposure. Trigger via instr.hedgeDeDesignationDate.
      const dedDate = instr.hedgeDeDesignationDate;
      const isDeDed = dedDate && dISO >= dedDate;
      if(isDeDed){
        // No further OCI / P&L accumulation from MTM changes — accounting frozen.
        // For CFH, amortise the existing reserve linearly to P&L over remaining
        // days from de-designation date to maturity.
        if(instr.hedge.type === 'CFH' && Math.abs(cashFlowHedgeReserve) > 0.005){
          // Compute remaining days from de-designation to maturity (inclusive)
          const dedDateObj = parseISO(dedDate);
          const remainDays = Math.max(1, Math.ceil((maturity - dedDateObj) / 86400000));
          // Amortise daily until reserve is fully recycled
          const dailyAmort = cashFlowHedgeReserve / remainDays;
          dailyHedgeReclass = dailyAmort;
          cashFlowHedgeReserve -= dailyAmort;
          // Numerical cleanup: if reserve gets close to zero, zero it out
          if(Math.abs(cashFlowHedgeReserve) < 0.01) cashFlowHedgeReserve = 0;
        }
      } else if(instr.hedge.type === 'CFH'){
        // Cash flow hedge: effective portion to OCI, ineffective to P&L
        dailyHedgeOCI = dMTM * effRatio;
        dailyHedgePL  = dMTM * (1 - effRatio);
        cashFlowHedgeReserve += dailyHedgeOCI;
        // Reclassify reserve to P&L on settlement dates (when hedged cashflow occurs)
        if(hedgeSettlements.has(dISO) && cashFlowHedgeReserve !== 0){
          dailyHedgeReclass = cashFlowHedgeReserve;
          cashFlowHedgeReserve = 0;
        }
      } else if(instr.hedge.type === 'FXP' || instr.hedge.subType === 'fxPrincipal'){
        // ── Transtype #22 — FX Hedge of Loan Principal (IFRS 9 §6.5.16(c)) ──
        // Same MTM math as CFH, but the OCI accumulates in the dedicated
        // FX Hedge Reserve (370000) instead of the generic CFH Reserve.
        // The JE emission routes through INVESTRAN_GL.fxHedgeReserveOCI
        // because the transactionType is labelled "FX Hedge Reserve" below.
        dailyHedgeOCI = dMTM * effRatio;
        dailyHedgePL  = dMTM * (1 - effRatio);
        cashFlowHedgeReserve += dailyHedgeOCI;
        if(hedgeSettlements.has(dISO) && cashFlowHedgeReserve !== 0){
          dailyHedgeReclass = cashFlowHedgeReserve;
          cashFlowHedgeReserve = 0;
        }
      } else if(instr.hedge.type === 'FVH'){
        // Fair value hedge: full MTM change to P&L
        dailyHedgePL = dMTM;
      }
      // Effectiveness ratio test — must be in 80-125% range under IFRS 9
      // (legacy IAS 39 numerical test; IFRS 9 §6.4.1 only requires economic
      // relationship + dominant credit risk, but we surface the ratio for
      // diagnostic purposes).
      hedgeEffectiveness = effRatio;
      cumHedgeOCI += dailyHedgeOCI;
      cumHedgePL  += dailyHedgePL;
      cumHedgeReclass += dailyHedgeReclass;
    }

    // ----- Non-use fee (on undrawn commitment) -----
    let dailyNonUse = 0;
    if(instr.nonUseFee?.enabled && commitment > drawnBalance){
      dailyNonUse = (commitment - drawnBalance) * (instr.nonUseFee.rate ?? 0) * dcf;
      cumNonUseFee += dailyNonUse;
    }

    // ----- Multi-fee daily accrual (IFRS 9 / 15 aware) -----
    // Each fee accrues on its own base × rate × dcf when in-window. EIR-classified
    // fees feed deferredEIRPool (one-off side already booked at t0); the pool
    // accretes daily into interest income (via carryingValue accretion). IFRS 15
    // fees recognise income directly on the fee line.
    let dailyFees = 0;
    const dailyFeeBreakdown = {};
    for(let fi=0; fi<fees.length; fi++){
      const f = fees[fi];
      const acc = feeAccum[fi];
      const accFrom = f.accrueFrom ? parseISO(f.accrueFrom) : settle;
      const accTo   = f.accrueTo   ? parseISO(f.accrueTo)   : maturity;
      if(d < accFrom || d > accTo) continue;
      let amt = 0;
      // One-off fees (arrangement, structuring) are captured into the
      // deferredEIRPool at t0 — skip the daily accrual loop entirely so
      // they don't double-count. They surface via dailyEIRAccretion (IFRS 9)
      // or as a point-in-time recognition row on paymentDate (IFRS 15).
      if(f.frequency === 'oneOff') {
        // Point-in-time IFRS 15: recognise the full amount on paymentDate.
        if(f.ifrs === 'IFRS15-pointInTime' && f.paymentDate && toISO(d) === f.paymentDate){
          if(f.mode === 'percent'){
            const baseAmt = (b => {
              if(b==='commitment') return commitment;
              if(b==='face')       return instr.faceValue || 0;
              if(b==='drawn')      return drawnBalance;
              if(b==='covered')    return instr.coveredAmount || 0;
              return commitment;
            })(f.base || 'commitment');
            amt = baseAmt * (f.rate || 0);
          } else {
            amt = f.amount || 0;
          }
        }
        // IFRS9-EIR / IFRS15-overTime one-offs: skip — already in EIR pool.
      } else if(f.mode === 'percent' || f.mode === 'marginLinked'){
        // Per-fee rate ratchet: if feeRateSchedule = [{from,to,rate}] is set,
        // resolve today's rate from the schedule (otherwise fall back to f.rate).
        // Closes scenario #14 (commitment fee % ratchets) and G3 (time-based
        // guarantee fee adjustments) — works for any percent-mode fee.
        let effectiveRate = f.rate || 0;
        if(Array.isArray(f.feeRateSchedule) && f.feeRateSchedule.length){
          for(const step of f.feeRateSchedule){
            const fr = step.from || '0000-01-01';
            const to = step.to   || '9999-12-31';
            if(todayISO >= fr && todayISO <= to){ effectiveRate = step.rate; break; }
          }
        }
        // For guarantee instruments, "drawn" / "undrawn" naturally refer to
        // the covered tranche, not the full facility. Fall back to commitment-
        // based for non-guarantee loans so existing behaviour is preserved.
        const isGuar = instr.instrumentKind === 'guarantee';
        const cap = isGuar && instr.coveredAmount ? instr.coveredAmount : commitment;
        const baseAmt = (b => {
          if(b==='commitment') return commitment;
          if(b==='undrawn')    return Math.max(0, cap - drawnBalance);
          if(b==='drawn')      return Math.min(drawnBalance, cap);
          if(b==='covered')    return instr.coveredAmount || 0;
          if(b==='face')       return instr.faceValue || 0;
          return cap;
        })(f.base || 'undrawn');
        if(f.mode === 'marginLinked'){
          // UK convention: commitment fee = marginMultiple × current margin × undrawn × dcf.
          // Margin includes ESG adjustment so the fee tracks the contractual
          // economics. marginMultiple defaults to 0.35 (35%).
          const baseMarginBps = lookupMarginBps(todayISO);
          const marginBps = (baseMarginBps != null ? baseMarginBps
                              : (instr.coupon?.spread ?? 0) * 10000)
                            + esgDeltaBps(todayISO);
          const eff = (marginBps/10000) * (f.marginMultiple ?? 0.35);
          amt = baseAmt * eff * dcf;
        } else {
          amt = baseAmt * effectiveRate * dcf;
        }
      } else if(f.mode === 'undrawnRamp'){
        // ─── Undrawn fee ramp (FirstAg Livestock Phase 2) ────────────
        //
        // During the ramp period, the undrawn balance is calculated as if
        // the facility limit were f.rampFacilityLimit (not the actual
        // commitment). The ramp ends when EITHER f.rampMonths elapses
        // since instr.startDate, OR outstanding balance exceeds
        // f.rampCancellationTriggerAmt — whichever comes first.
        //
        // After the ramp, undrawn reverts to the standard (cap − drawnBalance).
        //
        // Rate can come from f.bps (bps p.a., preferred for FirstAg-style
        // "40% of margin" = 280 bps), from f.rate (decimal p.a.), or from
        // a scheduled ratchet if provided.
        let effectiveRate = f.rate || 0;
        if(f.bps != null) effectiveRate = (+f.bps) / 10000;
        if(Array.isArray(f.feeRateSchedule) && f.feeRateSchedule.length){
          for(const step of f.feeRateSchedule){
            const fr = step.from || '0000-01-01';
            const to = step.to   || '9999-12-31';
            if(todayISO >= fr && todayISO <= to){ effectiveRate = step.rate; break; }
          }
        }
        // Determine whether we're inside the ramp on the current accrual day.
        let inRamp = false;
        const rampLimit = +f.rampFacilityLimit || 0;
        if(rampLimit > 0 && rampLimit < commitment){
          const startISO = instr.startDate || instr.settleDate;
          const rampMonths = +f.rampMonths || 0;
          const trigger   = +f.rampCancellationTriggerAmt || 0;
          // Loan-balance trigger — once outstanding exceeds the trigger, ramp ends
          const belowTrigger = trigger > 0 ? drawnBalance < trigger : true;
          // Time trigger — inside the ramp-months window from start
          let insideRampMonths = true;
          if(startISO && rampMonths > 0){
            const start = new Date(startISO);
            const rampEnd = new Date(start);
            rampEnd.setMonth(rampEnd.getMonth() + rampMonths);
            insideRampMonths = new Date(todayISO) <= rampEnd;
          }
          inRamp = insideRampMonths && belowTrigger;
        }
        const effectiveCap = inRamp ? rampLimit : commitment;
        const undrawn = Math.max(0, effectiveCap - drawnBalance);
        amt = undrawn * effectiveRate * dcf;
      } else if(f.mode === 'flat' || f.mode === 'fixed'){
        // Spread flat amount linearly across accrual window
        // 'fixed' is the v3 builder's mapping of 'fixAmount'; treat identical to 'flat'.
        const lifeDays = Math.max(1, Math.round((accTo - accFrom)/ONE_DAY) + 1);
        amt = (f.amount || 0) / lifeDays;
      }
      if(amt){
        acc.cumAccrued += amt;
        dailyFees += amt;
        dailyFeeBreakdown[acc.label] = (dailyFeeBreakdown[acc.label]||0) + amt;
      }
    }

    // ----- EIR accretion of deferred IFRS 9 fees -----
    // Deferred income (from arrangement / OID-style fees) accretes back into
    // interest income via increasing the carrying value daily.
    // V3 — Two-part fix to prevent carrying value from going negative:
    //   1. While balance > 0: accrete the daily slice as normal, but cap
    //      cumulative accretion at deferredEIRPool (prevents float rounding
    //      from over-shooting the pool).
    //   2. When balance hits zero on this row (paydown / loan sale / write-off
    //      / final maturity payment processed earlier in the event loop),
    //      CRYSTALLISE the remaining residual pool in one shot. This is the
    //      correct accounting treatment: the loan is derecognised so any
    //      unamortised deferred fee must be recognised at that moment.
    let dailyEIRAccretion = 0;
    if(eirFlatFallback > 0 && !assetDerecognised){
      /* Crystallisation is right when the loan is EXTINGUISHED — repaid, or
         written off — because the unamortised fee has nowhere left to go but
         income. It is wrong when the asset is SOLD. On a disposal the
         unamortised fee is already inside the carrying amount the proceeds are
         compared against, so recognising it again afterwards resurrects an
         asset that has been derecognised: the sold position carried 546,714
         the day after it left the balance sheet. Once derecognised, the pool
         goes with the asset and this stops entirely. */
      const remainingPool = Math.max(0, deferredEIRPool - cumulativeEIRAccreted);
      if(balance > 0.005){
        // Standard daily accretion — but never exceed the residual pool
        dailyEIRAccretion = Math.min(eirFlatFallback, remainingPool);
      } else if(remainingPool > 0.005){
        // Balance just hit zero — crystallise the entire residual pool today
        dailyEIRAccretion = remainingPool;
      }
      if(dailyEIRAccretion > 0){
        carryingValue += dailyEIRAccretion;
        cumulativeEIRAccreted += dailyEIRAccretion;
      }
    }

    // ----- Capitalization (PIK) -----
    let capitalized = 0;
    if(pikEnabled && isCapitalizationDay(d, capAnchor, capFreq) && cumPikAccrued > 0){
      capitalized = cumPikAccrued;
      balance += capitalized;
      carryingValue += capitalized;
      cumPikAccrued = 0; // reset accrued pool
    }

    /* ----- Floating-rate reset: re-estimate the yield if policy says so -----
       Only under 'revise', only for a floating coupon, and only once a yield
       exists to revise. A fixed-rate loan has nothing to re-estimate: its cash
       flows do not move, so the rate set at inception remains correct for life
       and re-solving would only add noise. */
    if(eirFloatingPolicy === 'revise' && activeYield != null && isFloatingCoupon &&
       isResetDay(d, settle, _resetMonths)){
      const daysLeft = Math.round((maturity - d)/ONE_DAY);
      const y = _reestimateEIR(carryingValue, balance, couponRate, daysLeft);
      if(y != null){
        if(Math.abs(y - activeYield) > 1e-9) eirRevisions++;
        activeYield = y;
      }
    }

    // ----- Amortization of discount/premium -----
    let dailyAmort = 0;
    if(inAmortWindow){
      if(amort.method === 'straightLine'){
        dailyAmort = straightLineDaily;
        carryingValue += dailyAmort;
        cumAmort += dailyAmort;
      } else if(activeYield != null){
        // effective interest: daily yield accrual on carrying value
        const dyield = activeYield * dcf;
        const effectiveIncome = carryingValue * dyield;
        dailyAmort = effectiveIncome - dailyCash; // portion that amortizes discount/premium
        carryingValue += dailyAmort;
        cumAmort += dailyAmort;
      }
    }

    rows.push({
      date: toISO(d),
      jsDate: d,
      dayOfWeek: d.getDay(),
      balance,
      drawnBalance,
      /* GROSS carrying amount — amortised cost before impairment. Kept under
         its original name so nothing downstream breaks, but it is the gross
         figure and the grids now label it as such. */
      carryingValue,
      /* NET carrying amount = gross less the ECL allowance.
         Computed once, here, rather than in each reader. The allowance is
         already on the row and the subtraction is trivial, which is exactly
         why four different surfaces would each end up doing it slightly
         differently — one of them on a restored run where the allowance was
         never persisted, and therefore silently reporting gross as net. */
      netCarryingValue: carryingValue - eclAllowance,
      initialPurchase: initial || 0,
      draw,
      paydown,
      prepayment,            // Transtype #4 — voluntary / mandatory early repayment (combined)
      mandatoryPrepayment,   // Transtype #16 — covenant-triggered portion (subset of `prepayment`)
      mandatoryTriggers: mandatoryTriggers.slice(),  // Transtype #16 — array of reason codes
      prepayPenalty,         // Transtype #5 — penalty income tied to prepayment
      writeOff,              // Transtype #8 — gross write-off amount
      writeOffAllowanceUsed, // Transtype #8 — portion absorbed by ECL allowance
      writeOffResidualExpense, // Transtype #8 — residual hitting P&L
      recovery,              // Transtype #9 — post-write-off cash recovered
      recoveryAllocation,    // Transtype #24 — optional split: {principal, defaultInt, defaultFee, legal}
      cureRelease,           // Transtype #10 — ECL allowance released back to P&L
      allowanceReversal,     // Transtype #23 — model-driven allowance reversal (no stage change)
      forbearanceStartDeferred,  // Transtype #11 — interest deferred from forbearance
      capitalisedCost,       // Transtype #12 — capitalised origination costs paid
      loanSale,              // Transtype #13 — sale proceeds (cash in)
      loanSaleCV,            // Transtype #13 — carrying value derecognised
      loanSaleGain,          // Transtype #13 — gain (+) or loss (−) on sale
      participation,         // Transtype #14 — participation proceeds (cash in)
      participationCV,       // Transtype #14 — partial carrying derecognised
      participationGain,     // Transtype #14 — gain/(loss) on partial sale
      debtEquitySwap,        // Transtype #15 — fair value of equity received
      debtEquitySwapCV,      // Transtype #15 — carrying derecognised
      debtEquitySwapLoss,    // Transtype #15 — restructuring loss (CV − FV)
      couponRate,
      floatingRate,
      currentRate: couponRate,
      dailyCash,
      cumInterestAccrued: cumCashAccrued,
      cumInterestEarned,
      capitalized,
      interestAdjustments: 0,
      cashInterestPayment: 0,
      /* Where today's benchmark rate came from. Only meaningful on a
         floating/RFR coupon; null on a fixed one, because "actual" would be a
         misleading thing to say about a rate nobody observes. */
      rateSource: isFloatingCoupon ? rfrRateSourceOn(instr, todayISO) : null,
      pikRate: pikRateToday,
      dailyPik,
      cumPikAccrued,
      cumPikEarned,
      pikInterestAdjustments: 0,
      pikPaydown: 0,
      amortDaily: dailyAmort,
      cumAmort,
      /* The two inputs the accretion was derived from, carried on the row so it
         can be re-derived downstream without re-running the engine. The
         external overlay replaces dailyCash with the amount the counterparty
         actually reported; accretion is the gap between the yield on the
         carrying amount and the cash coupon, so replacing one and not the other
         breaks the identity. Null when no effective yield is in force. */
      eirYieldUsed: (inAmortWindow && amort.method !== 'straightLine') ? activeYield : null,
      eirDcf: dcf,
      nonUseFee: dailyNonUse,
      cumNonUseFee,
      // IFRS-aware fee fields
      dailyFees,
      feeBreakdown: dailyFeeBreakdown,
      dailyEIRAccretion,
      cumEIRAccretion: (rows.length ? rows[rows.length-1].cumEIRAccretion : 0) + dailyEIRAccretion,
      // Default interest / default fee
      dailyDefaultInterest,
      dailyDefaultFee,
      cumDefaultInterest: (rows.length ? rows[rows.length-1].cumDefaultInterest : 0) + dailyDefaultInterest,
      cumDefaultFee:      (rows.length ? rows[rows.length-1].cumDefaultFee : 0) + dailyDefaultFee,
      // ECL provisioning (IFRS 9 §5.5)
      dailyECLChange,
      eclAllowance,
      cumECLChange,
      // Modification accounting (IFRS 9 §5.4.3)
      dailyModGain,
      modEventDescription,
      cumModGain: (rows.length ? rows[rows.length-1].cumModGain : 0) + dailyModGain,
      // FX revaluation
      fxRate: todayFX,
      dailyFXGain,
      cumFXGain,
      balanceFC: balance * todayFX,                       // balance in functional currency
      // Hedge accounting (IFRS 9 §6)
      dailyHedgeOCI, dailyHedgePL, dailyHedgeReclass,
      cashFlowHedgeReserve, cumHedgeOCI, cumHedgePL, cumHedgeReclass,
      hedgeEffectiveness,
      // Phase A covenants — daily diagnostics for JE memos + Dashboard
      covenantMarginStepBps: covenantBreachStepUpBps,
      covenantSICRActive,
      hasEvent: evs.length > 0 || capitalized > 0 || dailyDefaultFee > 0
    });
  }
  // Stash the engine's applied yield so computeEIR can align its effectiveYield
  // with the value the scheduler actually used.
  rows.effectiveYield = effectiveYield;
  rows.feeBreakdown   = feeAccum;          // per-fee cumulative accrual
  rows.deferredEIRPool = deferredEIRPool;  // total IFRS-9 deferred income at t0
  rows.modDerivations  = modDerivations;   // §5.4.3 build-up, one per modification event
  rows.poci = pociFlag ? {                 // §B5.4.7 credit-adjusted rate build-up
    applied: caEIR != null,
    creditAdjustedEIR: caEIR,
    build: caEIRBuild,
    refusal: caEIR == null ? eirRefusal : null
  } : null;
  // Phase A covenants — surface enriched covenant array for Dashboard / JE
  // generator to render breach banners + framework-aware memos.
  rows.covenants = enrichedCovenants;
  // What we are entitled to claim about the floating rate underneath these
  // rows. Carried on the schedule so the Cashflow tab, the accounting run and
  // any future reconciliation all read the same verdict rather than each
  // re-deriving it — or, worse, none of them asking.
  rows.rfrConventions = rfrConventionStatus(instr);
  /* ─── What the EIR on this schedule actually is ──────────────────────────
     A yield of "7.25%" that is really the contractual coupon, shown without
     qualification, is the same failure as a compounded rate built on assumed
     conventions: a number that looks calculated and is not. This says which,
     and shows the build-up so the figure can be decomposed rather than taken
     on trust — an EIR nobody can take apart is one nobody will defend. */
  rows.eirBasis = (function(){
    const consideration = instr.purchasePrice != null ? +instr.purchasePrice : null;
    const build = {
      faceValue:        instr.faceValue || 0,
      considerationPaid: consideration,
      yieldIntegralFees: deferredEIRPool || 0,
      transactionCosts:  txnCosts || 0,
      openingCarrying:   eirOpeningCarrying,
      contractualCoupon: couponRateNominal,
      expectedRedemption: instr.expectedRedemptionDate || null,
      horizonUsed: instr.expectedRedemptionDate ? 'expected redemption' : 'contractual maturity',
      floatingPolicy: isFloatingCoupon
        ? (eirFloatingPolicy === 'revise' ? 'revised at each reset' : 'held from initial recognition')
          + ' (' + (instr.eirFloatingPolicySource || 'workspace policy') + ')'
        : 'n/a (fixed coupon)',
      resetMonths: isFloatingCoupon ? _resetMonths : null,
      revisions: eirRevisions,
      // The rate in force at the end of the schedule. Equals the opening rate
      // under 'original'; under 'revise' it is wherever the resets took it.
      closingYield: activeYield
    };
    if(eirRefusal){
      return { status:'refused', calculated:false, effectiveYield:null, build,
               reason: eirRefusal };
    }
    if(effectiveYield == null){
      const atPar = consideration == null || Math.abs(consideration - (instr.faceValue||0)) < 0.005;
      return {
        status:'coupon', calculated:false, effectiveYield:null, build,
        reason: (atPar && !(deferredEIRPool > 0) && !txnCosts)
          ? 'No consideration, fee or cost was stated that differs from par, so '
          + 'there is nothing to amortise and the effective rate equals the '
          + 'contractual coupon. That is the correct answer here, not a fallback.'
          : 'No effective yield was solved — the amortisation method is not set. '
          + 'The figure shown is the contractual coupon and must not be reported '
          + 'as an effective interest rate.'
      };
    }
    return {
      status:'calculated', calculated:true, effectiveYield, build,
      reason: 'Solved so the carrying amount rolls forward to the balance '
            + 'outstanding at the ' + build.horizonUsed + '.'
    };
  })();
  return rows;
}

/* ---------- Window summariser ---------- */
function summarize(rows, beginISO, endISO){
  const win = rows.filter(r => r.date >= beginISO && r.date <= endISO);
  const sum = (arr, k) => arr.reduce((a,r)=> a + (r[k]||0), 0);
  // Build a per-fee breakdown for the window by walking each day's
  // feeBreakdown map and aggregating by label.
  const feeBreakdown = {};
  for(const r of win){
    if(r.feeBreakdown){
      for(const [k,v] of Object.entries(r.feeBreakdown)){
        feeBreakdown[k] = (feeBreakdown[k] || 0) + (v || 0);
      }
    }
  }
  return {
    rows: win,
    totalCashAccrual: sum(win,'dailyCash'),
    totalPikAccrual:  sum(win,'dailyPik'),
    totalCapitalized: sum(win,'capitalized'),
    totalAmort:       sum(win,'amortDaily'),
    totalNonUseFee:   sum(win,'nonUseFee'),
    totalFees:        sum(win,'dailyFees'),
    totalEIRAccretion: sum(win,'dailyEIRAccretion'),
    totalDefaultInterest: sum(win,'dailyDefaultInterest'),
    totalDefaultFee:      sum(win,'dailyDefaultFee'),
    totalDraws:           sum(win,'draw'),
    totalRepayments:      sum(win,'paydown'),
    totalPrepayments:     sum(win,'prepayment'),
    totalMandatoryPrepayments: sum(win,'mandatoryPrepayment'),  // Transtype #16 — covenant-triggered subset
    totalPrepayPenalty:   sum(win,'prepayPenalty'),
    totalWriteOff:        sum(win,'writeOff'),
    totalWriteOffAllowanceUsed:   sum(win,'writeOffAllowanceUsed'),
    totalWriteOffResidualExpense: sum(win,'writeOffResidualExpense'),
    totalRecovery:        sum(win,'recovery'),
    totalCureRelease:     sum(win,'cureRelease'),
    totalAllowanceReversal: sum(win,'allowanceReversal'),  // Transtype #23 — model-driven
    totalForbearanceDeferred: sum(win,'forbearanceStartDeferred'),
    totalCapitalisedCost: sum(win,'capitalisedCost'),
    totalLoanSale:        sum(win,'loanSale'),       // Transtype #13 — sale proceeds
    totalLoanSaleCV:      sum(win,'loanSaleCV'),     // Transtype #13 — carrying derecognised
    totalLoanSaleGain:    sum(win,'loanSaleGain'),   // Transtype #13 — gain/(loss) on sale
    totalParticipation:       sum(win,'participation'),    // Transtype #14 — participation proceeds
    totalParticipationCV:     sum(win,'participationCV'),  // Transtype #14 — partial carrying derecog
    totalParticipationGain:   sum(win,'participationGain'),// Transtype #14 — partial gain/(loss)
    totalDebtEquitySwap:      sum(win,'debtEquitySwap'),   // Transtype #15 — FV of equity recognised
    totalDebtEquitySwapCV:    sum(win,'debtEquitySwapCV'), // Transtype #15 — loan carrying derecog
    totalDebtEquitySwapLoss:  sum(win,'debtEquitySwapLoss'),// Transtype #15 — restructuring loss
    totalECLChange:       sum(win,'dailyECLChange'),
    closingECLAllowance:  win[win.length-1]?.eclAllowance ?? 0,
    totalFXGain:          sum(win,'dailyFXGain'),
    closingBalanceFC:     win[win.length-1]?.balanceFC ?? 0,
    totalModGain:         sum(win,'dailyModGain'),
    modEvents:            win.filter(r => r.modEventDescription).map(r => ({date: r.date, description: r.modEventDescription, gainLoss: r.dailyModGain})),
    totalHedgeOCI:        sum(win,'dailyHedgeOCI'),
    totalHedgePL:         sum(win,'dailyHedgePL'),
    totalHedgeReclass:    sum(win,'dailyHedgeReclass'),
    closingHedgeReserve:  win[win.length-1]?.cashFlowHedgeReserve ?? 0,
    feeBreakdown,                  // { 'Arrangement Fee': 12345.67, ... }
    daysCount:        win.length,
    openingBalance:   win[0]?.balance ?? 0,
    closingBalance:   win[win.length-1]?.balance ?? 0,
    closingCarrying:  win[win.length-1]?.carryingValue ?? 0,
    periodStart:      win[0]?.date,
    periodEnd:        win[win.length-1]?.date,
    // Phase A covenants — period-level breach signals for JE memo tagging.
    // covenantSICRTriggered = any day in window had a covenant-driven SICR
    // (forces Stage 2 ECL even if user set Stage 1). covenantMarginStepUpBpsMax
    // is the highest step-up active across the window — used for memo only.
    covenantSICRTriggered: win.some(r => r.covenantSICRActive),
    covenantMarginStepUpBpsMax: Math.max(0, ...win.map(r => r.covenantMarginStepBps || 0))
  };
}

/* ---------- Cash flow forecast & maturity ladder ----------
   Project daily flows from `asOfDate` forward into bucketed maturity ladders.
   Standard IFRS 7 liquidity disclosure buckets:
     ≤30d, 31-90d, 91-180d, 181d-1yr, 1-5yr, >5yr.
   Each bucket sums the principal repayments, interest, fees, and EIR
   accretion expected to settle in that window.
*/
function buildCashFlowForecast(rows, asOfISO){
  if(!rows || !rows.length) return null;
  const asOfDate = parseISO(asOfISO);
  if(!asOfDate) return null;
  const D = ms => Math.floor(ms / ONE_DAY);
  const cutoffs = [
    { label:'≤30d',     maxDays: 30  },
    { label:'31-90d',   maxDays: 90  },
    { label:'91-180d',  maxDays: 180 },
    { label:'181d-1yr', maxDays: 365 },
    { label:'1-5yr',    maxDays: 365 * 5 },
    { label:'>5yr',     maxDays: Infinity }
  ];
  // Initialise buckets
  const buckets = cutoffs.map((c, ix) => ({
    label: c.label,
    fromDays: ix === 0 ? 0 : cutoffs[ix-1].maxDays + 1,
    toDays:   c.maxDays,
    principal: 0, interest: 0, fees: 0, eir: 0, defaultInt: 0, total: 0,
    rowsCount: 0
  }));
  let totalPrincipal=0, totalInterest=0, totalFees=0, totalEIR=0, totalDefault=0;
  for(const r of rows){
    const rd = parseISO(r.date);
    if(rd < asOfDate) continue;
    const days = D(rd - asOfDate);
    const b = buckets.find(b => days >= b.fromDays && days <= b.toDays);
    if(!b) continue;
    const principal = (r.paydown || 0);
    const interest  = (r.dailyCash || 0);
    const fees      = (r.dailyFees || 0);
    const eir       = (r.dailyEIRAccretion || 0);
    const defaultInt= (r.dailyDefaultInterest || 0);
    b.principal += principal; b.interest += interest; b.fees += fees;
    b.eir += eir; b.defaultInt += defaultInt;
    b.total += principal + interest + fees + eir + defaultInt;
    b.rowsCount++;
    totalPrincipal += principal; totalInterest += interest; totalFees += fees;
    totalEIR += eir; totalDefault += defaultInt;
  }
  return {
    asOf: asOfISO,
    buckets,
    totals: {
      principal: totalPrincipal, interest: totalInterest, fees: totalFees,
      eirAccretion: totalEIR, defaultInterest: totalDefault,
      grandTotal: totalPrincipal + totalInterest + totalFees + totalEIR + totalDefault
    }
  };
}

/* ---------- Inline reference sample (SP023 / Libra 2) -----------------
   Embedded so the "Load sample" button works without a fetch — useful when
   the calculator is opened from file:// where same-directory JSON fetches
   may be blocked by the browser.
*/
const RECON_SAMPLE_LIBRA2 = {
  source: 'Reference Software X · SP023 Libra 2',
  exportedAt: '2026-04-30T16:00:00Z',
  matchKey: 'date',
  tolerances: { balance: 1.00, interest: 0.10, fees: 0.10, totalCash: 0.10, breakThresholdPct: 0.5 },
  instrument: { id: 'libra2', legalEntity: 'NWF Sustainable Infrastructure', deal: 'Libra 2',
                position: 'NWF 100% Bilateral Position · Libra 2',
                incomeSecurity: 'HSBC Facility B4 — Libra 2 (Compounded SONIA + Ratcheted Margin)' },
  scheduleResults: [
    { date:'2024-10-13', openingBalance:0, closingBalance:0, interestAccrued:0, totalFees: 437500.00, drawdown:0, repayment:0, utilisation:0, totalFacility:25000000, undrawnAmount:0,        comment:'Arrangement fee 1.75% × £25M paid 13/10/2024' },
    { date:'2025-01-10', openingBalance:0, closingBalance:0, interestAccrued:0, totalFees:  88219.18, drawdown:0, repayment:0, utilisation:0, totalFacility:25000000, undrawnAmount:25000000, comment:'Q1 commitment fee · 25M × 35% × 4.0% × 92/365' },
    { date:'2025-04-10', openingBalance:0, closingBalance:0, interestAccrued:0, totalFees:  87679.79, drawdown:0, repayment:0, utilisation:0, totalFacility:25000000, undrawnAmount:25000000, comment:'Q2 — margin 4.00% → 4.25% mid-period' },
    { date:'2025-07-10', openingBalance:0, closingBalance:0, interestAccrued:0, totalFees:  92420.38, drawdown:0, repayment:0, utilisation:0, totalFacility:25000000, undrawnAmount:25000000, comment:'Q3 — margin 4.50%, ESG -25 bps from 22/5' },
    { date:'2025-10-10', openingBalance:0, closingBalance:0, interestAccrued:0, totalFees:  93181.51, drawdown:0, repayment:0, utilisation:0, totalFacility:25000000, undrawnAmount:25000000, comment:'Q4 — full quarter at 4.475% effective' },
    { date:'2026-01-12', openingBalance:0, closingBalance:0, interestAccrued:0, totalFees:  95207.19, drawdown:0, repayment:0, utilisation:0, totalFacility:25000000, undrawnAmount:25000000, comment:'Q5 — date adjusted forward (modified following)' },
    { date:'2026-04-01', openingBalance:0, closingBalance:25000000, interestAccrued:0, totalFees:0, drawdown:25000000, repayment:0, utilisation:1, totalFacility:25000000, undrawnAmount:0, comment:'£25M drawdown · single tranche per reference modelling' },
    { date:'2026-04-10', openingBalance:25000000, closingBalance:25000000, interestAccrued:0, totalFees:80937.50, drawdown:0, repayment:0, utilisation:1, totalFacility:25000000, undrawnAmount:0, comment:'Stub commitment fee 12/01 → 31/03' },
    { date:'2026-07-01', openingBalance:25000000, closingBalance:25000000, interestAccrued:499006.92, totalFees:0, drawdown:0, repayment:0, utilisation:1, totalFacility:25000000, undrawnAmount:0, comment:'First quarterly interest post-drawdown' },
    { date:'2026-10-01', openingBalance:25000000, closingBalance:25000000, interestAccrued:497482.15, totalFees:0, drawdown:0, repayment:0, utilisation:1, totalFacility:25000000, undrawnAmount:0 },
    { date:'2027-01-04', openingBalance:25000000, closingBalance:25000000, interestAccrued:511904.02, totalFees:0, drawdown:0, repayment:0, utilisation:1, totalFacility:25000000, undrawnAmount:0 },
    { date:'2027-04-01', openingBalance:25000000, closingBalance:25000000, interestAccrued:469317.48, totalFees:0, drawdown:0, repayment:0, utilisation:1, totalFacility:25000000, undrawnAmount:0 },
    { date:'2027-07-01', openingBalance:25000000, closingBalance:25000000, interestAccrued:507740.36, totalFees:0, drawdown:0, repayment:0, utilisation:1, totalFacility:25000000, undrawnAmount:0 },
    { date:'2027-10-01', openingBalance:25000000, closingBalance:25000000, interestAccrued:515037.06, totalFees:0, drawdown:0, repayment:0, utilisation:1, totalFacility:25000000, undrawnAmount:0 }
  ]
};

/* ---------- Reconciliation engine -------------------------------------
   Compare our calculator's daily schedule against PortF reference data's
   period-by-period results (interest, fees, balance, etc.) and surface
   per-row diffs with status (tied / within tolerance / break) plus
   summary KPIs. Tolerances and break thresholds are configurable in the
   reference JSON; sensible defaults below.
*/
const RECON_DEFAULT_TOLERANCES = {
  balance: 1.00,
  interest: 0.10,
  fees: 0.10,
  totalCash: 0.10,
  breakThresholdPct: 0.5
};

function reconcileAgainstReference(rows, referenceData){
  if(!rows || !rows.length || !referenceData || !Array.isArray(referenceData.scheduleResults)) return null;
  const tol = Object.assign({}, RECON_DEFAULT_TOLERANCES, referenceData.tolerances || {});
  // Fast lookup: map calculator rows by date (ISO)
  const ourByDate = new Map();
  for(const r of rows) ourByDate.set(r.date, r);
  // For each reference period, find the matching day in our schedule.
  // The reference rows are typically end-of-period; we sum our daily flows
  // since the previous reference date for a period-to-period comparison.
  const sortedRef = referenceData.scheduleResults.slice()
    .sort((a,b)=> (a.date||'').localeCompare(b.date||''));
  let prevDate = null;
  const compared = [];
  for(const ref of sortedRef){
    const ourRow = ourByDate.get(ref.date);
    // Sum our daily flows from prevDate (exclusive) to ref.date (inclusive)
    // for period-style comparisons (interest, fees, drawdown, repayment).
    let ourInterest = 0, ourFees = 0, ourDraw = 0, ourPaydown = 0;
    if(prevDate){
      for(const r of rows){
        if(r.date > prevDate && r.date <= ref.date){
          ourInterest += r.dailyCash || 0;
          ourFees     += r.dailyFees || 0;
          ourDraw     += r.draw || 0;
          ourPaydown  += r.paydown || 0;
        }
      }
    } else {
      // First reference row — sum from start through ref.date
      for(const r of rows){
        if(r.date <= ref.date){
          ourInterest += r.dailyCash || 0;
          ourFees     += r.dailyFees || 0;
          ourDraw     += r.draw || 0;
          ourPaydown  += r.paydown || 0;
        }
      }
    }
    const ourBalance = ourRow ? ourRow.balance : null;
    const lines = [];
    const checkLine = (metric, refVal, ourVal, tolerance) => {
      if(refVal == null && ourVal == null) return;
      if(refVal == null) refVal = 0;
      if(ourVal == null) ourVal = 0;
      const diff = ourVal - refVal;
      const absDiff = Math.abs(diff);
      const denom = Math.abs(refVal) || Math.abs(ourVal) || 1;
      const pct = denom > 0 ? Math.abs(diff)/denom : 0;
      let status;
      if(absDiff <= tolerance)                                  status = 'tied';
      else if(pct * 100 <= tol.breakThresholdPct)               status = 'within';
      else                                                       status = 'break';
      lines.push({ metric, ref: refVal, ours: ourVal, diff, pct, status, tolerance });
    };
    checkLine('Closing Balance', ref.closingBalance,   ourBalance, tol.balance);
    checkLine('Interest Accrued', ref.interestAccrued,  ourInterest, tol.interest);
    checkLine('Total Fees',       ref.totalFees,        ourFees, tol.fees);
    checkLine('Drawdown',         ref.drawdown,         ourDraw, tol.balance);
    checkLine('Repayment',        ref.repayment,        ourPaydown, tol.balance);
    if(ref.feeBreakdown){
      for(const [k,v] of Object.entries(ref.feeBreakdown)){
        const ours = (ourRow && ourRow.feeBreakdown && ourRow.feeBreakdown[k]) || 0;
        checkLine('Fee · ' + k, v, ours, tol.fees);
      }
    }
    compared.push({
      date: ref.date,
      hasOurRow: !!ourRow,
      lines,
      worstStatus: lines.reduce((acc, l) =>
        l.status === 'break' ? 'break'
        : (l.status === 'within' && acc !== 'break') ? 'within'
        : acc, 'tied'),
      comment: ref.comment || null
    });
    prevDate = ref.date;
  }
  // Summary stats
  const flat = compared.flatMap(p => p.lines);
  const tied   = flat.filter(l => l.status === 'tied').length;
  const within = flat.filter(l => l.status === 'within').length;
  const breaks = flat.filter(l => l.status === 'break').length;
  const totalDiff = flat.reduce((a,l)=> a + l.diff, 0);
  const totalAbsDiff = flat.reduce((a,l)=> a + Math.abs(l.diff), 0);
  return {
    source: referenceData.source || '—',
    exportedAt: referenceData.exportedAt || null,
    tolerances: tol,
    periods: compared,
    summary: {
      periodsCompared: compared.length,
      linesTotal: flat.length,
      linesTied: tied,
      linesWithinTol: within,
      linesBreak: breaks,
      tieRatePct: flat.length ? (tied / flat.length * 100) : 100,
      totalSignedDiff: totalDiff,
      totalAbsDiff
    }
  };
}

/* ---------- Reference data persistence (per-instrument) ---------- */
const LS_KEY_RECON_REF = 'pe-loan-calc.reconciliation-references.v1';
function loadAllReferenceData(){
  try {
    const raw = localStorage.getItem(LS_KEY_RECON_REF);
    if(!raw) return {};
    return JSON.parse(raw) || {};
  } catch(e){ return {}; }
}
function saveAllReferenceData(map){
  try { localStorage.setItem(LS_KEY_RECON_REF, JSON.stringify(map || {})); }
  catch(e){ console.warn('Could not persist reference data:', e); }
}
function getReferenceForInstrument(id){ return loadAllReferenceData()[id] || null; }
function setReferenceForInstrument(id, refData){
  const all = loadAllReferenceData();
  all[id] = refData;
  saveAllReferenceData(all);
}
function clearReferenceForInstrument(id){
  const all = loadAllReferenceData();
  delete all[id];
  saveAllReferenceData(all);
}

/* ---------- DIU generator (N-6 / N-9) ---------- */
/* ---------- Investran GL chart mapping --------------------------------
   Maps the calculator's transaction types to the Investran GL accounts
   from "GL Accounts and tran types.xlsx". Each entry carries:
     account     — Investran 6-digit GL account code
     accountName — Investran display name
     transType   — Investran transaction type (when one cleanly matches)
     gap         — true when no clean match exists (operator must create)
     gapNote     — explanation shown in the GL Coverage panel
*/
const INVESTRAN_GL = {
  // ─── Cash ─────────────────────────────────────────────────────
  cashReceipt:     { account:'111000', accountName:'Cash', transType:'Cash received' },
  cashDisbursed:   { account:'111000', accountName:'Cash', transType:'Cash disbursed' },
  // ─── Loan asset (drawdown / repayment / capitalisation) ───────
  loanDrawdownInitial:    { account:'141000', accountName:'Investments at Cost', transType:'Purchase of investment - Notes - initial drawdown' },
  loanDrawdownAdditional: { account:'141000', accountName:'Investments at Cost', transType:'Purchase of investment - Notes - additional drawdown' },
  loanReturnOfCapital:    { account:'141000', accountName:'Investments at Cost', transType:'Sale of investment - Notes - Return of capital' },
  loanPikCapitalisation:  { account:'141000', accountName:'Investments at Cost', transType:'Purchase of investment - Notes - principal from capitalization' },
  loanOID:                { account:'141000', accountName:'Investments at Cost', transType:'Investment accretion - Original issue discount' },
  loanPIKAccretion:       { account:'141000', accountName:'Investments at Cost', transType:'Investment accretion - PIK interest' },
  /* ─── Deferred fee liability (IFRS 9 §B5.4.1 / §B5.4.2) ───────────────
     A fee that is integral to the effective interest rate, received BEFORE
     any loan asset exists — an arrangement fee on signing, a commitment fee
     on an undrawn facility where drawdown is probable — cannot be netted
     against a carrying amount that is not there yet. Until first drawdown it
     is a liability: cash the lender holds against a loan it has not made.

     Posting it straight to income would recognise revenue for a service not
     yet delivered; netting it against a nil asset would produce a negative
     loan balance. Both are wrong, and the second is the one that quietly
     looks plausible on a balance sheet. At drawdown the liability is released
     against the loan asset, so amortised cost opens net of the fee and the
     fee accretes back through the EIR over the life. */
  deferredFeeLiability: { account:'211000', accountName:'Deferred Fee Liability (IFRS 9 §B5.4.1)',
                          transType:'Deferred fee received – integral to EIR' },
  deferredFeeRelease:   { account:'211000', accountName:'Deferred Fee Liability (IFRS 9 §B5.4.1)',
                          transType:'Deferred fee released to loan asset on drawdown' },
  // ─── Receivables ──────────────────────────────────────────────
  interestReceivable:  { account:'113000', accountName:'Accounts Receivable', transType:'Interest receivable' },
  interestReceived:    { account:'113000', accountName:'Accounts Receivable', transType:'Interest received' },
  pikReceivable:       { account:'113000', accountName:'Accounts Receivable', transType:'Portfolio PIK interest receivable' },
  // Per-fee-type IFRS 15 fee receivables (NewReport(4) — gap closed). Each fee
  // type now has dedicated DR-side and CR-side (cash settlement) transtypes.
  feeReceivableArrangement:  { account:'113000', accountName:'Accounts Receivable', transType:'Fee receivable – Arrangement' },
  feeReceivedArrangement:    { account:'113000', accountName:'Accounts Receivable', transType:'Fee received – Arrangement' },
  feeReceivableCommitment:   { account:'113000', accountName:'Accounts Receivable', transType:'Fee receivable – Commitment' },
  feeReceivedCommitment:     { account:'113000', accountName:'Accounts Receivable', transType:'Fee received – Commitment' },
  feeReceivableGuarantee:    { account:'113000', accountName:'Accounts Receivable', transType:'Fee receivable – Guarantee' },
  feeReceivedGuarantee:      { account:'113000', accountName:'Accounts Receivable', transType:'Fee received – Guarantee' },
  feeReceivableManagement:   { account:'113000', accountName:'Accounts Receivable', transType:'Fee receivable – Management' },
  feeReceivedManagement:     { account:'113000', accountName:'Accounts Receivable', transType:'Fee received – Management' },
  feeReceivableDividend:     { account:'113000', accountName:'Accounts Receivable', transType:'Fee receivable – Dividend (Equity)' },
  feeReceivedDividend:       { account:'113000', accountName:'Accounts Receivable', transType:'Fee received – Dividend (Equity)' },
  // Generic fallback when the fee label doesn't fit any of the IFRS 15 buckets above.
  feeReceivable:       { account:'113000', accountName:'Accounts Receivable', transType:'Other receivable' },
  // Default interest / non-use fee receivable — no dedicated transtype on Investran chart.
  // These still use 'Other receivable' and are the only Priority-3 gap remaining.
  defaultIntReceivable:{ account:'113000', accountName:'Accounts Receivable', transType:'Other receivable',
                         gap:true, gapNote:'Default interest receivable — no specific transtype. The income side ("Default interest income (penalty rate)" under 421000) is mapped, but the DR-side receivable still falls back to "Other receivable". Optional: add "Default interest receivable" / "Default interest received" transtypes under 113000.' },
  defaultFeeReceivable:{ account:'113000', accountName:'Accounts Receivable', transType:'Other receivable',
                         gap:true, gapNote:'Default fee receivable — no specific transtype. The income side ("Default fee income" under 492000) is mapped, but the DR-side receivable still falls back to "Other receivable". Optional: add "Default fee receivable" / "Default fee received" transtypes under 113000.' },
  nonUseFeeReceivable: { account:'113000', accountName:'Accounts Receivable', transType:'Other receivable',
                         gap:true, gapNote:'Non-use fee receivable — no specific transtype. The income side ("Non-use fee income (lender)" under 492000) is mapped, but the DR-side receivable still falls back to "Other receivable". Optional: add "Non-use fee receivable" transtype under 113000.' },
  whtReceivable:       { account:'113000', accountName:'Accounts Receivable', transType:'Withholding tax receivable' },
  // ─── Income — interest ────────────────────────────────────────
  interestIncomeAccrued: { account:'421000', accountName:'Investment Interest Income', transType:'Income - Investment interest - Accrued' },
  interestIncomeCash:    { account:'421000', accountName:'Investment Interest Income', transType:'Income - Investment interest - Cash' },
  interestIncomePIK:     { account:'421000', accountName:'Investment Interest Income', transType:'Income - Investment interest - PIK/Accreted' },
  // ─── Income — IFRS 15 fees (dedicated accounts) ───────────────
  feeIncome:                { account:'492000', accountName:'Other Income - Amendments', transType:'Income - Other - Amendment fees' },  // generic fallback
  arrangementFeeIncome:     { account:'492100', accountName:'Arrangement Fee Income',         transType:'Arrangement fee income – IFRS 15' },
  commitmentFeeIncome:      { account:'492200', accountName:'Commitment Fee Income',          transType:'Commitment fee income – IFRS 15' },
  guaranteeFeeIncome:       { account:'492300', accountName:'Guarantee Fee Income',           transType:'Guarantee fee income – IFRS 15' },
  managementFeeIncomeInv:   { account:'492400', accountName:'Management Fee Income',          transType:'Management fee income – investment period' },
  managementFeeIncomePost:  { account:'492400', accountName:'Management Fee Income',          transType:'Management fee income – post-investment' },
  dividendIncome:           { account:'492500', accountName:'Dividend Income (Equity – IFRS 15)', transType:'Dividend income – IFRS 15' },
  // ─── Default interest / default fees / non-use fee (NewReport(4) — gaps closed)
  defaultIntIncome:      { account:'421000', accountName:'Investment Interest Income', transType:'Default interest income (penalty rate)' },
  defaultFeeIncome:      { account:'492000', accountName:'Other Income - Amendments',  transType:'Default fee income' },
  nonUseFeeIncome:       { account:'492000', accountName:'Other Income - Amendments',  transType:'Non-use fee income (lender)' },
  // ─── Gains / losses ───────────────────────────────────────────
  fxUnrealised:        { account:'450000', accountName:'Unrealized Gain/Loss', transType:'Unrealized gain/(loss) - F/X gain/(loss)' },
  fxRealised:          { account:'440000', accountName:'Realized Gain/Loss',   transType:'Realized gain/(loss) - Short term - F/X' },
  modificationGain:    { account:'442000', accountName:'Modification Gain / Loss (IFRS 9 §5.4.3)', transType:'Modification gain – IFRS 9' },
  modificationLoss:    { account:'442000', accountName:'Modification Gain / Loss (IFRS 9 §5.4.3)', transType:'Modification loss – IFRS 9' },
  // Loan sale / disposal (IFRS 9 §3.2.3 / ASC 860 — Transtype #13)
  loanSaleDerecognition:{ account:'141000', accountName:'Investments at Cost', transType:'Sale of investment - Notes - Loan disposal (derecognition)' },
  loanSaleGain:         { account:'442000', accountName:'Realized Gain on Loan Sale (IFRS 9 §3.2.3 / ASC 860)', transType:'Gain on sale of loan – IFRS 9 §3.2.3' },
  loanSaleLoss:         { account:'442000', accountName:'Realized Loss on Loan Sale (IFRS 9 §3.2.3 / ASC 860)', transType:'Loss on sale of loan – IFRS 9 §3.2.3' },
  // Loan participation / partial sell-down (IFRS 9 §3.2.6 — Transtype #14)
  participationDerecog: { account:'141000', accountName:'Investments at Cost', transType:'Sale of investment - Notes - Loan participation (partial derecog)' },
  participationGain:    { account:'442000', accountName:'Realized Gain on Loan Participation (IFRS 9 §3.2.6)', transType:'Gain on loan participation – IFRS 9 §3.2.6' },
  participationLoss:    { account:'442000', accountName:'Realized Loss on Loan Participation (IFRS 9 §3.2.6)', transType:'Loss on loan participation – IFRS 9 §3.2.6' },
  // Debt-for-Equity Swap (IFRIC 19 / ASC 470-50-40 — Transtype #15)
  d4eEquity:          { account:'142000', accountName:'Equity Investments at Cost', transType:'Equity received in debt-for-equity swap (IFRIC 19)' },
  d4eLoanDerecog:     { account:'141000', accountName:'Investments at Cost',         transType:'Sale of investment - Notes - Loan extinguished via D4E swap' },
  d4eRestructLoss:    { account:'542100', accountName:'Restructuring Loss — Debt-for-Equity (IFRIC 19)', transType:'Restructuring loss — debt-for-equity swap' },
  d4eRestructGain:    { account:'442100', accountName:'Restructuring Gain — Debt-for-Equity (IFRIC 19)', transType:'Restructuring gain — debt-for-equity swap' },
  // Mandatory prepayment (covenant-triggered — Transtype #16)
  mandatoryPrepayment:{ account:'141000', accountName:'Investments at Cost', transType:'Sale of investment - Notes - Mandatory prepayment (covenant trigger)' },
  // Trade-date accounting (IFRS 9 §B3.1.5 — Transtype #18)
  tradeDateAsset:     { account:'141000', accountName:'Investments at Cost', transType:'Trade-date recognition — Loan asset (IFRS 9 §B3.1.5)' },
  unsettledTradePay:  { account:'232000', accountName:'Unsettled Trade Payable', transType:'Unsettled trade payable — trade-date booking' },
  unsettledTradeRev:  { account:'232000', accountName:'Unsettled Trade Payable', transType:'Unsettled trade payable — settlement-date reversal' },
  tradeDateAssetRev:  { account:'141000', accountName:'Investments at Cost', transType:'Trade-date recognition reversal — Loan asset' },
  // ─── IFRS 9 ECL ───────────────────────────────────────────────
  impairmentExpense:   { account:'470000', accountName:'Impairment / ECL Expense (IFRS 9 §5.5)', transType:'Impairment expense – IFRS 9 ECL' },
  loanLossAllowance:   { account:'145000', accountName:'Loan Loss Allowance – IFRS 9 ECL',       transType:'Loan loss allowance – IFRS 9 ECL' },
  // ─── Hedge accounting (IFRS 9 §6) ─────────────────────────────
  hedgingInstrument:        { account:'146000', accountName:'Derivative Assets / Liabilities', transType:'Hedging instrument MTM' },
  hedgingInstrumentCFHEff:  { account:'146000', accountName:'Derivative Assets / Liabilities', transType:'Hedging instrument MTM – CFH effective' },
  hedgingInstrumentCFHIneff:{ account:'146000', accountName:'Derivative Assets / Liabilities', transType:'Hedging instrument MTM – CFH ineffective' },
  hedgingInstrumentFVH:     { account:'146000', accountName:'Derivative Assets / Liabilities', transType:'Hedging instrument MTM – FV hedge' },
  cfhReserve:               { account:'360000', accountName:'Cash Flow Hedge Reserve (OCI)',   transType:'Cash flow hedge reserve – OCI' },
  cfhReserveReclass:        { account:'360000', accountName:'Cash Flow Hedge Reserve (OCI)',   transType:'Cash flow hedge reserve – reclassification' },
  hedgeIneffectiveness:     { account:'451000', accountName:'Hedge Ineffectiveness P&L',       transType:'Hedge ineffectiveness P&L' },
  fvHedgePL:                { account:'452000', accountName:'Fair Value Hedge P&L',            transType:'Fair value hedge P&L' },
  hedgeReclass:             { account:'421000', accountName:'Investment Interest Income',     transType:'Income - Investment interest' },  // legacy generic CFH reclass routing
  // Transtype #21 — Dedicated CFH reclass transtype. Keeps the account on 421000
  // so it still flows to interest income, but tags the JE with a distinct
  // transactionType ("CFH reserve recycling to P&L — IFRS 9 §6.5.11"). This
  // lets reports split "income from hedge reserve recycling" from "raw coupon
  // income" — critical for hedge accounting disclosures (IFRS 7 §24A-B).
  cfhReclassPL:             { account:'421000', accountName:'Investment Interest Income — CFH Recycling', transType:'CFH reserve recycling to P&L (IFRS 9 §6.5.11)' },
  // De-designation amortisation surfaced separately so post-de-designation
  // OCI recycling is distinguishable from settlement-driven recycling.
  cfhReclassDeDed:          { account:'421000', accountName:'Investment Interest Income — CFH Recycling (De-Designated)', transType:'CFH reserve amortisation — post de-designation (IFRS 9 §6.5.6)' },
  // Transtype #22 — FX Hedge of Loan Principal (IFRS 9 §6.5.16(c) / §B6.5.34)
  // FX forwards designated as a hedge of the foreign-currency loan principal.
  // Spot-FX effective portion → FX Hedge Reserve (OCI).
  // Currency basis spread → Cost of Hedging Reserve (separate OCI bucket).
  fxHedgeReserveOCI:        { account:'370000', accountName:'FX Hedge Reserve (OCI · IFRS 9 §6.5.16)', transType:'FX hedge reserve – OCI (spot component)' },
  costOfHedgingReserve:     { account:'375000', accountName:'Cost of Hedging Reserve (OCI · IFRS 9 §6.5.16(c))', transType:'Cost of hedging – currency basis (OCI)' },
  fxHedgeInstrument:        { account:'146100', accountName:'FX Forward Asset / Liability', transType:'FX hedging instrument MTM' }
};

// Map our internal placeholder-account-codes / transaction-type strings onto
// the Investran chart. Called once on each batch of JE entries after the
// generators run so we don't have to thread the mapping through every add().
/* ── Configured GL mapping ───────────────────────────────────────────────────
   The accounts below are DEFAULTS. The General Ledger Mapping screen is what
   decides, and whatever it holds has to win here — otherwise the screen is a
   form that stores a preference nobody acts on, which is exactly what it was:
   a user could rename and renumber every account, re-run, and watch the
   journals come back on the shipped codes with nothing to say why.

   Keyed by engine transaction type, lowercased, with the DR and CR account for
   that business event. Populated by the builder before each run from
   gl_business_events + gl_event_mappings; empty here, so the engine keeps
   working standalone and tests that never load a workspace still pass. */
let _glOverrides = Object.create(null);
let _glFeeCtx    = null;      // { events, labelRules, roleRules } for fee routing
function setGLMappingOverrides(map, opts){
  _glOverrides = Object.create(null);
  _glFeeCtx    = null;
  if(!map) return 0;
  let n = 0;
  Object.keys(map).forEach(k => {
    const v = map[k];
    if(!v) return;
    _glOverrides[String(k).toLowerCase()] = v;
    n++;
  });
  if(opts && opts.feeEvents && opts.feeLabelRules && opts.feeRoleRules){
    _glFeeCtx = {
      events: opts.feeEvents,
      labelRules: opts.feeLabelRules.map(r => ({ re: new RegExp(r.src, r.flags), event: r.event })),
      roleRules:  opts.feeRoleRules.map(r  => ({ re: new RegExp(r.src, r.flags), side: r.side }))
    };
  }
  return n;
}
function getGLMappingOverrides(){ return _glOverrides; }

/* Fee rows by rule. Their transaction type is "<the operator's fee label>
   <role>" — "Commitment fee (undrawn capex) Receivable" — so no fixed list of
   names can cover them and they fell through to the shipped chart. That is how
   a commitment fee came to credit 492000 Other Income while the mapping screen
   said 492200 Commitment Fee Income, and how BOTH legs of the commitment-fee
   accrual ended up on the income account, so the pair cancelled and no
   receivable was ever raised.

   The label picks the event, the role picks which of its two accounts to use.
   Cash legs are left alone: cash is not one of the accounts a fee event
   carries. */
function _glFeeOverride(transactionType){
  if(!_glFeeCtx) return null;
  const tt = String(transactionType || '');
  if(!/fee/i.test(tt)) return null;
  if(/cash receipt/i.test(tt)) return null;
  const lab = _glFeeCtx.labelRules.find(r => r.re.test(tt));
  if(!lab) return null;
  const ev = _glFeeCtx.events[lab.event];
  if(!ev) return null;
  const role = _glFeeCtx.roleRules.find(r => r.re.test(tt));
  if(!role) return null;
  const acct = ev[role.side];
  if(!acct || !acct.account) return null;
  return { account: acct.account, accountName: acct.accountName || acct.account,
           eventKey: ev.eventKey, transType: ev.label, side: role.side };
}
if(typeof window !== 'undefined'){
  window.setGLMappingOverrides = setGLMappingOverrides;
  window.getGLMappingOverrides = getGLMappingOverrides;
}

function applyInvestranGLMapping(entries){
  // Transaction-type keyword → Investran GL key. Order matters: more specific
  // keywords must be checked before more general ones.
  const lookup = (tt, ourAcct) => {
    const t = (tt || '').toLowerCase();
    // Cash-leg lines (drawdown cash, repayment cash, fee/interest cash receipts)
    if(/cash receipt/.test(t) || /drawdown — cash/.test(t)) return INVESTRAN_GL.cashReceipt;
    if(/repayment — cash/.test(t))                          return INVESTRAN_GL.cashDisbursed;
    // Loan asset legs
    if(/^loan drawdown\b/.test(t) || /drawdown.*initial/.test(t))   return INVESTRAN_GL.loanDrawdownInitial;
    if(/^loan repayment\b/.test(t))                                return INVESTRAN_GL.loanReturnOfCapital;
    // Transtype #4 — Prepayment: same GL routing as repayment (loanReturnOfCapital
    // / cashReceipt) but distinct transtype so reports can filter on it.
    if(/^loan prepayment$/.test(t))                                return INVESTRAN_GL.loanReturnOfCapital;
    if(/^loan prepayment — cash$/.test(t))                         return INVESTRAN_GL.cashReceipt;
    // Transtype #16 — Mandatory Prepayment (covenant-triggered)
    if(/^mandatory prepayment$/.test(t))                           return INVESTRAN_GL.mandatoryPrepayment;
    if(/^mandatory prepayment — cash$/.test(t))                    return INVESTRAN_GL.cashReceipt;
    // Transtype #19 — Period-End Reversing Entries. The "Reversing — " prefix
    // is the entry's label; we delegate routing by stripping the prefix, re-
    // running the lookup recursively so the reverse pair lands in the same GL
    // account family as the original accrual, then re-attaching the prefix.
    if(/^reversing — /.test(t)){
      const innerTT = (tt || '').replace(/^reversing — /i, '');
      const innerMapped = lookup(innerTT, ourAcct);
      if(innerMapped){
        return { account: innerMapped.account, accountName: innerMapped.accountName,
                 transType: 'Reversing — ' + innerMapped.transType };
      }
    }
    // Transtype #18 — Trade vs Settlement Date Accounting
    if(/^trade-date recognition — loan asset$/.test(t))            return INVESTRAN_GL.tradeDateAsset;
    if(/^trade-date recognition — unsettled trade payable$/.test(t)) return INVESTRAN_GL.unsettledTradePay;
    if(/^settlement-date reversal — unsettled trade payable$/.test(t)) return INVESTRAN_GL.unsettledTradeRev;
    if(/^settlement-date reversal — loan asset/.test(t))           return INVESTRAN_GL.tradeDateAssetRev;
    // Transtype #5 — Prepayment penalty / make-whole income. Cash leg uses the
    // standard cash receipt; income leg maps to Other Investment Income (492000)
    // since 492700 isn't yet in the canonical Investran chart — flagged as a
    // candidate new sub-account in the GL gap inventory.
    if(/^prepayment penalty — cash$/.test(t))                      return INVESTRAN_GL.cashReceipt;
    if(/^prepayment penalty income$/.test(t))                      return INVESTRAN_GL.feeIncome;
    // Transtype #8 — Write-off. Allowance application → 145000 contra-asset;
    // residual expense → 470000 Impairment Expense; asset derecognition → 141000.
    if(/loan write-off — allowance applied/.test(t))               return INVESTRAN_GL.loanLossAllowance;
    if(/loan write-off — residual expense/.test(t))                return INVESTRAN_GL.impairmentExpense;
    if(/loan write-off — asset derecognition/.test(t))             return INVESTRAN_GL.loanReturnOfCapital;
    // Transtype #9 — Recovery post-write-off. Cash leg → standard cash receipt;
    // income leg credits 470000 Impairment (reverses prior write-off charge).
    if(/^recovery — cash receipt$/.test(t))                        return INVESTRAN_GL.cashReceipt;
    if(/^recovery of written-off loan$/.test(t))                   return INVESTRAN_GL.impairmentExpense;
    // Transtype #24 — Loan-Loss Recovery Allocation buckets
    if(/^recovery — cash receipt \(/.test(t))                      return INVESTRAN_GL.cashReceipt;
    if(/^recovery — principal/.test(t))                            return INVESTRAN_GL.impairmentExpense;
    if(/^recovery — default interest/.test(t))                     return INVESTRAN_GL.defaultIntIncome;
    if(/^recovery — default fee/.test(t))                          return INVESTRAN_GL.defaultFeeIncome;
    if(/^recovery — legal cost/.test(t))                           return INVESTRAN_GL.impairmentExpense;
    // Transtype #10 — Cure / Stage Reversal. Allowance side → 145000 (down),
    // income side → 470000 Impairment Expense (CR reverses prior expense).
    if(/^ecl cure — allowance reversal$/.test(t))                  return INVESTRAN_GL.loanLossAllowance;
    if(/^ecl cure — impairment reversal$/.test(t))                 return INVESTRAN_GL.impairmentExpense;
    // Transtype #23 — Model-driven allowance reversal (no stage change)
    if(/^allowance reversal — model recalibration$/.test(t))       return INVESTRAN_GL.loanLossAllowance;
    if(/^impairment reversal — model recalibration$/.test(t))      return INVESTRAN_GL.impairmentExpense;
    // Transtype #11 — Forbearance reclass. Both legs go to receivable area
    // (113000); operator can later route the deferred sub-balance to a
    // dedicated "Deferred Interest Receivable" sub-account.
    if(/^forbearance — deferred interest reclass$/.test(t))        return INVESTRAN_GL.interestReceivable;
    if(/^forbearance — interest receivable reduction$/.test(t))    return INVESTRAN_GL.interestReceivable;
    // Transtype #12 — Capitalised origination costs. DR carrying value (141000),
    // CR Cash (111000). Same income-statement effect as a negative upfront fee.
    if(/^capitalised origination costs$/.test(t))                  return INVESTRAN_GL.loanDrawdownInitial;
    if(/^capitalised origination costs — cash$/.test(t))           return INVESTRAN_GL.cashReceipt;
    // Transtype #25 — Revolver Origination Cost Deferral policy disclosure
    if(/^revolver cost deferral policy/.test(t))                   return INVESTRAN_GL.loanDrawdownInitial;
    // Transtype #13 — Loan Sale (full derecognition)
    if(/^loan sale — cash received/.test(t))                       return INVESTRAN_GL.cashReceipt;
    if(/^loan sale — asset derecognition$/.test(t))                return INVESTRAN_GL.loanSaleDerecognition;
    if(/^loan sale — residual asset derecog$/.test(t))             return INVESTRAN_GL.loanSaleDerecognition;
    if(/^loan sale — gain on disposal$/.test(t))                   return INVESTRAN_GL.loanSaleGain;
    if(/^loan sale — loss on disposal$/.test(t))                   return INVESTRAN_GL.loanSaleLoss;
    // Transtype #14 — Loan Participation (partial sell-down)
    if(/^loan participation — cash received/.test(t))              return INVESTRAN_GL.cashReceipt;
    if(/^loan participation — asset derecognition$/.test(t))       return INVESTRAN_GL.participationDerecog;
    if(/^loan participation — residual asset derecog$/.test(t))    return INVESTRAN_GL.participationDerecog;
    if(/^loan participation — gain on disposal$/.test(t))          return INVESTRAN_GL.participationGain;
    if(/^loan participation — loss on disposal$/.test(t))          return INVESTRAN_GL.participationLoss;
    // Transtype #15 — Debt-for-Equity Swap
    if(/^debt-for-equity swap — equity recognition/.test(t))       return INVESTRAN_GL.d4eEquity;
    if(/^debt-for-equity swap — loan derecognition/.test(t))       return INVESTRAN_GL.d4eLoanDerecog;
    if(/^debt-for-equity swap — restructuring loss$/.test(t))      return INVESTRAN_GL.d4eRestructLoss;
    if(/^debt-for-equity swap — restructuring gain$/.test(t))      return INVESTRAN_GL.d4eRestructGain;
    if(/pik (investment|capitalization)/.test(t))                  return INVESTRAN_GL.loanPikCapitalisation;
    // PIK legs on the external-feed path. 'PIK Interest Capitalised' raises the
    // loan asset; 'PIK Interest Income' is the income credit. Neither matched
    // any rule before, so both fell through to UNMAPPED and kept the hardcoded
    // 23000 they were emitted with.
    if(/^pik interest capitalised$/.test(t))                       return INVESTRAN_GL.loanPikCapitalisation;
    if(/pik interest income/.test(t))                              return INVESTRAN_GL.interestIncomePIK;
    if(/pik interest receivable/.test(t))                          return INVESTRAN_GL.pikReceivable;
    // Per IFRS 9 §B5.4 / ASC 310-20-35-26: discount accretion = income side; the
    // offset (asset side) goes to 141000 carrying value. So the "Offset" leg routes
    // to loanOID (141000), and the income leg routes to interestIncomeAccrued (421000).
    if(/discount accretion offset|premium amort.*offset/.test(t))  return INVESTRAN_GL.loanOID;
    if(/discount accretion|premium amort/.test(t))                 return INVESTRAN_GL.interestIncomeAccrued;
    if(/eir fee accretion/.test(t) && /offset/.test(t))            return INVESTRAN_GL.loanOID;
    if(/eir fee accretion/.test(t))                                return INVESTRAN_GL.interestIncomeAccrued;
    // Default interest / default fee — clear-leg checked BEFORE the bare receivable
    // pattern (the "clear" suffix is more specific and must match first).
    if(/default interest receivable clear/.test(t))                return INVESTRAN_GL.interestReceived;
    if(/default interest receivable/.test(t))                      return INVESTRAN_GL.defaultIntReceivable;
    if(/default interest income/.test(t))                          return INVESTRAN_GL.defaultIntIncome;
    if(/default interest cash receipt/.test(t))                    return INVESTRAN_GL.cashReceipt;
    if(/default fee receivable clear/.test(t))                     return INVESTRAN_GL.defaultFeeReceivable;
    if(/default fee receivable/.test(t))                           return INVESTRAN_GL.defaultFeeReceivable;
    if(/default fee income/.test(t))                               return INVESTRAN_GL.defaultFeeIncome;
    // Non-use fee
    if(/non-use fee receivable clear/.test(t))                     return INVESTRAN_GL.nonUseFeeReceivable;
    if(/non-use fee receivable/.test(t))                           return INVESTRAN_GL.nonUseFeeReceivable;
    if(/non-use fee income/.test(t))                               return INVESTRAN_GL.nonUseFeeIncome;
    // FX revaluation
    if(/fx (revaluation )?(gain|loss)/.test(t))                    return INVESTRAN_GL.fxUnrealised;
    if(/fx revaluation .*loan asset/.test(t))                      return INVESTRAN_GL.loanReturnOfCapital;
    // Modification gain/loss
    if(/modification (gain|loss)/.test(t) && !/offset|adjust/.test(t)) {
      return /gain/.test(t) ? INVESTRAN_GL.modificationGain : INVESTRAN_GL.modificationLoss;
    }
    if(/modification.*loan asset/.test(t))                         return INVESTRAN_GL.loanReturnOfCapital;
    // ECL / Impairment
    if(/impairment expense|impairment reversal/.test(t))           return INVESTRAN_GL.impairmentExpense;
    if(/loan loss allowance/.test(t))                              return INVESTRAN_GL.loanLossAllowance;
    // Hedge accounting — CFH OCI side, reclassification, ineffectiveness, FV hedge
    // Transtype #22 — FX Hedge of Loan Principal routing
    if(/^fx hedge reserve|fx hedge reserve.*oci/.test(t))          return INVESTRAN_GL.fxHedgeReserveOCI;
    if(/^fx hedging instrument mtm/.test(t))                       return INVESTRAN_GL.fxHedgeInstrument;
    if(/cost of hedging|currency basis/.test(t))                   return INVESTRAN_GL.costOfHedgingReserve;
    if(/cash flow hedge reserve.*reclass/.test(t))                 return INVESTRAN_GL.cfhReserveReclass;
    if(/hedge reserve reclass.*de-designat|cfh.*amortis.*de-desig/.test(t)) return INVESTRAN_GL.cfhReclassDeDed;
    if(/hedge reserve reclass|hedge income.*reclass|cfh reserve recycling/.test(t)) return INVESTRAN_GL.cfhReclassPL;
    if(/cfh oci|cash flow hedge reserve/.test(t))                  return INVESTRAN_GL.cfhReserve;
    if(/hedging instrument.*cfh oci/.test(t))                      return INVESTRAN_GL.hedgingInstrumentCFHEff;
    if(/hedging instrument mtm \(cfh/.test(t))                     return INVESTRAN_GL.hedgingInstrumentCFHEff;
    if(/hedging instrument/.test(t) && /fv|fair value/.test(t))    return INVESTRAN_GL.hedgingInstrumentFVH;
    if(/hedging instrument/.test(t))                               return INVESTRAN_GL.hedgingInstrumentCFHIneff;
    if(/hedge ineffectiveness/.test(t))                            return INVESTRAN_GL.hedgeIneffectiveness;
    if(/fair value hedge p&l/.test(t))                             return INVESTRAN_GL.fvHedgePL;
    // Interest legs
    if(/interest receivable clear/.test(t))                        return INVESTRAN_GL.interestReceived;
    // Transtype #3 — mid-period purchase: receivable side maps to 113000; cash side to 111000
    if(/accrued interest receivable/.test(t))                      return INVESTRAN_GL.interestReceivable;
    if(/accrued interest cash paid/.test(t))                       return INVESTRAN_GL.cashReceipt;
    if(/interest receivable/.test(t))                              return INVESTRAN_GL.interestReceivable;
    if(/income.*daily accrued interest/.test(t))                   return INVESTRAN_GL.interestIncomeAccrued;
    if(/interest cash receipt/.test(t))                            return INVESTRAN_GL.cashReceipt;
    // IFRS 15 fee legs — per-fee-type routing into dedicated accounts.
    // The fee label is what JE rows are tagged with (e.g. "Arrangement Fee Receivable",
    // "Arrangement Fee Receivable Clear", "Arrangement Fee Income"). Route both the
    // receivable / clear / income variants per fee type before falling back to generic.
    // Arrangement
    if(/arrangement fee receivable clear/.test(t))                 return INVESTRAN_GL.feeReceivedArrangement;
    if(/arrangement fee receivable/.test(t))                       return INVESTRAN_GL.feeReceivableArrangement;
    if(/arrangement fee.*income|arrangement fee \(/.test(t))       return INVESTRAN_GL.arrangementFeeIncome;
    // Commitment (NWF or generic)
    if(/(commitment fee|nwf commitment fee) receivable clear/.test(t)) return INVESTRAN_GL.feeReceivedCommitment;
    if(/(commitment fee|nwf commitment fee) receivable/.test(t))   return INVESTRAN_GL.feeReceivableCommitment;
    if(/(commitment fee|nwf commitment fee).*income|(commitment fee|nwf commitment fee) \(/.test(t))
                                                                    return INVESTRAN_GL.commitmentFeeIncome;
    // Guarantee
    if(/guarantee fee receivable clear/.test(t))                   return INVESTRAN_GL.feeReceivedGuarantee;
    if(/guarantee fee receivable/.test(t))                         return INVESTRAN_GL.feeReceivableGuarantee;
    if(/guarantee fee.*income|guarantee fee \(/.test(t))           return INVESTRAN_GL.guaranteeFeeIncome;
    // Management
    if(/management fee.*receivable clear/.test(t))                 return INVESTRAN_GL.feeReceivedManagement;
    if(/management fee.*receivable/.test(t))                       return INVESTRAN_GL.feeReceivableManagement;
    if(/management fee \(investment period\).*income/.test(t))     return INVESTRAN_GL.managementFeeIncomeInv;
    if(/management fee \(post-investment\).*income/.test(t))       return INVESTRAN_GL.managementFeeIncomePost;
    // Dividend (Equity, IFRS 15)
    if(/dividend.*receivable clear/.test(t))                       return INVESTRAN_GL.feeReceivedDividend;
    if(/dividend.*receivable/.test(t))                             return INVESTRAN_GL.feeReceivableDividend;
    if(/dividend income.*income \(ifrs 15\)|dividend.*\(ifrs 15\)/.test(t)) return INVESTRAN_GL.dividendIncome;
    /* Deferred fee liability — checked BEFORE the generic fee patterns below,
       which would otherwise catch "deferred fee received" on /receivable/ or
       /fee income/ and route a liability to a receivable or to income. */
    /* Order matters more than usual here. All four legs of the deferred-fee
       pair carry "Deferred Fee" in the label, but only two of them belong to
       the liability account — the other two are the cash received and the loan
       asset it is released against. A bare /deferred fee/ rule sent all four
       to 211000, producing a DR 211000 / CR 211000 pair twice over: a batch
       that balances and says nothing. */
    if(/deferred fee.*cash received/.test(t))                               return INVESTRAN_GL.cashReceipt;
    if(/deferred fee.*loan asset/.test(t))                                  return INVESTRAN_GL.loanDrawdownInitial;
    if(/deferred fee.*(release|drawdown)|release.*deferred fee/.test(t))    return INVESTRAN_GL.deferredFeeRelease;
    if(/deferred fee/.test(t))                                              return INVESTRAN_GL.deferredFeeLiability;
    // Generic IFRS 15 fee / PortF fallback
    if(/income \(ifrs 15\)|fee income \(ifrs 15\)|income \(portf\)/.test(t)) return INVESTRAN_GL.feeIncome;
    if(/cash receipt/.test(t))                                     return INVESTRAN_GL.cashReceipt;
    if(/receivable clear/.test(t))                                 return INVESTRAN_GL.feeReceivable;
    if(/receivable/.test(t))                                       return INVESTRAN_GL.feeReceivable;
    if(/fee income/.test(t))                                       return INVESTRAN_GL.feeIncome;
    return null;
  };
  for(const e of entries){
    /* Configuration first, defaults second.

       The leg matters: a business event carries a debit account and a credit
       account, and each engine row is one leg of it. Picking by `isDebit` is
       what makes "Interest Accrual · DR 113000 · CR 421000" on the mapping
       screen come out as a receivable debit and an income credit here, rather
       than both legs landing on whichever account was listed first. */
    /* Exact transaction type first, then the fee rules. Each entry already
       names a single account — the debit/credit flag plays no part, because
       which account a leg uses is a question about its ROLE in the event, not
       about the direction it happens to post in today. */
    const ov = _glOverrides[String(e.transactionType || '').toLowerCase()]
            || _glFeeOverride(e.transactionType);
    if(ov && ov.account){
      e.account       = ov.account;
      e.glAccountName = ov.accountName || ov.account;
      e.glTransType   = ov.transType || e.transactionType;
      e.glGap         = false;
      e.glGapNote     = null;
      // Recorded so the GL panel can show which rows followed configuration
      // and which fell back to the shipped chart.
      e.glSource      = 'configured';
      e.glEventKey    = ov.eventKey || null;
      continue;
    }
    const map = lookup(e.transactionType, e.account);
    if(map){
      e.account = map.account;
      e.glAccountName = map.accountName;
      e.glTransType = map.transType || e.transactionType;
      e.glGap = !!map.gap;
      e.glGapNote = map.gapNote || null;
      e.glSource = 'default';
    } else {
      // No mapping found — flag as a gap so the GL Coverage panel surfaces it
      e.glAccountName = '— UNMAPPED —';
      e.glGap = true;
      e.glGapNote = `No mapping rule for "${e.transactionType}". Add to INVESTRAN_GL or extend the lookup() rules.`;
    }
  }
  return entries;
}

function generateDIU(instr, summary, opts){
  if(!summary || !summary.rows.length) return [];
  // glDate semantics:
  //   • If opts.glDate is a non-empty string → every JE row uses that explicit close
  //     date (typical month-end posting: glDate = '2026-05-31' across the batch).
  //   • Otherwise → glDate AUTO-matches each row's effectiveDate (the day the
  //     underlying economic event occurred). This is the safe default: a JE for a
  //     drawdown booked on 2024-10-08 has glDate = 2024-10-08.
  // The operator overrides via the Stage 2 "GL Posting Date" date picker when
  // running a real period close.
  const glDateOverride = opts && opts.glDate ? opts.glDate : null;
  const ctx = { legal: instr.legalEntity, leid: instr.leid, deal: instr.deal, position: instr.position, sec: instr.incomeSecurity };
  const entries = [];
  let jeIndex = 1;
  const add = (transType, amount, isDebit, account, effDate, comments) => {
    entries.push({
      legalEntity: ctx.legal, leid: ctx.leid, batchId: 1, jeIndex: jeIndex, txIndex: isDebit?2:1,
      glDate: glDateOverride || effDate,        // auto = effectiveDate per row, else override
      effectiveDate: effDate,
      deal: ctx.deal, position: ctx.position, incomeSecurity: ctx.sec,
      transactionType: transType, account: account,
      allocationRule: 'No Allocation',           // NWF default for the loan module
      batchType: 'Loan Calculator',
      batchComments: `Loan Calculator Entries from ${summary.periodStart} to ${summary.periodEnd}`,
      transactionComments: comments,
      originalAmount: isDebit ? amount : amount,
      amountLE: Math.abs(amount),
      fx: 1, amountLocal: Math.abs(amount),
      isDebit, leDomain: 'NWF'                    // NWF instead of generic Investran Global
    });
  };

  /* ─── Fees received before any drawdown (IFRS 9 §B5.4.1) ───────────────────
     An arrangement or commitment fee that is integral to the effective rate
     and lands before the facility is drawn has no loan asset to net against.
     Two moments, not one:

       on receipt    DR Cash                      CR Deferred Fee Liability
       on drawdown   DR Deferred Fee Liability    CR Loan Asset

     After the release the asset opens at principal less the fee — 100m drawn
     against a 2m fee carries at 98m — and the fee accretes back into interest
     income over the life through the EIR, which is what makes it integral.

     Only fired when the fee genuinely precedes the first draw. A fee paid on
     the drawdown date itself needs no liability leg: the existing opening
     carrying amount already nets it, and emitting both would double-count. */
  (function emitDeferredFeeOnUndrawnFacility(){
    const feesAll = Array.isArray(instr.fees) ? instr.fees : [];
    if(!feesAll.length) return;
    // First drawdown: an explicit draw in the schedule, else the settlement
    // date when the loan was funded at inception.
    const draws = (Array.isArray(instr.principalSchedule) ? instr.principalSchedule : [])
      .filter(e => e && e.date && (e.type === 'draw' || e.type === 'initialPurchase'))
      .map(e => e.date).sort();
    const drawnAtSettle = (+instr.drawnInitially || 0) > 0 || !draws.length;
    const firstDraw = drawnAtSettle ? instr.settlementDate : draws[0];
    if(!firstDraw) return;
    const base = (+instr.commitment || +instr.faceValue || 0);
    for(const f of feesAll){
      if(!f || !/EIR$/.test(f.ifrs || '')) continue;
      if(f.frequency !== 'oneOff') continue;
      const paid = f.paymentDate || instr.settlementDate;
      if(!paid || paid >= firstDraw) continue;        // not an undrawn-period fee
      const amt = (f.mode === 'flat' || f.mode === 'fixed')
        ? (+f.amount || 0)
        : ((+f.rate || 0) * base);
      if(!(Math.abs(amt) > 0.005)) continue;
      const label = f.label || f.kind || 'fee';
      add('Deferred Fee — Cash Received', amt, true, '111000', paid,
          label + ' received ' + paid + ' — no loan asset exists yet, so the fee is '
          + 'carried as a liability rather than netted against a nil balance');
      add('Deferred Fee Liability', amt, false, '211000', paid,
          label + ' — integral to the effective interest rate (IFRS 9 §B5.4.1), '
          + 'deferred until first drawdown');
      jeIndex++;
      add('Deferred Fee Release on Drawdown', amt, true, '211000', firstDraw,
          label + ' released on first drawdown ' + firstDraw);
      add('Deferred Fee — Loan Asset Adjustment', amt, false, '141000', firstDraw,
          label + ' netted against the loan asset — amortised cost opens at '
          + 'principal less the deferred fee, which then accretes back through the EIR');
      jeIndex++;
    }
  })();

  // Interest pair
  if(summary.totalCashAccrual){
    // Direction fix: accrual JE is DR Receivable / CR Income (asset up, revenue
    // up). Previously emitted with the legs flipped — caught during Transtype #3
    // regression. Affects every loan with non-zero accrued cash interest.
    // Phase A covenants — when a covenant breach margin step-up was active in
    // this period, suffix the memo so the auditor sees the rate uplift source
    // in the workpaper. Step-up only shows up when at least one day in the
    // window had a non-zero covenantMarginStepBps.
    const stepUpSuffix = (summary.covenantMarginStepUpBpsMax || 0) > 0
      ? ` — includes covenant-breach step-up +${summary.covenantMarginStepUpBpsMax}bps`
      : '';
    add('Interest Receivable',           summary.totalCashAccrual, true,  '40100', summary.periodEnd, `Interest Adjustment for ${summary.periodEnd}${stepUpSuffix}`);
    add('Income - Daily Accrued Interest', summary.totalCashAccrual, false, '23000', summary.periodEnd, `Interest Adjustment for ${summary.periodEnd}${stepUpSuffix}`);
    jeIndex++;
  }
  /* PIK capitalisation pair.

     This was written as a RECLASS with negative amounts — DR 'PIK Investment'
     −cap, CR 'Interest Receivable' −cap — on the premise that PIK had already
     been raised as a receivable and was now being moved into the loan asset.
     That premise is false: PIK accrues in its own tracker (cumPikAccrued) and
     never touches totalCashAccrual, so no receivable exists to reverse. The
     pair therefore reversed a receivable that was never raised, and because
     the balance check sums absolute values a negative DR/CR pair cannot tie at
     all — the batch came out short by exactly the PIK total. The same fault
     was found and fixed on the external feed path (see the 'PIK Interest
     Capitalised' block in the builder, which records Ardersier failing by
     £94,266,381.62, exactly its PIK); the internal path kept the broken
     version because no internally built deal ever capitalised anything until
     date-banded PIK started working.

     What is economically true is simpler, and is what both paths now post: the
     borrower owes more and the lender has earned income. DR the loan asset,
     CR PIK interest income, both positive. The transaction-type names are the
     ones applyInvestranGLMapping already routes to loanPikCapitalisation and
     interestIncomePIK, so the accounts follow without a second mapping rule. */
  if(Math.abs(summary.totalCapitalized || 0) > 0.005){
    const cap = Math.abs(summary.totalCapitalized);
    add('PIK Interest Capitalised', cap, true,  '141000', summary.periodEnd, `PIK Capitalization for ${summary.periodEnd}`);
    add('PIK Interest Income',      cap, false, '421000', summary.periodEnd, `PIK Capitalization for ${summary.periodEnd}`);
    jeIndex++;
  }
  // Amortization — Transtype #1 (Discount Accretion) / #2 (Premium Amortization)
  // Direction flips on sign:
  //   • totalAmort > 0 (OID):     income CR / carrying DR   (income up, CV up)
  //   • totalAmort < 0 (premium): income DR / carrying CR   (income down, CV down)
  // Per IFRS 9 §B5.4 / ASC 310-20-35-26.
  if(Math.abs(summary.totalAmort) > 0.005){
    const isAccretion = summary.totalAmort > 0;
    const label = isAccretion ? 'Discount Accretion' : 'Premium Amortization';
    const absAmt = Math.abs(summary.totalAmort);
    // Income leg
    add(label,            absAmt, /*isDebit*/!isAccretion, '40150', summary.periodEnd, `${label} for ${summary.periodEnd}`);
    // Carrying-value (offset) leg
    add(label + ' Offset', absAmt, /*isDebit*/isAccretion,  '23000', summary.periodEnd, `${label} for ${summary.periodEnd}`);
    jeIndex++;
  }
  // Non-use fee
  if(summary.totalNonUseFee > 0.005){
    add('Non-Use Fee Income', summary.totalNonUseFee, false, '40200', summary.periodEnd, `Non-use fee for ${summary.periodEnd}`);
    add('Non-Use Fee Receivable', summary.totalNonUseFee, true, '23100', summary.periodEnd, `Non-use fee for ${summary.periodEnd}`);
    jeIndex++;
  }
  // Hedge accounting (IFRS 9 §6) — three components per period:
  //  1) CFH effective portion → DR/CR Hedging Instrument (16000) / Cash Flow Hedge Reserve OCI (35000)
  //  2) Ineffective (CFH) or full MTM (FVH) → DR/CR Hedging Instrument / P&L Hedge Ineffectiveness (45100) / FV Hedge P&L (45200)
  //  3) Reclassification on settlement → DR Cash Flow Hedge Reserve / CR Hedge Income (45100)
  if(Math.abs(summary.totalHedgeOCI || 0) > 0.005){
    const v = summary.totalHedgeOCI;
    if(v > 0){
      // Transtype #22 — Route to FX Hedge Reserve when this is an FX hedge of principal
      const isFXP = (instr.hedge?.type === 'FXP' || instr.hedge?.subType === 'fxPrincipal');
      const ociLabel = isFXP ? 'FX Hedge Reserve (OCI · FX Principal)' : 'Cash Flow Hedge Reserve (OCI)';
      const instrLabel = isFXP ? 'FX Hedging Instrument MTM' : 'Hedging Instrument MTM (CFH OCI)';
      const periodComment = isFXP ? `FX hedge of principal — effective portion to OCI ${summary.periodEnd}` : `CFH effective portion to OCI for ${summary.periodEnd}`;
      add(instrLabel,  v, true,  '16000', summary.periodEnd, periodComment);
      add(ociLabel,    v, false, '35000', summary.periodEnd, periodComment);
    } else {
      add(instrLabel, -v, false, '16000', summary.periodEnd, periodComment);
      add(ociLabel,   -v, true,  '35000', summary.periodEnd, periodComment);
    }
    jeIndex++;
  }
  if(Math.abs(summary.totalHedgePL || 0) > 0.005){
    const v = summary.totalHedgePL;
    const acct = (instr.hedge?.type === 'FVH') ? '45200' : '45100';
    const label = (instr.hedge?.type === 'FVH') ? 'Fair Value Hedge P&L' : 'Hedge Ineffectiveness P&L';
    if(v > 0){
      add('Hedging Instrument MTM',  v, true,  '16000', summary.periodEnd, `Hedge MTM to P&L for ${summary.periodEnd}`);
      add(label,                     v, false, acct,    summary.periodEnd, `Hedge MTM to P&L for ${summary.periodEnd}`);
    } else {
      add('Hedging Instrument MTM', -v, false, '16000', summary.periodEnd, `Hedge MTM to P&L for ${summary.periodEnd}`);
      add(label,                    -v, true,  acct,    summary.periodEnd, `Hedge MTM to P&L for ${summary.periodEnd}`);
    }
    jeIndex++;
  }
  if(Math.abs(summary.totalHedgeReclass || 0) > 0.005){
    const v = summary.totalHedgeReclass;
    // Transtype #21 — Distinguish post-de-designation amortisation from
    // settlement-driven CFH reclass. Both flow to interest income but with
    // different transtype labels so reports / disclosures can split them.
    const isDeDed = !!instr.hedgeDeDesignationDate;
    const reclassLabel = isDeDed
      ? 'Hedge Reserve Reclass — De-Designation Amortisation'
      : 'CFH Reserve Recycling — Settlement Reclass';
    const reclassComment = isDeDed
      ? `Post-de-designation amortisation to P&L (IFRS 9 §6.5.6) ${summary.periodEnd}`
      : `CFH reclass to P&L on settlement (IFRS 9 §6.5.11) ${summary.periodEnd}`;
    if(v > 0){
      add('Cash Flow Hedge Reserve Reclass',  v, true,  '35000', summary.periodEnd, reclassComment);
      add(reclassLabel,                       v, false, '45100', summary.periodEnd, reclassComment);
    } else {
      add('Cash Flow Hedge Reserve Reclass', -v, false, '35000', summary.periodEnd, reclassComment);
      add(reclassLabel,                      -v, true,  '45100', summary.periodEnd, reclassComment);
    }
    jeIndex++;
  }
  /* Modification gain/loss — framework-aware label
     (IFRS 9 §5.4.3 / ASC 470-50 / AASB 9 §5.4.3).

     Posted ON THE MODIFICATION DATE, one entry per event. This used to book
     the period total at summary.periodEnd — the end of the modelling horizon —
     so a restructuring agreed on 1 January 2026 appeared in the ledger dated
     31 December 2030, four years after the event and in the wrong reporting
     period entirely. §5.4.3 recognises the adjustment when the terms change,
     not when the model runs out. Falls back to periodEnd only when no dated
     events were carried out of the schedule. */
  const fwm = (instr.accountingFramework || 'IFRS').toUpperCase();
  const modTag = fwm === 'USGAAP' ? 'ASC 470-50' : fwm === 'AASB' ? 'AASB 9'
               : fwm === 'ASPE' ? 'ASPE 3856' : 'IFRS 9';
  const modEvts = (Array.isArray(summary.modEvents) && summary.modEvents.length)
    ? summary.modEvents.filter(m => m && Math.abs(+m.gainLoss || 0) > 0.005)
    : (Math.abs(summary.totalModGain || 0) > 0.005
        ? [{ date: summary.periodEnd, gainLoss: summary.totalModGain, description: null }]
        : []);
  for(const mev of modEvts){
    const v = +mev.gainLoss || 0;
    const when = mev.date || summary.periodEnd;
    const memo = (v > 0 ? 'Modification gain' : 'Modification loss') + ' on ' + when +
                 (mev.description ? ' — ' + mev.description : '');
    if(v > 0){
      add('Modification Gain (' + modTag + ')',   v, false, '44000', when, memo);
      add('Modification — Loan Asset Adjustment', v, true,  '15000', when, memo);
    } else {
      add('Modification Loss (' + modTag + ')',  -v, true,  '44000', when, memo);
      add('Modification — Loan Asset Adjustment',-v, false, '15000', when, memo);
    }
    jeIndex++;
  }
  // Credit-loss provisioning — DR Impairment expense / CR Loan Loss Allowance.
  // Net change can be positive (build-up) or negative (release on stage migration / paydown).
  // V3 — Memo references the right standard for the deal's accounting framework:
  //   IFRS  → IFRS 9 §5.5 ECL
  //   AASB  → AASB 9 ECL
  //   USGAAP → ASC 326 CECL (Current Expected Credit Loss)
  //   ASPE  → ASPE §3856 incurred-loss
  if(Math.abs(summary.totalECLChange || 0) > 0.005){
    const v = summary.totalECLChange;
    const fw = (instr.accountingFramework || 'IFRS').toUpperCase();
    const eclLabel =
      fw === 'USGAAP' ? 'ASC 326 CECL' :
      fw === 'AASB'   ? 'AASB 9 ECL' :
      fw === 'ASPE'   ? 'ASPE 3856 incurred-loss' :
                        'IFRS 9 ECL';
    // Phase A covenants — when a covenant-driven SICR escalated the stage in
    // this period, suffix the memo with the standard's SICR citation so the
    // workpaper trail shows the trigger source.
    const sicrCitation =
      fw === 'USGAAP' ? 'ASC 326-20-30-2' :
      fw === 'AASB'   ? 'AASB 9 §B5.5.17' :
      fw === 'ASPE'   ? 'ASPE 3856.16' :
                        'IFRS 9 §B5.5.17';
    const sicrSuffix = summary.covenantSICRTriggered
      ? ` — SICR triggered by covenant breach (${sicrCitation})`
      : '';
    if(v > 0){
      add('Impairment Expense (ECL)',           v, true,  '70100', summary.periodEnd, `${eclLabel} provision for ${summary.periodEnd}${sicrSuffix}`);
      add('Loan Loss Allowance (Contra-Asset)', v, false, '15500', summary.periodEnd, `${eclLabel} provision for ${summary.periodEnd}${sicrSuffix}`);
    } else {
      add('Impairment Reversal (ECL)',          -v, false, '70100', summary.periodEnd, `${eclLabel} release for ${summary.periodEnd}${sicrSuffix}`);
      add('Loan Loss Allowance Reversal',       -v, true,  '15500', summary.periodEnd, `${eclLabel} release for ${summary.periodEnd}${sicrSuffix}`);
    }
    jeIndex++;
  }
  // FX revaluation gain/loss — DR/CR Forex P&L (45000) / Loan Asset (15000)
  if(Math.abs(summary.totalFXGain || 0) > 0.005){
    const v = summary.totalFXGain;
    if(v > 0){
      add('FX Revaluation Gain', v, false, '45000', summary.periodEnd, `FX reval (functional currency) for ${summary.periodEnd}`);
      add('FX Revaluation — Loan Asset Adjustment', v, true,  '15000', summary.periodEnd, `FX reval (functional currency) for ${summary.periodEnd}`);
    } else {
      add('FX Revaluation Loss', -v, true,  '45000', summary.periodEnd, `FX reval (functional currency) for ${summary.periodEnd}`);
      add('FX Revaluation — Loan Asset Adjustment', -v, false, '15000', summary.periodEnd, `FX reval (functional currency) for ${summary.periodEnd}`);
    }
    jeIndex++;
  }
  // Default interest (penalty rate × outstanding balance from event date)
  if((summary.totalDefaultInterest || 0) > 0.005){
    add('Default Interest Income',     summary.totalDefaultInterest, false, '40130', summary.periodEnd, `Default interest for ${summary.periodEnd}`);
    add('Default Interest Receivable', summary.totalDefaultInterest, true,  '23130', summary.periodEnd, `Default interest for ${summary.periodEnd}`);
    jeIndex++;
  }
  // Default fee (one-off penalty fee on event date)
  if((summary.totalDefaultFee || 0) > 0.005){
    add('Default Fee Income',     summary.totalDefaultFee, false, '40140', summary.periodEnd, `Default fee for ${summary.periodEnd}`);
    add('Default Fee Receivable', summary.totalDefaultFee, true,  '23140', summary.periodEnd, `Default fee for ${summary.periodEnd}`);
    jeIndex++;
  }
  // EIR accretion of deferred origination fees (arrangement / OID-style).
  // DR Loan carrying value (40110) / CR Interest income (40100).
  // V3 — JE memo and transtype label now reflect the deal's accounting
  // framework. IFRS labels were applied to USGAAP / AASB / ASPE deals too,
  // confusing users on Ferhat Float (USGAAP).
  //   IFRS  → "IFRS 9 §B5.4 EIR"
  //   AASB  → "AASB 9 EIR"
  //   USGAAP → "ASC 310-20 effective-yield"
  //   ASPE  → "ASPE 3856 effective-interest"
  if(Math.abs(summary.totalEIRAccretion || 0) > 0.005){
    const v = summary.totalEIRAccretion;
    const fw = (instr.accountingFramework || 'IFRS').toUpperCase();
    const eirTag =
      fw === 'USGAAP' ? 'ASC 310-20' :
      fw === 'AASB'   ? 'AASB 9' :
      fw === 'ASPE'   ? 'ASPE 3856' :
                        'IFRS 9';
    add('EIR Fee Accretion ('        + eirTag + ')', v, false, '40100', summary.periodEnd, `${eirTag} EIR fee accretion for ${summary.periodEnd}`);
    add('EIR Fee Accretion Offset (' + eirTag + ')', v, true,  '40110', summary.periodEnd, `${eirTag} EIR fee accretion for ${summary.periodEnd}`);
    jeIndex++;
  }
  // Fee income — framework-aware tag (IFRS 15 / ASC 606 / AASB 15 / ASPE 3400).
  // GL split: 40250 Fee Income (commitment / arrangement / guarantee), 23150 Fee Receivable.
  const fb = summary.feeBreakdown || {};
  const fwf = (instr.accountingFramework || 'IFRS').toUpperCase();
  const feeTag = fwf === 'USGAAP' ? 'ASC 606' : fwf === 'AASB' ? 'AASB 15' : fwf === 'ASPE' ? 'ASPE 3400' : 'IFRS 15';
  for(const [label, amt] of Object.entries(fb)){
    if(Math.abs(amt) <= 0.005) continue;
    add(`${label} Income (${feeTag})`,   amt, false, '40250', summary.periodEnd, `${label} accrual for ${summary.periodEnd}`);
    add(`${label} Receivable`,           amt, true,  '23150', summary.periodEnd, `${label} accrual for ${summary.periodEnd}`);
    jeIndex++;
  }
  // ----- CASH-LEG JEs (closes the half-double-entry gap) -------------------
  // Drawdowns: DR Loan Asset (15000) / CR Cash (10000) — one pair per draw event
  // Repayments: DR Cash (10000) / CR Loan Asset (15000) — one pair per repayment
  // Cash settlement of accrued income at period end: DR Cash / CR Receivable
  // (clears the corresponding 23000/23130/23140/23150 receivables booked above).
  // ── Transtype #3 — Mid-period purchase (accrued interest paid at trade) ──
  // When NWF acquires a loan mid-coupon-period, the buyer pays the seller for
  // accrued-but-unpaid interest at the trade date. That amount is held as a
  // receivable and clears on the next coupon when the buyer receives the full
  // coupon. Emit a JE pair on the trade date (= recognition date for NWF):
  //   DR 113000 Interest Receivable   (purchased accrual)
  //   CR 111000 Cash                  (cash paid to seller)
  // Only emits if instr.tradeAccruedInterest is a positive number.
  if(typeof instr.tradeAccruedInterest === 'number' && instr.tradeAccruedInterest > 0.005){
    const tradeDate = instr.tradeDate || instr.settlementDate;
    add('Accrued Interest Receivable (purchased at trade)', instr.tradeAccruedInterest, true,  '40100', tradeDate,
        `Accrued interest paid to seller at trade · ${tradeDate}`);
    add('Accrued Interest Cash Paid (at trade)',            instr.tradeAccruedInterest, false, '10000', tradeDate,
        `Cash paid to seller for accrued interest at trade · ${tradeDate}`);
    jeIndex++;
  }
  // ── Transtype #18 — Trade vs Settlement Date Accounting ──
  // Per IFRS 9 §B3.1.5: a financial asset purchased may be recognised either
  // on trade date (commitment date) or settlement date (cash exchange).
  // Policy is applied consistently to a category of assets.
  //
  // When instr.tradeDate < instr.settlementDate AND
  // instr.tradeAccountingMethod === 'tradeDate', emit a pre-recognition pair
  // on trade date and the offsetting reversal on settle date so the
  // GL trail shows the unsettled-period exposure cleanly.
  //
  //   tradeDate (T+0)   : DR 141000 Loan Asset / CR 232000 Unsettled Trade Payable
  //   settleDate (T+n)  : DR 232000 Unsettled Trade Payable / CR 141000 Loan Asset
  //   settleDate (T+n)  : DR 141000 Loan Asset / CR 111000 Cash (existing draw JE)
  //
  // Net effect: the loan asset shows on day T+0 (commitment recognised) and
  // the cash hits on T+n. Total carrying value at end of T+n is unchanged.
  if(instr.tradeAccountingMethod === 'tradeDate' && instr.tradeDate && instr.tradeDate < instr.settlementDate){
    const initialDraw = (summary.rows[0]?.balance || 0);   // opening balance = face committed
    const tradeAmt    = +instr.faceValue || +instr.commitment || initialDraw;
    if(tradeAmt > 0.005){
      add('Trade-Date Recognition — Loan Asset',
          tradeAmt, true,  '141000', instr.tradeDate, `Trade-date recognition — IFRS 9 §B3.1.5 · ${instr.tradeDate}`);
      add('Trade-Date Recognition — Unsettled Trade Payable',
          tradeAmt, false, '232000', instr.tradeDate, `Unsettled trade payable booked on trade date · ${instr.tradeDate}`);
      jeIndex++;
      // Reversal on settlement date (immediately before the cash-settlement JE
      // that the existing draw handler will emit)
      add('Settlement-Date Reversal — Unsettled Trade Payable',
          tradeAmt, true,  '232000', instr.settlementDate, `Reverse unsettled trade payable on settle · ${instr.settlementDate}`);
      add('Settlement-Date Reversal — Loan Asset (Unsettled)',
          tradeAmt, false, '141000', instr.settlementDate, `Reverse trade-date asset booking on settle · ${instr.settlementDate}`);
      jeIndex++;
    }
  }
  /* ─── Acquisition of a purchased asset ───────────────────────────────────
     A purchased loan is recognised at what was PAID, not at the face value of
     the claim acquired (IFRS 9 §5.1.1). buildSchedule already opens the
     carrying amount at the consideration — that is why the POCI schedule
     starts at 60,000,000 against a 100,000,000 face — but this journal was
     posting the face, so the ledger and the schedule on the same run
     disagreed by the whole discount: £100m of cash shown leaving when £60m
     did, and the loan asset recognised 40m above what the schedule carried.

     Only the acquisition itself is re-priced. A later drawdown on a purchased
     facility is funded at par and keeps its own amount, so the substitution is
     limited to the first draw on the settlement date. */
  const _acqConsideration = (instr.purchasePrice != null && +instr.purchasePrice > 0)
    ? +instr.purchasePrice : null;
  let _acqPosted = false;

  for(const r of summary.rows){
    if(r.draw && r.draw > 0.005){
      const isAcquisition = _acqConsideration != null && !_acqPosted
                         && r.date === instr.settlementDate;
      const drawAmt = isAcquisition ? _acqConsideration : r.draw;
      const memo = isAcquisition
        ? `Acquisition ${r.date} — consideration paid for a ${Math.round(r.draw).toLocaleString('en-GB')} claim`
        : `Drawdown ${r.date}`;
      add('Loan Drawdown',          drawAmt, true,  '15000', r.date, memo);
      add('Loan Drawdown — Cash',   drawAmt, false, '10000', r.date, memo);
      if(isAcquisition) _acqPosted = true;
      jeIndex++;
    }
    if(r.paydown && r.paydown > 0.005){
      add('Loan Repayment — Cash',   r.paydown, true,  '10000', r.date, `Repayment ${r.date}`);
      add('Loan Repayment',          r.paydown, false, '15000', r.date, `Repayment ${r.date}`);
      jeIndex++;
    }
    // Transtype #4 — Prepayment. Same DR/CR pattern as scheduled repayment
    // but with a distinct transtype so it can be filtered separately in the
    // GL / DIU output and audit reports.
    if(r.prepayment && r.prepayment > 0.005){
      // Transtype #16 — Mandatory Prepayment Events. If part of today's
      // prepayment was mandatory (covenant-triggered: excess cash flow sweep,
      // change-of-control, asset sale proceeds, IPO, insurance), emit a
      // separate JE pair carrying the trigger reason in the comments so
      // covenant tracking / lender reporting can isolate it cleanly.
      const mandatory = r.mandatoryPrepayment || 0;
      const voluntary = Math.max(0, r.prepayment - mandatory);
      const trigStr   = (r.mandatoryTriggers && r.mandatoryTriggers.length)
                       ? ' (' + r.mandatoryTriggers.join(', ') + ')' : '';
      if(voluntary > 0.005){
        add('Loan Prepayment — Cash',  voluntary, true,  '10000', r.date, `Prepayment ${r.date}`);
        add('Loan Prepayment',         voluntary, false, '15000', r.date, `Prepayment ${r.date}`);
        jeIndex++;
      }
      if(mandatory > 0.005){
        add('Mandatory Prepayment — Cash', mandatory, true,  '10000', r.date, `Mandatory prepayment ${r.date}${trigStr}`);
        add('Mandatory Prepayment',        mandatory, false, '15000', r.date, `Mandatory prepayment ${r.date}${trigStr}`);
        jeIndex++;
      }
    }
    // Transtype #5 — Prepayment penalty / make-whole income. Cash received from
    // borrower over and above the prepaid principal; recognised immediately as
    // fee/penalty income (not part of EIR per IFRS 9 §B5.4 / ASC 310-20-25-12).
    if(r.prepayPenalty && r.prepayPenalty > 0.005){
      add('Prepayment Penalty — Cash', r.prepayPenalty, true,  '10000', r.date, `Prepayment penalty ${r.date}`);
      add('Prepayment Penalty Income', r.prepayPenalty, false, '40250', r.date, `Prepayment penalty ${r.date}`);
      jeIndex++;
    }
    // Transtype #8 — Write-off. Three-legged JE that uses up the existing ECL
    // allowance first, then takes the residual to P&L as a current-period
    // impairment expense. Asset side credited for the full gross write-off.
    if(r.writeOff && r.writeOff > 0.005){
      const allowUsed = r.writeOffAllowanceUsed || 0;
      const residual  = r.writeOffResidualExpense || 0;
      if(allowUsed > 0.005){
        add('Loan Write-Off — Allowance Applied', allowUsed, true,  '14500', r.date, `Write-off allowance application ${r.date}`);
      }
      if(residual > 0.005){
        add('Loan Write-Off — Residual Expense', residual, true,  '47000', r.date, `Write-off residual impairment ${r.date}`);
      }
      add('Loan Write-Off — Asset Derecognition', r.writeOff, false, '15000', r.date, `Loan asset written off ${r.date}`);
      jeIndex++;
    }
    // Transtype #9 — Recovery post-write-off. Cash received from a borrower /
    // bankruptcy estate / guarantor / collateral realisation AFTER write-off.
    // IFRS 9 §B5.5.43 / ASC 326-20-30 credit the income to the same line that
    // absorbed the original write-off (470000 Impairment), effectively
    // reversing prior expense.
    if(r.recovery && r.recovery > 0.005){
      // Transtype #24 — When `recoveryAllocation` is present, split the cash
      // receipt across the four buckets (principal, default interest, default
      // fees, legal). Each bucket emits its own JE pair with a distinct label
      // so the IFRS 7 §35K recovery analysis can trace where cash landed.
      const alloc = r.recoveryAllocation;
      if(alloc){
        const buckets = [
          { key:'principal',   amt: +alloc.principal  || 0, label:'Recovery — Principal (Write-Off Reversal)',  glAcct:'47000' },
          { key:'defaultInt',  amt: +alloc.defaultInt || 0, label:'Recovery — Default Interest Allocation',     glAcct:'42100' },
          { key:'defaultFee',  amt: +alloc.defaultFee || 0, label:'Recovery — Default Fee Allocation',           glAcct:'49200' },
          { key:'legal',       amt: +alloc.legal      || 0, label:'Recovery — Legal Cost Reimbursement',         glAcct:'54300' }
        ];
        for(const b of buckets){
          if(b.amt <= 0.005) continue;
          add('Recovery — Cash Receipt (' + b.key + ')', b.amt, true,  '10000', r.date, `Recovery cash allocated to ${b.key} ${r.date}`);
          add(b.label,                                    b.amt, false, b.glAcct, r.date, `Recovery cash allocated to ${b.key} ${r.date}`);
          jeIndex++;
        }
        // If allocation doesn't equal total recovery, residual hits Impairment Reversal
        const allocSum = buckets.reduce((s,b) => s + b.amt, 0);
        const residual = r.recovery - allocSum;
        if(residual > 0.005){
          add('Recovery — Cash Receipt (unallocated)', residual, true,  '10000', r.date, `Unallocated recovery residual ${r.date}`);
          add('Recovery of Written-Off Loan',          residual, false, '47000', r.date, `Unallocated recovery residual ${r.date}`);
          jeIndex++;
        }
      } else {
        // Legacy single-bucket path
        add('Recovery — Cash Receipt',              r.recovery, true,  '10000', r.date, `Post-write-off recovery ${r.date}`);
        add('Recovery of Written-Off Loan',         r.recovery, false, '47000', r.date, `Post-write-off recovery ${r.date}`);
        jeIndex++;
      }
    }
    // Transtype #10 — Cure / Stage Reversal. Stage 3 → Stage 2/1 transition
    // releases the existing ECL allowance back to P&L. JE pair reverses the
    // prior allowance build (DR Allowance / CR Impairment Expense).
    if(r.cureRelease && r.cureRelease > 0.005){
      add('ECL Cure — Allowance Reversal',       r.cureRelease, true,  '14500', r.date, `Stage cure / allowance release ${r.date}`);
      add('ECL Cure — Impairment Reversal',      r.cureRelease, false, '47000', r.date, `Stage cure / allowance release ${r.date}`);
      jeIndex++;
    }
    // Transtype #23 — Allowance Reversal (Without Stage Change). Same DR/CR
    // mechanic as cure (DR Allowance / CR Impairment) but with distinct
    // transtype labels so IFRS 7 §35F ECL roll-forward can split model-
    // recalibration movements from stage-driven movements.
    if(r.allowanceReversal && r.allowanceReversal > 0.005){
      add('Allowance Reversal — Model Recalibration',  r.allowanceReversal, true,  '14500', r.date, `Model-driven allowance reversal (no stage change) ${r.date}`);
      add('Impairment Reversal — Model Recalibration', r.allowanceReversal, false, '47000', r.date, `Model-driven allowance reversal (no stage change) ${r.date}`);
      jeIndex++;
    }
    // Transtype #11 — Forbearance / Payment Holiday. One-time booking on the
    // forbearance start date that reclassifies the expected deferred interest
    // from the regular receivable (113000) to a separate "Deferred Interest"
    // sub-account. Subsequent accruals continue and naturally accumulate in
    // the deferred bucket until the holiday ends.
    if(r.forbearanceStartDeferred && r.forbearanceStartDeferred > 0.005){
      add('Forbearance — Deferred Interest Reclass',  r.forbearanceStartDeferred, true,  '40100', r.date, `Forbearance deferral ${r.date}`);
      add('Forbearance — Interest Receivable Reduction', r.forbearanceStartDeferred, false, '40100', r.date, `Forbearance deferral ${r.date}`);
      jeIndex++;
    }
    // Transtype #12 — Capitalised origination costs. Costs PAID by NWF at
    // origination (legal, transaction, valuation) that capitalise into the
    // loan's carrying value per IFRS 9 §B5.4 / ASC 310-20-25-2.
    if(r.capitalisedCost && r.capitalisedCost > 0.005){
      add('Capitalised Origination Costs',           r.capitalisedCost, true,  '15000', r.date, `Capitalised cost into carrying ${r.date}`);
      add('Capitalised Origination Costs — Cash',    r.capitalisedCost, false, '10000', r.date, `Capitalised cost cash paid ${r.date}`);
      jeIndex++;
      // ── Transtype #25 — Origination Cost Deferral on Revolvers (ASC 310-20-25-19) ──
      // When the deal's revolverCostDeferralBasis === 'commitment', the
      // origination cost amortises over the COMMITMENT period (settlement →
      // availabilityEnd) rather than the loan maturity. Emit a documentation
      // JE that captures the policy choice for the audit trail. The actual
      // amortisation flows through the existing EIR mechanism (the higher
      // day-1 carrying yields a lower EIR over the commitment period).
      if(instr.revolverCostDeferralBasis === 'commitment' && instr.availabilityEnd && r.date === instr.settlementDate){
        add('Revolver Cost Deferral Policy — Commitment Basis (ASC 310-20-25-19)',
            r.capitalisedCost, true,  '15000', r.date,
            `Origination cost amortises over commitment period (settle → ${instr.availabilityEnd}) per ASC 310-20-25-19, not over loan maturity (${instr.maturityDate})`);
        add('Revolver Cost Deferral Policy — Offset (zero net effect)',
            r.capitalisedCost, false, '15000', r.date,
            `Memo entry — policy disclosure only; no net carrying-value impact`);
        jeIndex++;
      }
    }
    // Transtype #13 — Loan Sale (full derecognition). Per IFRS 9 §3.2.3 /
    // ASC 860: derecognise the entire carrying amount; book sale proceeds to
    // cash; the difference between proceeds and carrying value flows to P&L
    // as Gain/(Loss) on Sale of Loan.
    //
    // We split the booking into two JE pairs so the gain/loss leg is visible:
    //   JE-A (always)    DR Cash 111000           CR Loan Asset 141000  (at carrying)
    //   JE-B (gain)      DR Cash 111000           CR Gain on Sale 442000
    //   JE-B (loss)      DR Loss on Sale 542000   CR Loan Asset 141000
    if(r.loanSaleCV && r.loanSaleCV > 0.005){
      const proceeds = r.loanSale || 0;
      const cv       = r.loanSaleCV;
      const gainLoss = r.loanSaleGain || 0;
      // JE-A — derecognise asset against cash up to carrying value
      const baseCash = Math.min(proceeds, cv);   // portion of cash that pairs with asset
      if(baseCash > 0.005){
        add('Loan Sale — Cash Received',         baseCash, true,  '111000', r.date, `Loan sale proceeds ${r.date}`);
        add('Loan Sale — Asset Derecognition',   baseCash, false, '141000', r.date, `Loan sale carrying derecog ${r.date}`);
        jeIndex++;
      }
      // JE-B — gain or loss leg
      if(gainLoss > 0.005){
        // Sold above carrying → gain. Excess cash hits Gain on Sale (P&L credit).
        const excess = gainLoss;
        add('Loan Sale — Cash Received (Gain)',  excess,   true,  '111000', r.date, `Loan sale gain — extra cash ${r.date}`);
        add('Loan Sale — Gain on Disposal',      excess,   false, '442000', r.date, `Gain on loan sale ${r.date}`);
        jeIndex++;
      } else if(gainLoss < -0.005){
        // Sold below carrying → loss. Loss on Sale absorbs the residual carrying value.
        const shortfall = -gainLoss;
        add('Loan Sale — Loss on Disposal',      shortfall, true,  '542000', r.date, `Loss on loan sale ${r.date}`);
        add('Loan Sale — Residual Asset Derecog',shortfall, false, '141000', r.date, `Loan sale residual derecog ${r.date}`);
        jeIndex++;
      }
    }
    // Transtype #14 — Loan Participation / Partial Sell-Down. Per IFRS 9
    // §3.2.6 "fully proportionate share" transfer test. The pro-rata
    // carrying value is derecognised; cash flows in; the difference flows
    // to P&L as Gain/(Loss) on Participation Sale.
    if(r.participationCV && r.participationCV > 0.005){
      const proceeds = r.participation || 0;
      const cv       = r.participationCV;
      const gainLoss = r.participationGain || 0;
      const baseCash = Math.min(proceeds, cv);
      if(baseCash > 0.005){
        add('Loan Participation — Cash Received',          baseCash, true,  '111000', r.date, `Participation proceeds ${r.date}`);
        add('Loan Participation — Asset Derecognition',    baseCash, false, '141000', r.date, `Participation partial derecog ${r.date}`);
        jeIndex++;
      }
      if(gainLoss > 0.005){
        const excess = gainLoss;
        add('Loan Participation — Cash Received (Gain)',   excess,   true,  '111000', r.date, `Participation gain — extra cash ${r.date}`);
        add('Loan Participation — Gain on Disposal',       excess,   false, '442000', r.date, `Gain on participation ${r.date}`);
        jeIndex++;
      } else if(gainLoss < -0.005){
        const shortfall = -gainLoss;
        add('Loan Participation — Loss on Disposal',       shortfall, true,  '542000', r.date, `Loss on participation ${r.date}`);
        add('Loan Participation — Residual Asset Derecog', shortfall, false, '141000', r.date, `Participation residual derecog ${r.date}`);
        jeIndex++;
      }
    }
    // Transtype #15 — Debt-for-Equity Swap. Per IFRIC 19 / ASC 470-50-40:
    // derecognise the loan at carrying; recognise a new equity investment
    // at fair value (FV); the carrying-FV gap is a restructuring loss to
    // P&L. JE pair structure:
    //   DR Equity Investment  142000    (at fair value of equity received)
    //   DR Restructuring Loss 542100    (CV − FV)
    //   CR Loan Asset         141000    (at full carrying)
    if(r.debtEquitySwapCV && r.debtEquitySwapCV > 0.005){
      const fv   = r.debtEquitySwap || 0;
      const cv   = r.debtEquitySwapCV;
      const loss = r.debtEquitySwapLoss || 0;
      if(fv > 0.005){
        add('Debt-for-Equity Swap — Equity Recognition', fv, true,  '142000', r.date, `Equity received at FV — D4E swap ${r.date}`);
        add('Debt-for-Equity Swap — Loan Derecognition (FV portion)', fv, false, '141000', r.date, `Loan derecog at FV portion ${r.date}`);
        jeIndex++;
      }
      if(loss > 0.005){
        add('Debt-for-Equity Swap — Restructuring Loss', loss, true,  '542100', r.date, `Restructuring loss CV-FV ${r.date}`);
        add('Debt-for-Equity Swap — Loan Derecognition (Loss portion)', loss, false, '141000', r.date, `Loan derecog loss portion ${r.date}`);
        jeIndex++;
      } else if(loss < -0.005){
        // Rare — equity FV exceeds loan carrying. Gain on swap.
        const gain = -loss;
        add('Debt-for-Equity Swap — Equity Recognition (Gain)', gain, true, '142000', r.date, `Equity FV > carrying ${r.date}`);
        add('Debt-for-Equity Swap — Restructuring Gain',       gain, false,'442100', r.date, `Restructuring gain FV-CV ${r.date}`);
        jeIndex++;
      }
    }
  }
  // Cash settlement at period end: assume accrued interest + fees paid on
  // periodEnd date (a simplification — real systems track per-fee payment
  // schedules). Pair up to clear the receivables we booked above.
  if(summary.totalCashAccrual > 0.005){
    add('Interest Cash Receipt',     summary.totalCashAccrual, true,  '10000', summary.periodEnd, `Interest cash settlement ${summary.periodEnd}`);
    add('Interest Receivable Clear', summary.totalCashAccrual, false, '23000', summary.periodEnd, `Interest cash settlement ${summary.periodEnd}`);
    jeIndex++;
  }
  for(const [label, amt] of Object.entries(fb)){
    if(Math.abs(amt) <= 0.005) continue;
    add(`${label} Cash Receipt`,            amt, true,  '10000', summary.periodEnd, `${label} cash settlement ${summary.periodEnd}`);
    add(`${label} Receivable Clear`,        amt, false, '23150', summary.periodEnd, `${label} cash settlement ${summary.periodEnd}`);
    jeIndex++;
  }
  if((summary.totalDefaultInterest || 0) > 0.005){
    add('Default Interest Cash Receipt',     summary.totalDefaultInterest, true,  '10000', summary.periodEnd, `Default interest cash settlement ${summary.periodEnd}`);
    add('Default Interest Receivable Clear', summary.totalDefaultInterest, false, '23130', summary.periodEnd, `Default interest cash settlement ${summary.periodEnd}`);
    jeIndex++;
  }
  if((summary.totalDefaultFee || 0) > 0.005){
    add('Default Fee Cash Receipt',          summary.totalDefaultFee, true,  '10000', summary.periodEnd, `Default fee cash settlement ${summary.periodEnd}`);
    add('Default Fee Receivable Clear',      summary.totalDefaultFee, false, '23140', summary.periodEnd, `Default fee cash settlement ${summary.periodEnd}`);
    jeIndex++;
  }
  if(summary.totalNonUseFee > 0.005){
    add('Non-Use Fee Cash Receipt',          summary.totalNonUseFee, true,  '10000', summary.periodEnd, `Non-use fee cash settlement ${summary.periodEnd}`);
    add('Non-Use Fee Receivable Clear',      summary.totalNonUseFee, false, '23100', summary.periodEnd, `Non-use fee cash settlement ${summary.periodEnd}`);
    jeIndex++;
  }
  // ──────────────── Transtype #19 — Period-End Reversing Entries ────────────────
  // Standard month-end-close pattern: every accrual JE posted on periodEnd gets
  // a mirrored "reversing" entry on day 1 of the next period. When the real cash
  // hits later, the cash JE books the full amount to income in the new period.
  // The reverse pair cancels out so net effect is zero — but the audit trail
  // shows the original accrual + its reversal + the eventual cash receipt
  // distinctly, which is how many GLs require accruals to be presented.
  //
  // Triggered when instr.useReversingEntries === true. Filters the entries
  // emitted so far to find accrual-style postings (income/receivable pairs)
  // and emits flipped twins dated to the day after periodEnd.
  if(instr.useReversingEntries && summary.periodEnd){
    const periodEndDate = new Date(summary.periodEnd);
    const nextDay = new Date(periodEndDate.getFullYear(), periodEndDate.getMonth(), periodEndDate.getDate() + 1)
                    .toISOString().slice(0, 10);
    // Identify which JEs to reverse: anything posted on periodEnd that is an
    // accrual (interest, fee, PIK, default interest/fee, EIR accretion) and
    // NOT a cash receipt or settlement.
    const isAccrual = (e) => {
      if(e.effectiveDate !== summary.periodEnd) return false;
      const tt = (e.transactionType || '').toLowerCase();
      const isCash = /cash receipt|cash settlement|receivable clear|drawdown|repayment/.test(tt);
      const isAccrualLike = /interest receivable|interest income|daily accrued|pik|fee receivable|fee income|accretion|amortis|default (interest|fee)|non-use fee/.test(tt);
      return isAccrualLike && !isCash;
    };
    const toReverse = entries.filter(isAccrual);
    for(const orig of toReverse){
      // Emit a DR/CR-flipped twin with a "Reversing —" prefix label
      add(
        'Reversing — ' + (orig.transactionType || ''),
        orig.amountLE,
        !orig.isDebit,         // flip DR ↔ CR
        orig.account,
        nextDay,
        `Auto-reversing entry — cancels ${summary.periodEnd} accrual at next period start`
      );
    }
    if(toReverse.length > 0) jeIndex++;
  }
  return applyInvestranGLMapping(entries);
}

/* ---------- DIU generator — from PortF Data ---------------
   Walks the loaded reference's scheduleResults[] (date-indexed period rows)
   and emits the same DIU JE pair shape that generateDIU() produces from
   our calculator. Used when the DIU Export tab's Source = "PortF Data".
*/
function generateDIUFromReference(instr, referenceData){
  if(!instr || !referenceData || !Array.isArray(referenceData.scheduleResults)) return [];
  const ctx = { legal: instr.legalEntity, leid: instr.leid, deal: instr.deal, position: instr.position, sec: instr.incomeSecurity };
  const entries = [];
  let jeIndex = 1;
  const add = (transType, amount, isDebit, account, effDate, comments) => {
    entries.push({
      legalEntity: ctx.legal, leid: ctx.leid, batchId: 1, jeIndex: jeIndex, txIndex: isDebit?2:1,
      glDate: effDate, effectiveDate: effDate,
      deal: ctx.deal, position: ctx.position, incomeSecurity: ctx.sec,
      transactionType: transType, account: account, allocationRule: isDebit?'Non-Dominant':'By Commitment and GL Date',
      batchType: 'Loan Calculator (PortF)',
      batchComments: `From reference: ${referenceData.source || 'unknown'} · ${effDate}`,
      transactionComments: comments,
      originalAmount: isDebit ? amount : amount,
      amountLE: Math.abs(amount), fx: 1, amountLocal: Math.abs(amount),
      isDebit, leDomain: 'Investran Global · PortF'
    });
  };
  for(const ref of referenceData.scheduleResults){
    const eff = ref.date;
    // Interest accrual pair (+ cash-settlement clear)
    if((ref.interestAccrued || 0) > 0.005){
      // Direction fix (same as main flow): DR Receivable / CR Income for accrual
      add('Interest Receivable',           ref.interestAccrued, true,  '40100', eff, `Interest accrual (PortF) ${eff}`);
      add('Income - Daily Accrued Interest', ref.interestAccrued, false, '23000', eff, `Interest accrual (PortF) ${eff}`);
      jeIndex++;
      add('Interest Cash Receipt',     ref.interestAccrued, true,  '10000', eff, `Interest cash settlement (PortF) ${eff}`);
      add('Interest Receivable Clear', ref.interestAccrued, false, '23000', eff, `Interest cash settlement (PortF) ${eff}`);
      jeIndex++;
    }
    // Fees — by breakdown if provided, else as a single line
    if(ref.feeBreakdown && Object.keys(ref.feeBreakdown).length){
      for(const [label, amt] of Object.entries(ref.feeBreakdown)){
        if(Math.abs(amt) <= 0.005) continue;
        add(`${label} Income (PortF)`,        amt, false, '40250', eff, `${label} accrual (PortF) ${eff}`);
        add(`${label} Receivable`,                amt, true,  '23150', eff, `${label} accrual (PortF) ${eff}`);
        jeIndex++;
        add(`${label} Cash Receipt`,              amt, true,  '10000', eff, `${label} cash settlement (PortF) ${eff}`);
        add(`${label} Receivable Clear`,          amt, false, '23150', eff, `${label} cash settlement (PortF) ${eff}`);
        jeIndex++;
      }
    } else if((ref.totalFees || 0) > 0.005){
      add('Fee Income (PortF)',     ref.totalFees, false, '40250', eff, `Total fees (PortF) ${eff}`);
      add('Fee Receivable',             ref.totalFees, true,  '23150', eff, `Total fees (PortF) ${eff}`);
      jeIndex++;
      add('Fee Cash Receipt',           ref.totalFees, true,  '10000', eff, `Fee cash settlement (PortF) ${eff}`);
      add('Fee Receivable Clear',       ref.totalFees, false, '23150', eff, `Fee cash settlement (PortF) ${eff}`);
      jeIndex++;
    }
    // Drawdown pair
    if((ref.drawdown || 0) > 0.005){
      add('Loan Drawdown',          ref.drawdown, true,  '15000', eff, `Drawdown (PortF) ${eff}`);
      add('Loan Drawdown — Cash',   ref.drawdown, false, '10000', eff, `Drawdown (PortF) ${eff}`);
      jeIndex++;
    }
    // Repayment pair
    if((ref.repayment || 0) > 0.005){
      add('Loan Repayment — Cash',   ref.repayment, true,  '10000', eff, `Repayment (PortF) ${eff}`);
      add('Loan Repayment',          ref.repayment, false, '15000', eff, `Repayment (PortF) ${eff}`);
      jeIndex++;
    }
  }
  return applyInvestranGLMapping(entries);
}

/* ═══════════════════════════════════════════════════════════════════════════
   generateDIUFromExternalFeed — journals for an imported deal
   ───────────────────────────────────────────────────────────────────────────
   For a deal PortF calculates, PCS accounts and does not re-derive. Until now
   the accounting run called generateDIU() for every deal regardless of source,
   so an imported deal was journalised from the ENGINE'S PROJECTION rather than
   from the schedule that was sent. On Marija Example 2 that produced 901 JEs
   running to the facility's 2063 end date from a feed of 27 rows covering
   November 2025 — and, because the projection's first monthly period ended
   after the feed stopped, not one interest journal fell inside the window
   PortF had actually reported.

   This generator posts the received rows and nothing else. There is no
   horizon, no period grid and no forecast: one row in, one JE pair out. The
   ledger therefore ends where the feed ends, which is the honest position —
   a period PortF has not reported is a period PCS has nothing to say about.

   Three rules worth stating, because each was a way of quietly inventing a
   number:

   1. Cash is posted from `cash_settled`, never from the accrual. An accrued
      amount is not evidence that it was paid; a row that accrues 2,500 and
      settles nothing gets an accrual pair and no cash pair.
   2. A posting type we do not map is REPORTED, not skipped. Silently dropping
      a row type would understate income while the run still reported success.
   3. Transaction-type labels are reused verbatim from the existing generators
      because applyInvestranGLMapping routes on that text. Inventing a clearer
      label here would silently change the GL account it lands in.
   ═══════════════════════════════════════════════════════════════════════════ */
function generateDIUFromExternalFeed(instr, rows, opts){
  opts = opts || {};
  const out = { entries: [], unmapped: [], rowsPosted: 0, rowsSkipped: 0,
                minDate: null, maxDate: null };
  if(!instr || !Array.isArray(rows) || !rows.length) return out;

  const system   = opts.system || 'PortF';
  const snapshot = opts.snapshotId || null;
  const glDateOverride = opts.glDate || null;
  const trNames  = opts.trancheNames   || {};
  const cpNames  = opts.componentNames || {};
  const ctx = { legal: instr.legalEntity, leid: instr.leid, deal: instr.deal,
                position: instr.position, sec: instr.incomeSecurity };
  const entries = [];
  let jeIndex = 1;

  const add = (transType, amount, isDebit, account, effDate, comments) => {
    entries.push({
      legalEntity: ctx.legal, leid: ctx.leid, batchId: 1, jeIndex: jeIndex,
      txIndex: isDebit ? 2 : 1,
      glDate: glDateOverride || effDate, effectiveDate: effDate,
      deal: ctx.deal, position: ctx.position, incomeSecurity: ctx.sec,
      transactionType: transType, account: account,
      allocationRule: 'No Allocation',
      batchType: 'Loan Calculator (external feed)',
      batchComments: 'Posted from the ' + system + ' schedule as received' +
                     (snapshot ? ' · snapshot ' + snapshot : '') +
                     ' · no PCS projection',
      transactionComments: comments,
      originalAmount: amount,
      amountLE: Math.abs(amount), fx: 1, amountLocal: Math.abs(amount),
      isDebit, leDomain: 'NWF'
    });
  };

  // "Tranche A · Monthly SONIA · 2025-11-04" — enough for a workpaper to find
  // the source row without opening the workbook.
  const label = r => {
    const bits = [];
    if(r.external_tranche_id   && trNames[r.external_tranche_id])   bits.push(trNames[r.external_tranche_id]);
    else if(r.external_tranche_id)   bits.push(r.external_tranche_id);
    if(r.external_component_id && cpNames[r.external_component_id]) bits.push(cpNames[r.external_component_id]);
    const period = (r.period_start && r.period_end)
      ? r.period_start + '→' + r.period_end
      : (r.flow_date || '');
    bits.push(period);
    return bits.join(' · ');
  };

  /* ── Accrual periods ──────────────────────────────────────────────────────
     A feed row is accrual DETAIL, not a separate economic event. PortF sends
     one row per component per day; the Components sheet separately states how
     often each component accrues ("Quarterly", "Semi-annual") and when it
     first settles. Until now the generator read neither, posting one JE pair
     per received row — so SP013 Hamilton's 3,651 daily rows became 14,628
     journal lines, and the sheet's "Quarterly" changed nothing at all.

     Rows are therefore grouped into the period each component's own sheet
     nominates, and one accrual is recognised per period. No amount moves: a
     period's accrual is the exact sum of its daily rows, so the totals are
     penny-identical to posting them individually. Only the granularity of
     recognition changes, and it changes to the one the file asked for.

     Periods are anchored on First Settlement Date, not on the first row, so
     the boundaries land on the real payment dates — including for rows dated
     before the first settlement, which fall in earlier (negative) periods.

     A component whose frequency is one-off, at-maturity or simply unstated is
     passed through untouched: with nothing stated there is no period to group
     into, and inventing one would be the same mistake in the other direction.
     Drawdowns, repayments and PIK capitalisations are always passed through —
     those are dated events, not accrual detail, and aggregating them would
     move real cash to a date it did not happen on. */
  const _EXT_FREQ_MONTHS = { monthly: 1, quarterly: 3, semiannual: 6, semi: 6,
                             annual: 12, yearly: 12 };
  const _extFreqMonths = f =>
    _EXT_FREQ_MONTHS[String(f || '').toLowerCase().replace(/[^a-z]/g, '')] || null;

  /* Month arithmetic clamped to the month's length, so a 31st anchor gives
     Feb 28/29 rather than rolling into March. */
  const _addMonthsISO = (iso, n) => {
    const d = new Date(iso + 'T00:00:00Z');
    const day = d.getUTCDate();
    const t = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + n, 1));
    const last = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth() + 1, 0)).getUTCDate();
    t.setUTCDate(Math.min(day, last));
    return t.toISOString().slice(0, 10);
  };

  // The smallest boundary (anchor + k·months, k any integer) that is >= date.
  const _extPeriodEnd = (dateISO, anchorISO, months) => {
    const a = new Date(anchorISO + 'T00:00:00Z'), d = new Date(dateISO + 'T00:00:00Z');
    let k = Math.round((((d.getUTCFullYear() - a.getUTCFullYear()) * 12) +
                        (d.getUTCMonth() - a.getUTCMonth())) / months);
    let guard = 0;
    while(_addMonthsISO(anchorISO, k * months) < dateISO && guard++ < 2000) k++;
    while(_addMonthsISO(anchorISO, (k - 1) * months) >= dateISO && guard++ < 4000) k--;
    return _addMonthsISO(anchorISO, k * months);
  };

  const terms = opts.componentTerms || null;
  let feedRows = rows;
  if(terms){
    /* How many rows each component contributes, needed before the loop. A
       component with no stated frequency and ONE row is a genuine one-off —
       the row is the charge and its date is the payment date, so it settles.
       A component with no stated frequency and MANY rows is accrual detail we
       have no schedule for: settling those on their accrual dates is exactly
       the fiction this change removes, so they accrue and the unsettled total
       is reported rather than quietly paid or quietly dropped. */
    const rowsPerComponent = new Map();
    for(const r of rows){
      const k = r.external_component_id;
      if(k) rowsPerComponent.set(k, (rowsPerComponent.get(k) || 0) + 1);
    }

    const passthrough = [], buckets = new Map();
    for(const r of rows){
      const ptype = String(r.posting_type || '').toLowerCase();
      const cid   = r.external_component_id;
      const t     = cid ? terms[cid] : null;
      const months = (ptype === 'interest' || ptype === 'fee') && t
                       ? _extFreqMonths(t.accrualFreq) : null;
      if(!months || !r.flow_date){
        const settlesCash = t && String(t.settlementType || 'cash').toLowerCase() === 'cash';
        const single = cid && rowsPerComponent.get(cid) === 1;
        if((ptype === 'interest' || ptype === 'fee') && settlesCash){
          if(single){
            // One row, one charge, one payment — the £600,000 arrangement fee.
            passthrough.push(Object.assign({}, r, { cash_settled: +r.amount || 0 }));
          } else {
            passthrough.push(r);                       // accrues; cash unknown
            out.unsettled = (out.unsettled || 0) + (+r.amount || 0);
            if(cid && (out.unsettledComponents = out.unsettledComponents || [])
                 .indexOf(cid) === -1) out.unsettledComponents.push(cid);
          }
        } else {
          passthrough.push(r);
        }
        continue;
      }

      const anchor = /^\d{4}-\d{2}-\d{2}$/.test(t.firstSettlement || '')
                       ? t.firstSettlement : r.flow_date;
      const pend = _extPeriodEnd(r.flow_date, anchor, months);
      const key  = cid + '|' + pend;
      let b = buckets.get(key);
      if(!b){
        b = Object.assign({}, r, {
          flow_date: pend, period_start: r.period_start || r.flow_date,
          period_end: pend, amount: 0, cash_settled: 0, days_covered: null
        });
        buckets.set(key, b);
      }
      b.amount += (+r.amount || 0);
      const ps = r.period_start || r.flow_date;
      if(ps < b.period_start) b.period_start = ps;
      /* Settlement TYPE says cash rather than PIK; the period end is the date
         the sheet's own schedule makes it due. The parser no longer claims a
         row settles on the day it accrues — that fiction cleared the
         receivable every day and kept its balance permanently nil. */
      if(String(t.settlementType || 'cash').toLowerCase() === 'cash'){
        b.cash_settled = b.amount;
      }
    }
    feedRows = passthrough.concat(Array.from(buckets.values()));
    out.rowsAggregated = rows.length - feedRows.length;
  }

  const sorted = feedRows.slice().sort((a, b) =>
    String(a.flow_date || '').localeCompare(String(b.flow_date || '')));

  for(const r of sorted){
    const eff = r.flow_date;
    if(!eff){ out.rowsSkipped++; continue; }
    const amt  = +r.amount || 0;
    /* cash_settled arrives as numeric, not boolean — a column that looks like a
       flag and is not. Treating it as truthy would have posted the full accrual
       as cash on every row that settled a penny. */
    const cash = +r.cash_settled || 0;
    const type = String(r.posting_type || '').toLowerCase();
    const memo = ' · ' + system + ' ' + label(r);
    let handled = false;

    if(type === 'interest'){
      if(Math.abs(amt) > 0.005){
        add('Interest Receivable',            amt, true,  '40100', eff, 'Interest accrual' + memo);
        add('Income - Daily Accrued Interest', amt, false, '23000', eff, 'Interest accrual' + memo);
        jeIndex++;
      }
      if(Math.abs(cash) > 0.005){
        add('Interest Cash Receipt',     cash, true,  '10000', eff, 'Interest cash settlement' + memo);
        add('Interest Receivable Clear', cash, false, '23000', eff, 'Interest cash settlement' + memo);
        jeIndex++;
      }
      handled = true;
    } else if(type === 'fee'){
      if(Math.abs(amt) > 0.005){
        add('Fee Income (PortF)', amt, false, '40250', eff, 'Fee accrual' + memo);
        add('Fee Receivable',     amt, true,  '23150', eff, 'Fee accrual' + memo);
        jeIndex++;
      }
      if(Math.abs(cash) > 0.005){
        add('Fee Cash Receipt',       cash, true,  '10000', eff, 'Fee cash settlement' + memo);
        add('Fee Receivable Clear',   cash, false, '23150', eff, 'Fee cash settlement' + memo);
        jeIndex++;
      }
      handled = true;
    } else if(type === 'drawdown' || type === 'principaldrawdown'){
      if(Math.abs(amt) > 0.005){
        add('Loan Drawdown',        Math.abs(amt), true,  '15000', eff, 'Drawdown' + memo);
        add('Loan Drawdown — Cash', Math.abs(amt), false, '10000', eff, 'Drawdown' + memo);
        jeIndex++;
      }
      handled = true;
    } else if(type === 'repayment' || type === 'principal' || type === 'principalrepayment'){
      if(Math.abs(amt) > 0.005){
        add('Loan Repayment — Cash', Math.abs(amt), true,  '10000', eff, 'Repayment' + memo);
        add('Loan Repayment',        Math.abs(amt), false, '15000', eff, 'Repayment' + memo);
        jeIndex++;
      }
      handled = true;
    } else if(type === 'capitalisation' || type === 'capitalization' || type === 'pik'){
      /* NOT the engine's reclass. The engine books PIK by moving interest its
         own daily accrual already parked in Interest Receivable across into the
         loan asset. Under a feed no such receivable was ever raised — the
         capitalised amount arrives as a fact — so reversing it leaves a lone
         debit and a batch that does not balance (Ardersier was out by exactly
         its PIK total). What is true is simpler: the borrower owes more and we
         earned income. */
      if(Math.abs(amt) > 0.005){
        add('PIK Interest Capitalised', Math.abs(amt), true,  '15000', eff, 'PIK capitalisation' + memo);
        add('PIK Interest Income',      Math.abs(amt), false, '23000', eff, 'PIK capitalisation' + memo);
        jeIndex++;
      }
      handled = true;
    }

    if(handled){
      out.rowsPosted++;
      if(!out.minDate || eff < out.minDate) out.minDate = eff;
      if(!out.maxDate || eff > out.maxDate) out.maxDate = eff;
    } else {
      out.rowsSkipped++;
      // Carried out so the caller can say which types went unposted, with a
      // count and an example date, rather than reporting a clean run.
      let u = out.unmapped.find(x => x.postingType === (r.posting_type || '(blank)'));
      if(!u){ u = { postingType: r.posting_type || '(blank)', count: 0,
                    firstDate: eff, total: 0 }; out.unmapped.push(u); }
      u.count++; u.total += amt;
    }
  }

  out.entries = applyInvestranGLMapping(entries);
  return out;
}

// ═══════════════════════════════════════════════════════════════════════════
// splitInterestJEsByCouponPeriod — post-processor for generateDIU output
// ═══════════════════════════════════════════════════════════════════════════
// The base generateDIU emits one aggregated interest JE pair (Interest
// Receivable + Income - Daily Accrued Interest) and one aggregated
// settlement pair (Interest Cash Receipt + Interest Receivable Clear) for
// the WHOLE window at `summary.periodEnd`. That's not how the real world
// works — quarterly floaters post interest every 3 months, not once at
// maturity.
//
// This helper transforms an already-generated JE array in place:
//   1. Detects aggregated interest rows (by transaction_type + effective_date)
//   2. Derives coupon payment dates from inst's coupon frequency
//   3. Sums dailyCash from the daily schedule per period
//   4. Removes the aggregated interest pairs
//   5. Emits per-period Interest Receivable / Income pairs on each period-end
//   6. Emits per-period Cash Receipt / Receivable Clear pairs on each period-end
//
// Non-interest JEs (drawdown, prepayment, ECL, fees, etc.) pass through
// untouched.
//
// Returns the new journals array. Caller should replace the original.
function splitInterestJEsByCouponPeriod(journals, inst, schedule){
  if(!Array.isArray(journals) || !journals.length) return journals;
  if(!Array.isArray(schedule) || !schedule.length) return journals;

  // 1. Derive coupon period length.
  //    Priority: inst.couponFrequency > tranche's interestComponents[0].terms[0].tenor > default 3M
  //    Result is expressed as periodDays (integer). "weekly" is 7 days;
  //    monthly/quarterly/etc. round-trip through periodMonths → periodDays
  //    isn't done — we keep monthly semantics for those via setUTCMonth.
  const freqToMonths = { monthly:1, quarterly:3, 'semi-annual':6, semi:6, semiannual:6, annual:12, yearly:12 };
  const tenorToMonths = (t) => {
    if(!t) return null;
    const m = String(t).toUpperCase().match(/^(\d+)([MY])$/);
    if(!m) return null;
    return m[2] === 'Y' ? +m[1] * 12 : +m[1];
  };
  const freqLower = String(inst.couponFrequency || '').toLowerCase();
  // Bullet/at-maturity flag — skip splitting entirely (JE stays at maturity date)
  if(freqLower === 'at-maturity' || freqLower === 'bullet') return journals;
  // Weekly special case — steps by 7 days, not by month math. All other
  // frequencies use monthly stepping. Bail out with days-based generation
  // when weekly, then rejoin the mainline loop below.
  const isWeekly = (freqLower === 'weekly');
  let periodMonths = 0;
  if(!isWeekly){
    periodMonths =
      freqToMonths[freqLower] ||
      tenorToMonths(inst.tranches && inst.tranches[0] && inst.tranches[0].interestComponents &&
                    inst.tranches[0].interestComponents[0] && inst.tranches[0].interestComponents[0].terms &&
                    inst.tranches[0].interestComponents[0].terms[0] && inst.tranches[0].interestComponents[0].terms[0].tenor) ||
      tenorToMonths(inst.rfr && inst.rfr.tenor) ||
      3;   // quarterly default
  }

  // 2. Derive coupon payment dates from settle → maturity stepped by periodMonths.
  //    Payment on last day of each period. E.g. settle 2026-01-15, quarterly →
  //    2026-04-15, 2026-07-15, 2026-10-15, 2027-01-15, ... up to maturity.
  const settleISO   = inst.settlementDate || schedule[0].date;
  const maturityISO = inst.maturityDate || schedule[schedule.length - 1].date;
  if(!settleISO || !maturityISO) return journals;
  const paymentDates = [];
  const start = new Date(settleISO + 'T00:00:00Z');
  const mat   = new Date(maturityISO + 'T00:00:00Z');
  let cursor = new Date(start);
  if(isWeekly){
    cursor.setUTCDate(cursor.getUTCDate() + 7);
  } else {
    cursor.setUTCMonth(cursor.getUTCMonth() + periodMonths);
  }
  while(cursor <= mat){
    paymentDates.push(cursor.toISOString().slice(0,10));
    cursor = new Date(cursor);
    if(isWeekly){
      cursor.setUTCDate(cursor.getUTCDate() + 7);
    } else {
      cursor.setUTCMonth(cursor.getUTCMonth() + periodMonths);
    }
  }
  // Ensure the final period ends at maturity (in case settle+N*period doesn't line up)
  const lastMaturityISO = mat.toISOString().slice(0,10);
  if(!paymentDates.length || paymentDates[paymentDates.length - 1] !== lastMaturityISO){
    paymentDates.push(lastMaturityISO);
  }
  // ALSO insert paydown / prepayment / mandatory-prepayment dates as period
  // boundaries. When a loan closes early (e.g. covenant-triggered mandatory
  // prepayment mid-quarter), the accrued interest since the last coupon MUST
  // be settled on the close date, not silently rolled into a coupon that
  // will never happen. Without this, matches the deriveNotices logic which
  // dumps notices on the same events.
  const eventDatesSet = new Set(paymentDates);
  for(const r of schedule){
    if(!r.date) continue;
    const closeEvent = (+r.paydown || 0) > 0.01 ||
                       (+r.prepayment || 0) > 0.01;
    if(closeEvent && r.date > settleISO && r.date <= maturityISO){
      eventDatesSet.add(r.date);
    }
  }
  const allBoundaries = Array.from(eventDatesSet).sort();
  // If we only got 1 period (shorter than one coupon period), don't split — the
  // aggregated JE is already the right shape.
  if(allBoundaries.length <= 1) return journals;
  // Overwrite paymentDates with the merged, sorted list (coupon + event dates)
  paymentDates.length = 0;
  paymentDates.push.apply(paymentDates, allBoundaries);

  // 3. Sum daily interest per period (from schedule row.dailyCash).
  //    A row belongs to the period whose payment_date is the smallest one >= row.date.
  const periodTotals = paymentDates.map(d => ({ end: d, sum: 0 }));
  for(const r of schedule){
    if(!r.date || !r.dailyCash) continue;
    const rd = r.date;
    let bucket = periodTotals.find(p => rd <= p.end);
    if(!bucket) bucket = periodTotals[periodTotals.length - 1];   // trailing dust
    bucket.sum += (+r.dailyCash || 0);
  }
  // Skip periods that had zero accrual (e.g. loan not yet drawn)
  const activePeriods = periodTotals.filter(p => p.sum > 0.005);
  if(!activePeriods.length) return journals;

  // 4. Identify & remove the aggregated interest rows to be replaced.
  //    Heuristic: aggregate means <=2 rows per interest type (one DR + one CR).
  //    If we already have many rows per type, they're already per-period and
  //    we shouldn't touch them. Match by transaction type — date might not
  //    equal maturity (engine uses summary.periodEnd which can differ).
  const AGG_INTEREST_TYPES = new Set([
    'Interest Receivable',
    'Income - Daily Accrued Interest',
    'Interest Cash Receipt',
    'Interest Receivable Clear'
  ]);
  const intCounts = {};
  for(const j of journals){
    if(AGG_INTEREST_TYPES.has(j.transactionType)){
      intCounts[j.transactionType] = (intCounts[j.transactionType] || 0) + 1;
    }
  }
  const looksAggregate = Object.values(intCounts).every(c => c <= 2);
  if(!looksAggregate) return journals;  // already per-period
  const kept = [];
  const removedTemplate = { accrual: null, cash: null };
  for(const j of journals){
    if(AGG_INTEREST_TYPES.has(j.transactionType)){
      if(j.transactionType === 'Interest Receivable' && !removedTemplate.accrual) removedTemplate.accrual = j;
      if(j.transactionType === 'Interest Cash Receipt' && !removedTemplate.cash)  removedTemplate.cash = j;
      continue;   // drop it
    }
    kept.push(j);
  }
  if(!removedTemplate.accrual && !removedTemplate.cash) return journals;

  // 5. Emit per-period pairs. Reuse the template's shape (legalEntity, deal,
  //    account codes, etc.) — just override amount + effectiveDate + memo.
  const newRows = [];
  let jeIndex = Math.max(0, ...kept.map(r => +r.jeIndex || 0)) + 1;
  const clone = (tmpl, overrides) => Object.assign({}, tmpl, overrides);
  for(const p of activePeriods){
    const memo = 'Interest accrual · period ending ' + p.end;
    if(removedTemplate.accrual){
      // Accrual pair: DR Interest Receivable / CR Income - Daily Accrued Interest
      newRows.push(clone(removedTemplate.accrual, {
        jeIndex, txIndex: 2,
        glDate: p.end, effectiveDate: p.end,
        transactionType: 'Interest Receivable',
        originalAmount: p.sum, amountLE: p.sum, amountLocal: p.sum,
        isDebit: true, transactionComments: memo
      }));
      newRows.push(clone(removedTemplate.accrual, {
        jeIndex, txIndex: 1,
        glDate: p.end, effectiveDate: p.end,
        transactionType: 'Income - Daily Accrued Interest',
        originalAmount: p.sum, amountLE: p.sum, amountLocal: p.sum,
        isDebit: false, transactionComments: memo
      }));
      jeIndex++;
    }
    if(removedTemplate.cash){
      // Settlement pair: DR Interest Cash Receipt / CR Interest Receivable Clear
      newRows.push(clone(removedTemplate.cash, {
        jeIndex, txIndex: 2,
        glDate: p.end, effectiveDate: p.end,
        transactionType: 'Interest Cash Receipt',
        originalAmount: p.sum, amountLE: p.sum, amountLocal: p.sum,
        isDebit: true, transactionComments: 'Interest cash settlement · period ending ' + p.end
      }));
      newRows.push(clone(removedTemplate.cash, {
        jeIndex, txIndex: 1,
        glDate: p.end, effectiveDate: p.end,
        transactionType: 'Interest Receivable Clear',
        originalAmount: p.sum, amountLE: p.sum, amountLocal: p.sum,
        isDebit: false, transactionComments: 'Interest cash settlement · period ending ' + p.end
      }));
      jeIndex++;
    }
  }
  /* ── Discount accretion / premium amortisation — the same problem ────────
     generateDIU adds ONE amortisation pair for the whole window at
     summary.periodEnd, exactly as it did for interest. Interest was split
     above and amortisation was left behind, so a deal whose fee accretes
     across twenty quarters posted the entire accretion in the last one:
     DEMO-FEES-EIR recognised £2,000,000 of interest income in a single
     period, and CYPRESS_001 posted its accretion in January 2031 against
     interest that stopped in May 2026.

     The daily figures were always right — buildSchedule computes
     amortDaily = carryingValue × effectiveYield × dcf − dailyCash per day.
     Only the posting granularity was wrong, which is why the totals always
     reconciled and nothing looked broken until someone read the dates.

     Same period boundaries as the interest split, so the accretion lands on
     the coupon dates its own schedule produced it on. The sign is evaluated
     per period rather than once for the window: accretion and amortisation
     are opposite directions and a deal can in principle do both. */
  const AMORT_TYPES = new Set(['Discount Accretion', 'Discount Accretion Offset',
                               'Premium Amortization', 'Premium Amortization Offset']);
  let finalKept = kept;
  const amortCounts = {};
  for(const j of kept){
    if(AMORT_TYPES.has(j.transactionType)){
      amortCounts[j.transactionType] = (amortCounts[j.transactionType] || 0) + 1;
    }
  }
  const amortIsAggregate = Object.keys(amortCounts).length > 0
                        && Object.values(amortCounts).every(c => c <= 2);
  if(amortIsAggregate){
    const amortTotals = paymentDates.map(d => ({ end: d, sum: 0 }));
    for(const r of schedule){
      if(!r.date || !r.amortDaily) continue;
      let b = amortTotals.find(p => r.date <= p.end);
      if(!b) b = amortTotals[amortTotals.length - 1];
      b.sum += (+r.amortDaily || 0);
    }
    const activeAmort = amortTotals.filter(p => Math.abs(p.sum) > 0.005);
    // One active period means the single line is already on the right date.
    if(activeAmort.length > 1){
      let incomeTmpl = null, offsetTmpl = null;
      const withoutAmort = [];
      for(const j of kept){
        if(AMORT_TYPES.has(j.transactionType)){
          if(/ Offset$/.test(j.transactionType)){ if(!offsetTmpl) offsetTmpl = j; }
          else if(!incomeTmpl) incomeTmpl = j;
          continue;
        }
        withoutAmort.push(j);
      }
      if(incomeTmpl && offsetTmpl){
        for(const p of activeAmort){
          const isAccretion = p.sum > 0;
          const label = isAccretion ? 'Discount Accretion' : 'Premium Amortization';
          const abs   = Math.abs(p.sum);
          const memo  = label + ' · period ending ' + p.end;
          // Income leg: CR on accretion (income up), DR on premium (income down).
          newRows.push(clone(incomeTmpl, {
            jeIndex, txIndex: 1, glDate: p.end, effectiveDate: p.end,
            transactionType: label,
            originalAmount: abs, amountLE: abs, amountLocal: abs,
            isDebit: !isAccretion, transactionComments: memo
          }));
          // Carrying-value leg: the mirror.
          newRows.push(clone(offsetTmpl, {
            jeIndex, txIndex: 2, glDate: p.end, effectiveDate: p.end,
            transactionType: label + ' Offset',
            originalAmount: abs, amountLE: abs, amountLocal: abs,
            isDebit: isAccretion, transactionComments: memo
          }));
          jeIndex++;
        }
        finalKept = withoutAmort;
      }
    }
  }

  /* Route the new rows through the GL mapper.
     These rows are CLONES of the template line, so without this they inherit
     the template's account on every leg — the receivable legs would carry the
     income account, and the two credit legs carried a hardcoded '23000'.
     Every other DIU generator ends with this call; this one did not, which is
     why the per-period interest lines were the only ones still showing 23000
     instead of 421000 (Income - Daily Accrued Interest) and 113000
     (Interest Receivable Clear). One source of truth: INVESTRAN_GL. */
  return finalKept.concat(applyInvestranGLMapping(newRows));
}

if(typeof window !== 'undefined') window.splitInterestJEsByCouponPeriod = splitInterestJEsByCouponPeriod;

/* ═══════════════════════════════════════════════════════════════════════════
   splitECLByReportingPeriod — one impairment entry per reporting date
   ───────────────────────────────────────────────────────────────────────────
   IFRS 9 5.5.1 measures the loss allowance AT EACH REPORTING DATE, and the
   period's impairment charge is the movement in that allowance. The engine
   already models this properly: every schedule row carries `eclAllowance`,
   re-derived daily from stage, exposure and remaining life, with SICR
   migration and releases on cure, write-off and participation sale.

   generateDIU then threw that away. It collapsed roughly three thousand daily
   movements into a single `summary.totalECLChange` and posted it at
   `summary.periodEnd` — the end of the MODELLED HORIZON, which on a full-term
   run is maturity. So an eight-year loan booked its entire impairment charge
   in 2034, the balance sheet carried no allowance at any reporting date before
   then, and a month-end close deleted the entry outright, because the
   up-until filter drops rows dated after the cut-off.

   `periodEnd` meaning "end of the model" rather than "end of the accounting
   period" is the whole bug. Interest was already fixed this way — hence 99
   monthly interest entries beside a single ECL one in the same ledger.

   This takes the allowance at each reporting date, differences consecutive
   values, and posts the movement on that date. Provisions and releases use
   the same transaction types and accounts as before, so Investran GL routing
   is untouched.

   It also GENERATES the entries where none existed: external deals post from
   the received feed, which carries no ECL because ECL is PCS's own
   calculation, so the aggregate pair was simply absent. Deriving from the
   schedule rather than from the rows being replaced fixes both cases in one
   pass.
   ═══════════════════════════════════════════════════════════════════════════ */
function splitECLByReportingPeriod(journals, inst, schedule, opts){
  opts = opts || {};
  const rows = Array.isArray(journals) ? journals : [];
  if(!Array.isArray(schedule) || !schedule.length) return rows;

  const ECL_TYPES = /^(Impairment Expense \(ECL\)|Loan Loss Allowance \(Contra-Asset\)|Impairment Reversal \(ECL\)|Loan Loss Allowance Reversal)$/i;
  const aggregates = rows.filter(j => ECL_TYPES.test(j.transactionType || ''));
  const kept       = rows.filter(j => !ECL_TYPES.test(j.transactionType || ''));

  // Nothing to do when the allowance never moves — a Stage 1 bullet with a
  // flat exposure legitimately has one step and then nothing. Emitting a
  // string of zero-value entries would be noise dressed as diligence.
  const hasAllowance = schedule.some(r => Math.abs(+r.eclAllowance || 0) > 0.005);
  if(!hasAllowance) return kept;

  /* Reporting grid. Monthly by default — it matches the coupon split, and a
     fund striking quarterly NAVs can set 'quarterly' rather than getting
     twelve entries where it wants four. Deliberately NOT tied to coupon
     frequency: when you report is an accounting-policy question, not a
     property of the loan's payment terms. */
  const freq = String(opts.frequency || (typeof window !== 'undefined' && window.__ECL_REPORTING_FREQ) || 'monthly').toLowerCase();
  const stepMonths = freq === 'quarterly' ? 3
                   : freq === 'semi-annual' || freq === 'semi' ? 6
                   : freq === 'annual' || freq === 'yearly' ? 12
                   : 1;

  // Allowance on each date, plus the ordered list of dates we actually hold.
  const allowanceByDate = new Map();
  for(const r of schedule){
    if(r && r.date) allowanceByDate.set(r.date, +r.eclAllowance || 0);
  }
  const firstDate = schedule[0].date;
  const lastDate  = schedule[schedule.length - 1].date;

  /* Period ends: step from the first schedule date, and always include the
     last one. The final period is usually partial, and dropping it would
     strand whatever the allowance did in it — most often the release to zero
     at repayment, which is the entry an auditor looks for first. */
  const ends = [];
  const cur = new Date(firstDate + 'T00:00:00Z');
  const end = new Date(lastDate + 'T00:00:00Z');
  while(true){
    cur.setUTCMonth(cur.getUTCMonth() + stepMonths);
    if(cur > end) break;
    ends.push(cur.toISOString().slice(0, 10));
  }
  if(!ends.length || ends[ends.length - 1] !== lastDate) ends.push(lastDate);

  // The allowance as at a date — walk back up to 7 days for a period end that
  // falls on a non-schedule day (weekend, holiday roll).
  const allowanceAt = (iso) => {
    if(allowanceByDate.has(iso)) return allowanceByDate.get(iso);
    const d = new Date(iso + 'T00:00:00Z');
    for(let k = 0; k < 7; k++){
      d.setUTCDate(d.getUTCDate() - 1);
      const key = d.toISOString().slice(0, 10);
      if(allowanceByDate.has(key)) return allowanceByDate.get(key);
    }
    return null;
  };

  const fw = String((inst && inst.accountingFramework) || 'IFRS').toUpperCase();
  const eclLabel = fw === 'USGAAP' ? 'ASC 326 CECL'
                 : fw === 'AASB'   ? 'AASB 9 ECL'
                 : fw === 'ASPE'   ? 'ASPE 3856 incurred-loss'
                 :                   'IFRS 9 ECL';

  /* Carry the batch/entity context from a row that already exists. Rebuilding
     it from `inst` would drift from whatever the rest of the run used — and on
     the external path these rows have to sit in the same batch as the feed
     journals they accompany. */
  const tpl = aggregates[0] || kept[0] || null;
  if(!tpl) return kept;
  let jeIndex = kept.reduce((m, j) => Math.max(m, +j.jeIndex || 0), 0) + 1;
  const mk = (transType, amount, isDebit, account, effDate, comments) =>
    Object.assign({}, tpl, {
      jeIndex: jeIndex, txIndex: isDebit ? 2 : 1,
      glDate: (opts.glDate || effDate), effectiveDate: effDate,
      transactionType: transType, account: account,
      originalAmount: amount, amountLE: Math.abs(amount), amountLocal: Math.abs(amount),
      isDebit: isDebit, transactionComments: comments,
      glAccountName: undefined, glTransType: undefined   // re-mapped by the GL pass
    });

  const out = [];
  /* The allowance starts at NIL, not at whatever it already is on day one.

     This seeded `prev` from the first schedule date, which silently treated a
     day-one allowance as an opening balance that had been journalised
     somewhere else. Nothing ever journalises it. On a Stage 3 deal the target
     is reached immediately — balance × lifetime PD × LGD, which on the Stage 3
     demo deal is 100,000,000 × 100% × 40% = 40,000,000 — so the whole
     establishment vanished: the ledger showed 4,651,540 of impairment expense
     against 44,651,540 of releases, a net credit of exactly the 40,000,000
     that was never charged. An allowance cannot appear on the balance sheet
     without a charge to profit or loss, and the first reporting period is
     where that charge belongs.

     opts.openingAllowance exists for the one case where an opening balance is
     real: an external feed that carries an allowance recognised before PCS saw
     the deal. Posting that as a current-period charge would be just as wrong
     in the other direction, so the caller can say so explicitly. */
  let prev = (opts.openingAllowance != null) ? +opts.openingAllowance : 0;
  if(!isFinite(prev)) prev = 0;
  for(const e of ends){
    const now = allowanceAt(e);
    if(now == null) continue;
    const delta = +(now - prev).toFixed(2);
    prev = now;
    if(Math.abs(delta) <= 0.005) continue;      // no movement, no entry
    const memo = eclLabel + (delta > 0 ? ' provision' : ' release') +
                 ' for period ending ' + e +
                 ' · allowance ' + now.toFixed(2);
    if(delta > 0){
      out.push(mk('Impairment Expense (ECL)',           delta, true,  '70100', e, memo));
      out.push(mk('Loan Loss Allowance (Contra-Asset)', delta, false, '15500', e, memo));
    } else {
      out.push(mk('Impairment Reversal (ECL)',          -delta, false, '70100', e, memo));
      out.push(mk('Loan Loss Allowance Reversal',       -delta, true,  '15500', e, memo));
    }
    jeIndex++;
  }

  /* As above: this is a post-processor, so it runs after generateDIU's GL
     pass and nothing maps its output unless it does so itself. Unmapped, the
     ECL pair carried 70100 / 15500 — the engine's internal codes — instead of
     470000 Impairment / 145000 Loan Loss Allowance, with no account name. */
  return kept.concat(applyInvestranGLMapping(out));
}
if(typeof window !== 'undefined') window.splitECLByReportingPeriod = splitECLByReportingPeriod;

/* ═══════════════════════════════════════════════════════════════════════════
   emitPrincipalMovementsFromSchedule — book the drawdowns and repayments
   ───────────────────────────────────────────────────────────────────────────
   Principal does NOT arrive on the cashflow sheet. It arrives on Movements —
   Initial Purchase, drawdown, repayment, capitalisation — and the engine folds
   those into the schedule as `draw` and `paydown` per day.

   generateDIU walks the schedule and books them. The external feed generator
   does not: it emits one JE per RECEIVED CASHFLOW ROW, and principal is not a
   cashflow row. So an imported deal recognised no loan asset at all. External
   Deal III carried three Initial Purchases totalling £100,000,000, every one
   of them present in the schedule, and not a single Loan Drawdown entry in the
   ledger — while 3,864 interest lines accrued on the asset that was never
   booked. Interest on nothing, and a balance sheet missing the loan.

   Derived from the schedule rather than from the feed rows on purpose: the
   schedule is where movements have already been reconciled into a single daily
   position, so there is one source and nothing to double-count.

   No-ops when principal entries already exist, so the internal path — which
   books them inside generateDIU — is untouched.
   ═══════════════════════════════════════════════════════════════════════════ */
function emitPrincipalMovementsFromSchedule(journals, inst, schedule, opts){
  opts = opts || {};
  const rows = Array.isArray(journals) ? journals : [];
  if(!Array.isArray(schedule) || !schedule.length) return rows;

  // Already booked (internal path) — leave well alone.
  const PRINCIPAL = /^(Loan Drawdown|Loan Drawdown — Cash|Loan Repayment|Loan Repayment — Cash|Loan Prepayment|Loan Prepayment — Cash)$/i;
  if(rows.some(j => PRINCIPAL.test(j.transactionType || ''))) return rows;

  const moves = schedule.filter(r => (Math.abs(+r.draw || 0) > 0.005) ||
                                     (Math.abs(+r.paydown || 0) > 0.005));
  if(!moves.length) return rows;

  const tpl = rows[0];
  if(!tpl) return rows;                      // nothing to inherit batch context from
  let jeIndex = rows.reduce((m, j) => Math.max(m, +j.jeIndex || 0), 0) + 1;
  const system = opts.system || 'the external feed';
  const mk = (transType, amount, isDebit, account, effDate, comments) =>
    Object.assign({}, tpl, {
      jeIndex: jeIndex, txIndex: isDebit ? 2 : 1,
      glDate: (opts.glDate || effDate), effectiveDate: effDate,
      transactionType: transType, account: account,
      originalAmount: amount, amountLE: Math.abs(amount), amountLocal: Math.abs(amount),
      isDebit: isDebit, transactionComments: comments,
      glAccountName: undefined, glTransType: undefined   // re-mapped by the GL pass
    });

  const out = [];
  for(const r of moves){
    const draw = +r.draw || 0;
    const paid = +r.paydown || 0;
    if(Math.abs(draw) > 0.005){
      const memo = 'Drawdown ' + r.date + ' · movement supplied by ' + system;
      out.push(mk('Loan Drawdown',        draw, true,  '15000', r.date, memo));
      out.push(mk('Loan Drawdown — Cash', draw, false, '10000', r.date, memo));
      jeIndex++;
    }
    if(Math.abs(paid) > 0.005){
      const memo = 'Repayment ' + r.date + ' · movement supplied by ' + system;
      out.push(mk('Loan Repayment — Cash', paid, true,  '10000', r.date, memo));
      out.push(mk('Loan Repayment',        paid, false, '15000', r.date, memo));
      jeIndex++;
    }
  }
  /* Map the new rows into the Investran chart before returning them.

     generateDIU ends with applyInvestranGLMapping, so anything it emits is
     already translated — but this runs AFTER that, as a post-processor, and
     nothing re-runs the mapping afterwards. The rows therefore reached the
     ledger carrying the engine's internal codes (15000, 10000) with no
     glAccountName at all: an account nobody recognises and a blank name.

     Only the NEW rows are mapped. `rows` has been through the pass already.  */
  return rows.concat(applyInvestranGLMapping(out));
}
if(typeof window !== 'undefined') window.emitPrincipalMovementsFromSchedule = emitPrincipalMovementsFromSchedule;


